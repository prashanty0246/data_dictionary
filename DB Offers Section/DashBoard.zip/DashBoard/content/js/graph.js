/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 20.0, "minX": 0.0, "maxY": 198219.0, "series": [{"data": [[0.0, 20.0], [0.1, 31.0], [0.2, 31.0], [0.3, 32.0], [0.4, 32.0], [0.5, 32.0], [0.6, 33.0], [0.7, 33.0], [0.8, 33.0], [0.9, 33.0], [1.0, 33.0], [1.1, 33.0], [1.2, 34.0], [1.3, 34.0], [1.4, 34.0], [1.5, 34.0], [1.6, 34.0], [1.7, 34.0], [1.8, 34.0], [1.9, 34.0], [2.0, 34.0], [2.1, 35.0], [2.2, 35.0], [2.3, 35.0], [2.4, 35.0], [2.5, 35.0], [2.6, 35.0], [2.7, 35.0], [2.8, 35.0], [2.9, 35.0], [3.0, 35.0], [3.1, 35.0], [3.2, 35.0], [3.3, 36.0], [3.4, 36.0], [3.5, 36.0], [3.6, 36.0], [3.7, 36.0], [3.8, 36.0], [3.9, 36.0], [4.0, 36.0], [4.1, 36.0], [4.2, 36.0], [4.3, 36.0], [4.4, 36.0], [4.5, 36.0], [4.6, 36.0], [4.7, 37.0], [4.8, 37.0], [4.9, 37.0], [5.0, 37.0], [5.1, 37.0], [5.2, 37.0], [5.3, 37.0], [5.4, 37.0], [5.5, 37.0], [5.6, 37.0], [5.7, 37.0], [5.8, 37.0], [5.9, 37.0], [6.0, 37.0], [6.1, 38.0], [6.2, 38.0], [6.3, 38.0], [6.4, 38.0], [6.5, 38.0], [6.6, 38.0], [6.7, 38.0], [6.8, 38.0], [6.9, 38.0], [7.0, 38.0], [7.1, 38.0], [7.2, 38.0], [7.3, 38.0], [7.4, 38.0], [7.5, 38.0], [7.6, 39.0], [7.7, 39.0], [7.8, 39.0], [7.9, 39.0], [8.0, 39.0], [8.1, 39.0], [8.2, 39.0], [8.3, 39.0], [8.4, 39.0], [8.5, 39.0], [8.6, 39.0], [8.7, 39.0], [8.8, 39.0], [8.9, 39.0], [9.0, 39.0], [9.1, 39.0], [9.2, 39.0], [9.3, 40.0], [9.4, 40.0], [9.5, 40.0], [9.6, 40.0], [9.7, 40.0], [9.8, 40.0], [9.9, 40.0], [10.0, 40.0], [10.1, 40.0], [10.2, 40.0], [10.3, 40.0], [10.4, 40.0], [10.5, 40.0], [10.6, 40.0], [10.7, 40.0], [10.8, 40.0], [10.9, 40.0], [11.0, 40.0], [11.1, 41.0], [11.2, 41.0], [11.3, 41.0], [11.4, 41.0], [11.5, 41.0], [11.6, 41.0], [11.7, 41.0], [11.8, 41.0], [11.9, 41.0], [12.0, 41.0], [12.1, 41.0], [12.2, 41.0], [12.3, 41.0], [12.4, 41.0], [12.5, 41.0], [12.6, 41.0], [12.7, 41.0], [12.8, 41.0], [12.9, 41.0], [13.0, 41.0], [13.1, 41.0], [13.2, 41.0], [13.3, 42.0], [13.4, 42.0], [13.5, 42.0], [13.6, 42.0], [13.7, 42.0], [13.8, 42.0], [13.9, 42.0], [14.0, 42.0], [14.1, 42.0], [14.2, 42.0], [14.3, 42.0], [14.4, 42.0], [14.5, 42.0], [14.6, 42.0], [14.7, 42.0], [14.8, 42.0], [14.9, 42.0], [15.0, 42.0], [15.1, 42.0], [15.2, 42.0], [15.3, 43.0], [15.4, 43.0], [15.5, 43.0], [15.6, 43.0], [15.7, 43.0], [15.8, 43.0], [15.9, 43.0], [16.0, 43.0], [16.1, 43.0], [16.2, 43.0], [16.3, 43.0], [16.4, 43.0], [16.5, 43.0], [16.6, 43.0], [16.7, 43.0], [16.8, 43.0], [16.9, 43.0], [17.0, 43.0], [17.1, 43.0], [17.2, 43.0], [17.3, 44.0], [17.4, 44.0], [17.5, 44.0], [17.6, 44.0], [17.7, 44.0], [17.8, 44.0], [17.9, 44.0], [18.0, 44.0], [18.1, 44.0], [18.2, 44.0], [18.3, 44.0], [18.4, 44.0], [18.5, 44.0], [18.6, 44.0], [18.7, 44.0], [18.8, 44.0], [18.9, 44.0], [19.0, 44.0], [19.1, 45.0], [19.2, 45.0], [19.3, 45.0], [19.4, 45.0], [19.5, 45.0], [19.6, 45.0], [19.7, 45.0], [19.8, 45.0], [19.9, 45.0], [20.0, 45.0], [20.1, 45.0], [20.2, 45.0], [20.3, 45.0], [20.4, 45.0], [20.5, 45.0], [20.6, 45.0], [20.7, 45.0], [20.8, 45.0], [20.9, 45.0], [21.0, 45.0], [21.1, 45.0], [21.2, 46.0], [21.3, 46.0], [21.4, 46.0], [21.5, 46.0], [21.6, 46.0], [21.7, 46.0], [21.8, 46.0], [21.9, 46.0], [22.0, 46.0], [22.1, 46.0], [22.2, 46.0], [22.3, 46.0], [22.4, 46.0], [22.5, 46.0], [22.6, 46.0], [22.7, 46.0], [22.8, 46.0], [22.9, 46.0], [23.0, 46.0], [23.1, 46.0], [23.2, 46.0], [23.3, 47.0], [23.4, 47.0], [23.5, 47.0], [23.6, 47.0], [23.7, 47.0], [23.8, 47.0], [23.9, 47.0], [24.0, 47.0], [24.1, 47.0], [24.2, 47.0], [24.3, 47.0], [24.4, 47.0], [24.5, 47.0], [24.6, 47.0], [24.7, 47.0], [24.8, 47.0], [24.9, 47.0], [25.0, 47.0], [25.1, 47.0], [25.2, 48.0], [25.3, 48.0], [25.4, 48.0], [25.5, 48.0], [25.6, 48.0], [25.7, 48.0], [25.8, 48.0], [25.9, 48.0], [26.0, 48.0], [26.1, 48.0], [26.2, 48.0], [26.3, 48.0], [26.4, 48.0], [26.5, 48.0], [26.6, 48.0], [26.7, 48.0], [26.8, 48.0], [26.9, 48.0], [27.0, 48.0], [27.1, 48.0], [27.2, 49.0], [27.3, 49.0], [27.4, 49.0], [27.5, 49.0], [27.6, 49.0], [27.7, 49.0], [27.8, 49.0], [27.9, 49.0], [28.0, 49.0], [28.1, 49.0], [28.2, 49.0], [28.3, 49.0], [28.4, 49.0], [28.5, 49.0], [28.6, 49.0], [28.7, 49.0], [28.8, 49.0], [28.9, 49.0], [29.0, 50.0], [29.1, 50.0], [29.2, 50.0], [29.3, 50.0], [29.4, 50.0], [29.5, 50.0], [29.6, 50.0], [29.7, 50.0], [29.8, 50.0], [29.9, 50.0], [30.0, 50.0], [30.1, 50.0], [30.2, 50.0], [30.3, 50.0], [30.4, 50.0], [30.5, 50.0], [30.6, 50.0], [30.7, 51.0], [30.8, 51.0], [30.9, 51.0], [31.0, 51.0], [31.1, 51.0], [31.2, 51.0], [31.3, 51.0], [31.4, 51.0], [31.5, 51.0], [31.6, 51.0], [31.7, 51.0], [31.8, 51.0], [31.9, 51.0], [32.0, 51.0], [32.1, 51.0], [32.2, 51.0], [32.3, 51.0], [32.4, 52.0], [32.5, 52.0], [32.6, 52.0], [32.7, 52.0], [32.8, 52.0], [32.9, 52.0], [33.0, 52.0], [33.1, 52.0], [33.2, 52.0], [33.3, 52.0], [33.4, 52.0], [33.5, 52.0], [33.6, 52.0], [33.7, 52.0], [33.8, 52.0], [33.9, 52.0], [34.0, 53.0], [34.1, 53.0], [34.2, 53.0], [34.3, 53.0], [34.4, 53.0], [34.5, 53.0], [34.6, 53.0], [34.7, 53.0], [34.8, 53.0], [34.9, 53.0], [35.0, 53.0], [35.1, 53.0], [35.2, 53.0], [35.3, 53.0], [35.4, 54.0], [35.5, 54.0], [35.6, 54.0], [35.7, 54.0], [35.8, 54.0], [35.9, 54.0], [36.0, 54.0], [36.1, 54.0], [36.2, 54.0], [36.3, 54.0], [36.4, 54.0], [36.5, 54.0], [36.6, 54.0], [36.7, 55.0], [36.8, 55.0], [36.9, 55.0], [37.0, 55.0], [37.1, 55.0], [37.2, 55.0], [37.3, 55.0], [37.4, 55.0], [37.5, 55.0], [37.6, 55.0], [37.7, 55.0], [37.8, 55.0], [37.9, 55.0], [38.0, 55.0], [38.1, 56.0], [38.2, 56.0], [38.3, 56.0], [38.4, 56.0], [38.5, 56.0], [38.6, 56.0], [38.7, 56.0], [38.8, 56.0], [38.9, 56.0], [39.0, 56.0], [39.1, 56.0], [39.2, 56.0], [39.3, 56.0], [39.4, 56.0], [39.5, 57.0], [39.6, 57.0], [39.7, 57.0], [39.8, 57.0], [39.9, 57.0], [40.0, 57.0], [40.1, 57.0], [40.2, 57.0], [40.3, 57.0], [40.4, 57.0], [40.5, 57.0], [40.6, 57.0], [40.7, 57.0], [40.8, 57.0], [40.9, 58.0], [41.0, 58.0], [41.1, 58.0], [41.2, 58.0], [41.3, 58.0], [41.4, 58.0], [41.5, 58.0], [41.6, 58.0], [41.7, 58.0], [41.8, 58.0], [41.9, 58.0], [42.0, 58.0], [42.1, 58.0], [42.2, 59.0], [42.3, 59.0], [42.4, 59.0], [42.5, 59.0], [42.6, 59.0], [42.7, 59.0], [42.8, 59.0], [42.9, 59.0], [43.0, 59.0], [43.1, 59.0], [43.2, 59.0], [43.3, 59.0], [43.4, 60.0], [43.5, 60.0], [43.6, 60.0], [43.7, 60.0], [43.8, 60.0], [43.9, 60.0], [44.0, 60.0], [44.1, 60.0], [44.2, 60.0], [44.3, 60.0], [44.4, 60.0], [44.5, 60.0], [44.6, 61.0], [44.7, 61.0], [44.8, 61.0], [44.9, 61.0], [45.0, 61.0], [45.1, 61.0], [45.2, 61.0], [45.3, 61.0], [45.4, 61.0], [45.5, 61.0], [45.6, 61.0], [45.7, 61.0], [45.8, 62.0], [45.9, 62.0], [46.0, 62.0], [46.1, 62.0], [46.2, 62.0], [46.3, 62.0], [46.4, 62.0], [46.5, 62.0], [46.6, 62.0], [46.7, 62.0], [46.8, 62.0], [46.9, 63.0], [47.0, 63.0], [47.1, 63.0], [47.2, 63.0], [47.3, 63.0], [47.4, 63.0], [47.5, 63.0], [47.6, 63.0], [47.7, 63.0], [47.8, 63.0], [47.9, 63.0], [48.0, 63.0], [48.1, 64.0], [48.2, 64.0], [48.3, 64.0], [48.4, 64.0], [48.5, 64.0], [48.6, 64.0], [48.7, 64.0], [48.8, 64.0], [48.9, 64.0], [49.0, 64.0], [49.1, 64.0], [49.2, 65.0], [49.3, 65.0], [49.4, 65.0], [49.5, 65.0], [49.6, 65.0], [49.7, 65.0], [49.8, 65.0], [49.9, 65.0], [50.0, 65.0], [50.1, 65.0], [50.2, 66.0], [50.3, 66.0], [50.4, 66.0], [50.5, 66.0], [50.6, 66.0], [50.7, 66.0], [50.8, 66.0], [50.9, 66.0], [51.0, 66.0], [51.1, 66.0], [51.2, 66.0], [51.3, 67.0], [51.4, 67.0], [51.5, 67.0], [51.6, 67.0], [51.7, 67.0], [51.8, 67.0], [51.9, 67.0], [52.0, 67.0], [52.1, 67.0], [52.2, 67.0], [52.3, 68.0], [52.4, 68.0], [52.5, 68.0], [52.6, 68.0], [52.7, 68.0], [52.8, 68.0], [52.9, 68.0], [53.0, 68.0], [53.1, 68.0], [53.2, 69.0], [53.3, 69.0], [53.4, 69.0], [53.5, 69.0], [53.6, 69.0], [53.7, 69.0], [53.8, 69.0], [53.9, 69.0], [54.0, 69.0], [54.1, 70.0], [54.2, 70.0], [54.3, 70.0], [54.4, 70.0], [54.5, 70.0], [54.6, 70.0], [54.7, 70.0], [54.8, 70.0], [54.9, 70.0], [55.0, 71.0], [55.1, 71.0], [55.2, 71.0], [55.3, 71.0], [55.4, 71.0], [55.5, 71.0], [55.6, 71.0], [55.7, 71.0], [55.8, 71.0], [55.9, 72.0], [56.0, 72.0], [56.1, 72.0], [56.2, 72.0], [56.3, 72.0], [56.4, 72.0], [56.5, 72.0], [56.6, 72.0], [56.7, 72.0], [56.8, 73.0], [56.9, 73.0], [57.0, 73.0], [57.1, 73.0], [57.2, 73.0], [57.3, 73.0], [57.4, 73.0], [57.5, 73.0], [57.6, 73.0], [57.7, 74.0], [57.8, 74.0], [57.9, 74.0], [58.0, 74.0], [58.1, 74.0], [58.2, 74.0], [58.3, 74.0], [58.4, 74.0], [58.5, 75.0], [58.6, 75.0], [58.7, 75.0], [58.8, 75.0], [58.9, 75.0], [59.0, 75.0], [59.1, 75.0], [59.2, 76.0], [59.3, 76.0], [59.4, 76.0], [59.5, 76.0], [59.6, 76.0], [59.7, 76.0], [59.8, 76.0], [59.9, 76.0], [60.0, 77.0], [60.1, 77.0], [60.2, 77.0], [60.3, 77.0], [60.4, 77.0], [60.5, 77.0], [60.6, 77.0], [60.7, 77.0], [60.8, 78.0], [60.9, 78.0], [61.0, 78.0], [61.1, 78.0], [61.2, 78.0], [61.3, 78.0], [61.4, 78.0], [61.5, 78.0], [61.6, 79.0], [61.7, 79.0], [61.8, 79.0], [61.9, 79.0], [62.0, 79.0], [62.1, 79.0], [62.2, 79.0], [62.3, 80.0], [62.4, 80.0], [62.5, 80.0], [62.6, 80.0], [62.7, 80.0], [62.8, 80.0], [62.9, 80.0], [63.0, 80.0], [63.1, 81.0], [63.2, 81.0], [63.3, 81.0], [63.4, 81.0], [63.5, 81.0], [63.6, 81.0], [63.7, 81.0], [63.8, 82.0], [63.9, 82.0], [64.0, 82.0], [64.1, 82.0], [64.2, 82.0], [64.3, 82.0], [64.4, 83.0], [64.5, 83.0], [64.6, 83.0], [64.7, 83.0], [64.8, 83.0], [64.9, 83.0], [65.0, 84.0], [65.1, 84.0], [65.2, 84.0], [65.3, 84.0], [65.4, 84.0], [65.5, 84.0], [65.6, 84.0], [65.7, 85.0], [65.8, 85.0], [65.9, 85.0], [66.0, 85.0], [66.1, 85.0], [66.2, 85.0], [66.3, 86.0], [66.4, 86.0], [66.5, 86.0], [66.6, 86.0], [66.7, 86.0], [66.8, 86.0], [66.9, 87.0], [67.0, 87.0], [67.1, 87.0], [67.2, 87.0], [67.3, 87.0], [67.4, 87.0], [67.5, 88.0], [67.6, 88.0], [67.7, 88.0], [67.8, 88.0], [67.9, 88.0], [68.0, 88.0], [68.1, 89.0], [68.2, 89.0], [68.3, 89.0], [68.4, 89.0], [68.5, 89.0], [68.6, 89.0], [68.7, 90.0], [68.8, 90.0], [68.9, 90.0], [69.0, 90.0], [69.1, 90.0], [69.2, 91.0], [69.3, 91.0], [69.4, 91.0], [69.5, 91.0], [69.6, 91.0], [69.7, 91.0], [69.8, 92.0], [69.9, 92.0], [70.0, 92.0], [70.1, 92.0], [70.2, 92.0], [70.3, 93.0], [70.4, 93.0], [70.5, 93.0], [70.6, 93.0], [70.7, 93.0], [70.8, 93.0], [70.9, 94.0], [71.0, 94.0], [71.1, 94.0], [71.2, 94.0], [71.3, 94.0], [71.4, 95.0], [71.5, 95.0], [71.6, 95.0], [71.7, 95.0], [71.8, 95.0], [71.9, 96.0], [72.0, 96.0], [72.1, 96.0], [72.2, 96.0], [72.3, 96.0], [72.4, 97.0], [72.5, 97.0], [72.6, 97.0], [72.7, 97.0], [72.8, 97.0], [72.9, 98.0], [73.0, 98.0], [73.1, 98.0], [73.2, 98.0], [73.3, 98.0], [73.4, 99.0], [73.5, 99.0], [73.6, 99.0], [73.7, 99.0], [73.8, 99.0], [73.9, 100.0], [74.0, 100.0], [74.1, 100.0], [74.2, 100.0], [74.3, 101.0], [74.4, 101.0], [74.5, 101.0], [74.6, 101.0], [74.7, 101.0], [74.8, 102.0], [74.9, 102.0], [75.0, 102.0], [75.1, 102.0], [75.2, 103.0], [75.3, 103.0], [75.4, 103.0], [75.5, 103.0], [75.6, 103.0], [75.7, 104.0], [75.8, 104.0], [75.9, 104.0], [76.0, 104.0], [76.1, 105.0], [76.2, 105.0], [76.3, 105.0], [76.4, 105.0], [76.5, 106.0], [76.6, 106.0], [76.7, 106.0], [76.8, 106.0], [76.9, 107.0], [77.0, 107.0], [77.1, 107.0], [77.2, 108.0], [77.3, 108.0], [77.4, 108.0], [77.5, 108.0], [77.6, 109.0], [77.7, 109.0], [77.8, 109.0], [77.9, 109.0], [78.0, 110.0], [78.1, 110.0], [78.2, 110.0], [78.3, 110.0], [78.4, 111.0], [78.5, 111.0], [78.6, 111.0], [78.7, 112.0], [78.8, 112.0], [78.9, 112.0], [79.0, 112.0], [79.1, 113.0], [79.2, 113.0], [79.3, 113.0], [79.4, 113.0], [79.5, 114.0], [79.6, 114.0], [79.7, 114.0], [79.8, 115.0], [79.9, 115.0], [80.0, 115.0], [80.1, 115.0], [80.2, 116.0], [80.3, 116.0], [80.4, 116.0], [80.5, 117.0], [80.6, 117.0], [80.7, 117.0], [80.8, 118.0], [80.9, 118.0], [81.0, 118.0], [81.1, 118.0], [81.2, 119.0], [81.3, 119.0], [81.4, 119.0], [81.5, 120.0], [81.6, 120.0], [81.7, 120.0], [81.8, 121.0], [81.9, 121.0], [82.0, 121.0], [82.1, 122.0], [82.2, 122.0], [82.3, 122.0], [82.4, 123.0], [82.5, 123.0], [82.6, 123.0], [82.7, 124.0], [82.8, 124.0], [82.9, 124.0], [83.0, 125.0], [83.1, 125.0], [83.2, 125.0], [83.3, 126.0], [83.4, 126.0], [83.5, 127.0], [83.6, 127.0], [83.7, 127.0], [83.8, 128.0], [83.9, 128.0], [84.0, 128.0], [84.1, 129.0], [84.2, 129.0], [84.3, 130.0], [84.4, 130.0], [84.5, 130.0], [84.6, 131.0], [84.7, 131.0], [84.8, 131.0], [84.9, 132.0], [85.0, 132.0], [85.1, 133.0], [85.2, 133.0], [85.3, 133.0], [85.4, 134.0], [85.5, 134.0], [85.6, 135.0], [85.7, 135.0], [85.8, 135.0], [85.9, 136.0], [86.0, 136.0], [86.1, 137.0], [86.2, 137.0], [86.3, 138.0], [86.4, 138.0], [86.5, 139.0], [86.6, 139.0], [86.7, 139.0], [86.8, 140.0], [86.9, 140.0], [87.0, 141.0], [87.1, 141.0], [87.2, 142.0], [87.3, 142.0], [87.4, 143.0], [87.5, 143.0], [87.6, 144.0], [87.7, 144.0], [87.8, 145.0], [87.9, 145.0], [88.0, 146.0], [88.1, 146.0], [88.2, 147.0], [88.3, 147.0], [88.4, 148.0], [88.5, 148.0], [88.6, 149.0], [88.7, 149.0], [88.8, 150.0], [88.9, 150.0], [89.0, 151.0], [89.1, 151.0], [89.2, 152.0], [89.3, 153.0], [89.4, 153.0], [89.5, 154.0], [89.6, 154.0], [89.7, 155.0], [89.8, 155.0], [89.9, 156.0], [90.0, 157.0], [90.1, 157.0], [90.2, 158.0], [90.3, 159.0], [90.4, 159.0], [90.5, 160.0], [90.6, 161.0], [90.7, 161.0], [90.8, 162.0], [90.9, 163.0], [91.0, 163.0], [91.1, 164.0], [91.2, 165.0], [91.3, 165.0], [91.4, 166.0], [91.5, 167.0], [91.6, 168.0], [91.7, 168.0], [91.8, 169.0], [91.9, 170.0], [92.0, 171.0], [92.1, 172.0], [92.2, 173.0], [92.3, 174.0], [92.4, 174.0], [92.5, 175.0], [92.6, 176.0], [92.7, 177.0], [92.8, 178.0], [92.9, 179.0], [93.0, 180.0], [93.1, 181.0], [93.2, 182.0], [93.3, 182.0], [93.4, 183.0], [93.5, 184.0], [93.6, 185.0], [93.7, 186.0], [93.8, 187.0], [93.9, 188.0], [94.0, 189.0], [94.1, 191.0], [94.2, 192.0], [94.3, 193.0], [94.4, 194.0], [94.5, 195.0], [94.6, 197.0], [94.7, 198.0], [94.8, 199.0], [94.9, 201.0], [95.0, 202.0], [95.1, 203.0], [95.2, 205.0], [95.3, 207.0], [95.4, 208.0], [95.5, 209.0], [95.6, 211.0], [95.7, 213.0], [95.8, 214.0], [95.9, 215.0], [96.0, 217.0], [96.1, 219.0], [96.2, 220.0], [96.3, 222.0], [96.4, 224.0], [96.5, 226.0], [96.6, 228.0], [96.7, 230.0], [96.8, 232.0], [96.9, 234.0], [97.0, 236.0], [97.1, 238.0], [97.2, 241.0], [97.3, 244.0], [97.4, 247.0], [97.5, 249.0], [97.6, 252.0], [97.7, 255.0], [97.8, 258.0], [97.9, 261.0], [98.0, 265.0], [98.1, 269.0], [98.2, 272.0], [98.3, 277.0], [98.4, 283.0], [98.5, 289.0], [98.6, 297.0], [98.7, 304.0], [98.8, 313.0], [98.9, 324.0], [99.0, 336.0], [99.1, 348.0], [99.2, 360.0], [99.3, 377.0], [99.4, 394.0], [99.5, 414.0], [99.6, 438.0], [99.7, 484.0], [99.8, 621.0], [99.9, 1099.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 140150.0, "series": [{"data": [[0.0, 140150.0], [600.0, 52.0], [700.0, 59.0], [198200.0, 1.0], [800.0, 27.0], [900.0, 20.0], [1000.0, 47.0], [1100.0, 42.0], [1200.0, 16.0], [1300.0, 3.0], [1400.0, 4.0], [1500.0, 1.0], [1600.0, 4.0], [100.0, 39876.0], [1700.0, 2.0], [1800.0, 3.0], [1900.0, 5.0], [2000.0, 4.0], [2100.0, 5.0], [2200.0, 3.0], [2300.0, 8.0], [2400.0, 2.0], [2500.0, 5.0], [2600.0, 6.0], [3000.0, 31.0], [3100.0, 2.0], [200.0, 7263.0], [63000.0, 33.0], [63100.0, 2.0], [63600.0, 3.0], [63500.0, 2.0], [63700.0, 1.0], [64000.0, 1.0], [300.0, 1495.0], [400.0, 548.0], [500.0, 144.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 198200.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 81.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 189246.0, "series": [{"data": [[0.0, 189246.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 413.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 81.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 130.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 50.0, "minX": 1.62581364E12, "maxY": 300.0, "series": [{"data": [[1.6258143E12, 200.0], [1.6258146E12, 250.0], [1.62581364E12, 50.0], [1.62581394E12, 100.0], [1.62581424E12, 180.20185354924178], [1.62581406E12, 145.2280332135329], [1.62581436E12, 200.0], [1.62581466E12, 294.13922279463316], [1.6258137E12, 50.0], [1.625814E12, 100.0], [1.62581478E12, 300.0], [1.62581382E12, 65.45929887106355], [1.62581412E12, 150.0], [1.62581442E12, 211.0164820318839], [1.62581472E12, 300.0], [1.62581376E12, 50.0], [1.62581454E12, 250.0], [1.62581484E12, 294.3908879109499], [1.62581388E12, 100.0], [1.62581418E12, 150.0], [1.62581448E12, 250.0]], "isOverall": false, "label": "bzm - Concurrency Thread Group-ThreadStarter", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.62581484E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 45.0, "minX": 1.0, "maxY": 63568.0, "series": [{"data": [[3.0, 363.0], [4.0, 396.0], [7.0, 367.0], [8.0, 228.0], [9.0, 136.0], [11.0, 210.5], [12.0, 290.0], [13.0, 371.0], [14.0, 387.0], [16.0, 262.5], [17.0, 364.0], [18.0, 383.0], [20.0, 230.0], [22.0, 268.5], [23.0, 200.0], [24.0, 276.0], [26.0, 262.5], [27.0, 276.0], [29.0, 216.0], [30.0, 314.0], [31.0, 140.0], [33.0, 200.0], [35.0, 167.0], [34.0, 96.0], [37.0, 163.0], [36.0, 245.0], [39.0, 241.0], [38.0, 109.0], [41.0, 129.0], [40.0, 108.0], [43.0, 153.0], [42.0, 77.0], [45.0, 72.0], [47.0, 219.0], [46.0, 132.5], [48.0, 304.0], [50.0, 60.891920699211106], [51.0, 83.5], [53.0, 76.0], [52.0, 78.0], [54.0, 47.833333333333336], [55.0, 174.0], [57.0, 233.0], [56.0, 72.0], [59.0, 164.0], [58.0, 63.0], [61.0, 154.0], [60.0, 161.0], [63.0, 222.0], [62.0, 223.0], [67.0, 198.0], [66.0, 152.0], [65.0, 247.0], [64.0, 197.0], [68.0, 136.0], [71.0, 182.0], [70.0, 216.0], [69.0, 194.0], [75.0, 137.0], [74.0, 204.0], [73.0, 178.0], [72.0, 192.0], [79.0, 195.0], [78.0, 168.0], [77.0, 185.0], [76.0, 184.0], [83.0, 153.0], [82.0, 149.0], [81.0, 179.0], [80.0, 108.0], [86.0, 93.5], [87.0, 137.0], [85.0, 178.0], [84.0, 141.0], [91.0, 212.5], [89.0, 143.0], [88.0, 154.0], [95.0, 149.0], [94.0, 209.0], [93.0, 156.0], [92.0, 151.0], [99.0, 271.0], [98.0, 209.5], [100.0, 58.271221977313], [103.0, 177.0], [101.0, 207.0], [105.0, 128.0], [104.0, 139.0], [109.0, 45.0], [111.0, 98.66666666666667], [110.0, 160.0], [108.0, 166.0], [114.0, 98.5], [115.0, 79.0], [113.0, 97.0], [112.0, 103.0], [118.0, 128.0], [117.0, 136.0], [116.0, 77.0], [123.0, 86.0], [122.0, 117.0], [121.0, 53.0], [120.0, 81.0], [124.0, 77.0], [127.0, 85.0], [126.0, 64.0], [125.0, 82.0], [132.0, 56.75], [133.0, 59.2], [135.0, 125.5], [131.0, 87.0], [130.0, 140.0], [128.0, 94.0], [140.0, 72.0], [143.0, 99.0], [142.0, 120.0], [141.0, 104.0], [139.0, 106.0], [138.0, 141.5], [137.0, 111.0], [136.0, 113.0], [150.0, 85.03671385640345], [151.0, 96.0], [149.0, 77.0], [148.0, 122.0], [147.0, 73.0], [146.0, 73.0], [145.0, 78.0], [144.0, 78.0], [152.0, 66.66666666666667], [157.0, 57.0], [158.0, 94.5], [159.0, 68.0], [156.0, 115.0], [155.0, 116.0], [154.0, 165.0], [153.0, 74.0], [165.0, 77.0], [167.0, 261.0], [166.0, 86.0], [164.0, 84.0], [163.0, 247.0], [162.0, 267.0], [161.0, 93.0], [160.0, 284.0], [171.0, 71.66666666666667], [175.0, 210.0], [174.0, 219.0], [173.0, 248.0], [172.0, 214.0], [170.0, 131.0], [169.0, 133.0], [168.0, 83.0], [183.0, 67.5], [182.0, 155.0], [181.0, 156.0], [179.0, 92.0], [177.0, 72.0], [185.0, 64.33333333333333], [191.0, 162.0], [190.0, 60.0], [189.0, 110.0], [192.0, 61.5], [198.0, 76.0], [199.0, 98.83333333333333], [196.0, 139.0], [195.0, 48.0], [200.0, 87.37465444094734], [201.0, 49.0], [204.0, 77.33333333333333], [207.0, 187.0], [205.0, 155.0], [210.0, 61.5], [211.0, 47.0], [219.0, 73.0], [223.0, 135.0], [222.0, 112.0], [221.0, 122.0], [229.0, 152.4], [228.0, 150.0], [236.0, 186.10526315789477], [237.0, 313.0], [233.0, 232.66666666666666], [247.0, 150.0], [246.0, 147.0], [245.0, 204.0], [243.0, 220.0], [242.0, 132.33333333333334], [241.0, 179.0], [240.0, 197.0], [250.0, 128.2812584818596], [251.0, 131.0], [252.0, 97.0], [255.0, 139.0], [254.0, 140.0], [253.0, 116.0], [248.0, 145.0], [270.0, 147.0], [256.0, 145.5], [257.0, 92.0], [259.0, 104.0], [258.0, 214.0], [260.0, 48.0], [261.0, 87.0], [262.0, 131.5], [263.0, 172.0], [264.0, 65.5], [265.0, 129.0], [267.0, 162.0], [266.0, 163.0], [269.0, 139.0], [268.0, 156.0], [286.0, 102.0], [272.0, 45.0], [273.0, 63.0], [287.0, 82.06666666666668], [284.0, 119.0], [275.0, 141.0], [274.0, 142.0], [282.0, 108.5], [281.0, 148.0], [280.0, 87.0], [279.0, 88.0], [277.0, 101.0], [276.0, 144.0], [288.0, 67.71428571428571], [289.0, 80.625], [294.0, 72.5], [300.0, 121.3376623376623], [298.0, 93.66666666666667], [295.0, 98.0], [292.0, 126.0], [291.0, 95.33333333333333], [1.0, 63568.0]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[215.0756517617343, 102.33602464844515]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 300.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 41821.01666666667, "minX": 1.62581364E12, "maxY": 727842.4166666666, "series": [{"data": [[1.6258143E12, 502575.35], [1.6258146E12, 620149.5166666667], [1.62581364E12, 61269.666666666664], [1.62581394E12, 255806.93333333332], [1.62581424E12, 446930.3], [1.62581406E12, 367223.31666666665], [1.62581436E12, 497297.61666666664], [1.62581466E12, 715531.6166666667], [1.6258137E12, 129916.0], [1.625814E12, 253909.66666666666], [1.62581478E12, 727842.4166666666], [1.62581382E12, 153186.0], [1.62581412E12, 368354.1666666667], [1.62581442E12, 505252.5833333333], [1.62581472E12, 722524.6166666667], [1.62581376E12, 130036.0], [1.62581454E12, 602584.3333333334], [1.62581484E12, 351826.31666666665], [1.62581388E12, 255736.16666666666], [1.62581418E12, 380087.98333333334], [1.62581448E12, 594134.9833333333]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.6258143E12, 342572.61666666664], [1.6258146E12, 422491.7833333333], [1.62581364E12, 41821.01666666667], [1.62581394E12, 174419.78333333333], [1.62581424E12, 304629.7], [1.62581406E12, 250305.81666666668], [1.62581436E12, 338911.75], [1.62581466E12, 487705.31666666665], [1.6258137E12, 88543.95], [1.625814E12, 169517.88333333333], [1.62581478E12, 496175.05], [1.62581382E12, 104428.5], [1.62581412E12, 251081.28333333333], [1.62581442E12, 344310.0333333333], [1.62581472E12, 492483.06666666665], [1.62581376E12, 88668.05], [1.62581454E12, 410547.3], [1.62581484E12, 239664.31666666668], [1.62581388E12, 174326.8], [1.62581418E12, 259054.68333333332], [1.62581448E12, 404931.93333333335]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.62581484E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 48.17876200640358, "minX": 1.62581364E12, "maxY": 136.7715133531157, "series": [{"data": [[1.6258143E12, 81.26405867970647], [1.6258146E12, 112.4239999999998], [1.62581364E12, 136.7715133531157], [1.62581394E12, 48.17876200640358], [1.62581424E12, 68.84265200122168], [1.62581406E12, 83.38753253191213], [1.62581436E12, 96.77075134986683], [1.62581466E12, 116.03167334478158], [1.6258137E12, 49.467764540995084], [1.625814E12, 73.83684494867639], [1.62581478E12, 123.38240810202572], [1.62581382E12, 50.64587046939987], [1.62581412E12, 86.67836401828754], [1.62581442E12, 121.27343961091611], [1.62581472E12, 124.12993638596667], [1.62581376E12, 49.20083974807547], [1.62581454E12, 129.60592100294622], [1.62581484E12, 122.61985503494698], [1.62581388E12, 53.11372130272281], [1.62581418E12, 91.97078893810571], [1.62581448E12, 132.56798161623865]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.62581484E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 48.119174670935784, "minX": 1.62581364E12, "maxY": 136.68842729970342, "series": [{"data": [[1.6258143E12, 75.48754867336808], [1.6258146E12, 79.96917431192627], [1.62581364E12, 136.68842729970342], [1.62581394E12, 48.119174670935784], [1.62581424E12, 68.78073123536002], [1.62581406E12, 58.74928739620774], [1.62581436E12, 79.39315457124543], [1.62581466E12, 103.92272467086404], [1.6258137E12, 49.378766643307614], [1.625814E12, 50.28543129839738], [1.62581478E12, 111.34639909977548], [1.62581382E12, 50.601010101010075], [1.62581412E12, 86.62041270233536], [1.62581442E12, 92.79374943708875], [1.62581472E12, 112.04547458587909], [1.62581376E12, 49.10951714485659], [1.62581454E12, 91.42934823653782], [1.62581484E12, 114.29614289412366], [1.62581388E12, 53.057839473215886], [1.62581418E12, 69.2583502933077], [1.62581448E12, 118.00681731137459]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.62581484E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 28.83511205976517, "minX": 1.62581364E12, "maxY": 113.25296735905036, "series": [{"data": [[1.6258143E12, 50.07117631078536], [1.6258146E12, 81.24051376146814], [1.62581364E12, 113.25296735905036], [1.62581394E12, 28.83511205976517], [1.62581424E12, 40.36918219777994], [1.62581406E12, 60.66365101003847], [1.62581436E12, 65.69845337238011], [1.62581466E12, 83.67525281434811], [1.6258137E12, 29.681149264190633], [1.625814E12, 52.95389879344509], [1.62581478E12, 88.63209552388068], [1.62581382E12, 30.517528223410608], [1.62581412E12, 52.012479920919155], [1.62581442E12, 87.01341979645136], [1.62581472E12, 91.51898973357683], [1.62581376E12, 29.304058782365296], [1.62581454E12, 93.93799561966586], [1.62581484E12, 90.76067822935582], [1.62581388E12, 30.546182594767746], [1.62581418E12, 63.613432299772604], [1.62581448E12, 86.1319034852545]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.62581484E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 28.0, "minX": 1.62581364E12, "maxY": 3104.0, "series": [{"data": [[1.6258143E12, 3050.0], [1.6258146E12, 1124.0], [1.62581364E12, 2673.0], [1.62581394E12, 3037.0], [1.62581424E12, 3067.0], [1.62581406E12, 484.0], [1.62581436E12, 3104.0], [1.62581466E12, 565.0], [1.6258137E12, 418.0], [1.625814E12, 3049.0], [1.62581478E12, 1194.0], [1.62581382E12, 3048.0], [1.62581412E12, 3038.0], [1.62581442E12, 3104.0], [1.62581472E12, 745.0], [1.62581376E12, 410.0], [1.62581454E12, 1205.0], [1.62581484E12, 1358.0], [1.62581388E12, 3056.0], [1.62581418E12, 1208.0], [1.62581448E12, 1141.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.6258143E12, 123.70000000000073], [1.6258146E12, 135.0], [1.62581364E12, 104.10000000000014], [1.62581394E12, 63.0], [1.62581424E12, 98.0], [1.62581406E12, 89.0], [1.62581436E12, 127.0], [1.62581466E12, 180.0], [1.6258137E12, 68.5], [1.625814E12, 70.0], [1.62581478E12, 191.0], [1.62581382E12, 70.0], [1.62581412E12, 162.0], [1.62581442E12, 139.0], [1.62581472E12, 192.0], [1.62581376E12, 68.0], [1.62581454E12, 166.0], [1.62581484E12, 194.0], [1.62581388E12, 71.0], [1.62581418E12, 112.0], [1.62581448E12, 233.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.6258143E12, 235.5699999999997], [1.6258146E12, 265.8099999999995], [1.62581364E12, 2406.6399999999994], [1.62581394E12, 117.53999999999905], [1.62581424E12, 208.0], [1.62581406E12, 235.3099999999995], [1.62581436E12, 268.5], [1.62581466E12, 331.0], [1.6258137E12, 157.0], [1.625814E12, 129.0500000000011], [1.62581478E12, 303.0], [1.62581382E12, 241.0], [1.62581412E12, 285.0], [1.62581442E12, 792.0100000000002], [1.62581472E12, 333.5], [1.62581376E12, 165.22999999999956], [1.62581454E12, 274.65999999999985], [1.62581484E12, 326.7399999999998], [1.62581388E12, 148.80000000000018], [1.62581418E12, 283.0], [1.62581448E12, 476.0]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.6258143E12, 154.0], [1.6258146E12, 171.0], [1.62581364E12, 179.0], [1.62581394E12, 74.0], [1.62581424E12, 125.0], [1.62581406E12, 123.0], [1.62581436E12, 160.0], [1.62581466E12, 217.0], [1.6258137E12, 95.0], [1.625814E12, 85.0], [1.62581478E12, 228.0], [1.62581382E12, 95.0], [1.62581412E12, 199.0], [1.62581442E12, 225.0], [1.62581472E12, 231.0], [1.62581376E12, 85.0], [1.62581454E12, 204.0], [1.62581484E12, 244.0], [1.62581388E12, 87.0], [1.62581418E12, 164.0], [1.62581448E12, 313.0]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.6258143E12, 31.0], [1.6258146E12, 29.0], [1.62581364E12, 32.0], [1.62581394E12, 30.0], [1.62581424E12, 29.0], [1.62581406E12, 28.0], [1.62581436E12, 31.0], [1.62581466E12, 30.0], [1.6258137E12, 31.0], [1.625814E12, 29.0], [1.62581478E12, 30.0], [1.62581382E12, 28.0], [1.62581412E12, 31.0], [1.62581442E12, 30.0], [1.62581472E12, 30.0], [1.62581376E12, 29.0], [1.62581454E12, 30.0], [1.62581484E12, 30.0], [1.62581388E12, 29.0], [1.62581418E12, 29.0], [1.62581448E12, 32.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.6258143E12, 61.0], [1.6258146E12, 66.0], [1.62581364E12, 50.0], [1.62581394E12, 43.0], [1.62581424E12, 56.0], [1.62581406E12, 47.0], [1.62581436E12, 63.0], [1.62581466E12, 90.0], [1.6258137E12, 42.0], [1.625814E12, 44.0], [1.62581478E12, 98.0], [1.62581382E12, 41.0], [1.62581412E12, 65.0], [1.62581442E12, 60.0], [1.62581472E12, 96.0], [1.62581376E12, 42.0], [1.62581454E12, 74.0], [1.62581484E12, 101.0], [1.62581388E12, 44.0], [1.62581418E12, 53.5], [1.62581448E12, 85.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.62581484E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 27.0, "minX": 1.0, "maxY": 198219.0, "series": [{"data": [[2.0, 1585.5], [31.0, 47.0], [32.0, 283.5], [39.0, 46.0], [38.0, 38.0], [41.0, 45.0], [43.0, 43.0], [42.0, 43.5], [44.0, 46.0], [45.0, 39.0], [46.0, 45.0], [47.0, 40.0], [48.0, 41.0], [49.0, 42.0], [50.0, 42.0], [70.0, 60.0], [78.0, 60.5], [76.0, 43.0], [83.0, 46.0], [81.0, 54.0], [84.0, 43.0], [87.0, 41.0], [86.0, 44.0], [85.0, 43.0], [88.0, 45.0], [91.0, 43.0], [89.0, 47.0], [90.0, 45.0], [95.0, 43.0], [94.0, 45.0], [93.0, 43.0], [92.0, 44.0], [98.0, 44.0], [99.0, 44.0], [97.0, 43.0], [96.0, 43.0], [100.0, 76.5], [109.0, 53.0], [115.0, 39.0], [113.0, 56.0], [112.0, 191.0], [119.0, 88.0], [117.0, 69.0], [118.0, 62.0], [122.0, 100.5], [120.0, 77.5], [121.0, 85.0], [124.0, 198.0], [127.0, 62.0], [131.0, 51.0], [132.0, 60.0], [129.0, 46.0], [133.0, 51.0], [128.0, 60.5], [135.0, 65.0], [130.0, 51.0], [134.0, 52.0], [143.0, 56.0], [138.0, 52.0], [142.0, 63.0], [140.0, 51.0], [139.0, 52.0], [137.0, 50.0], [141.0, 63.0], [136.0, 52.0], [146.0, 57.0], [144.0, 51.0], [148.0, 51.0], [145.0, 53.0], [149.0, 52.0], [150.0, 48.0], [147.0, 52.0], [151.0, 60.5], [154.0, 56.0], [157.0, 74.0], [156.0, 73.0], [166.0, 56.0], [163.0, 52.0], [165.0, 74.0], [161.0, 59.0], [173.0, 59.0], [169.0, 67.0], [174.0, 60.0], [172.0, 61.0], [170.0, 63.0], [168.0, 63.0], [171.0, 57.0], [175.0, 70.0], [183.0, 64.0], [180.0, 60.0], [178.0, 58.0], [179.0, 59.0], [176.0, 63.0], [177.0, 60.0], [182.0, 57.0], [181.0, 57.0], [186.0, 57.0], [187.0, 62.5], [184.0, 53.0], [190.0, 55.0], [188.0, 59.0], [189.0, 59.0], [191.0, 64.0], [185.0, 70.0], [196.0, 66.0], [192.0, 78.0], [195.0, 59.0], [199.0, 64.5], [194.0, 69.0], [197.0, 78.0], [193.0, 81.0], [198.0, 90.5], [202.0, 696.0], [204.0, 66.0], [200.0, 95.0], [203.0, 73.0], [206.0, 84.5], [207.0, 89.0], [201.0, 70.5], [214.0, 72.0], [209.0, 61.0], [211.0, 74.0], [215.0, 72.0], [212.0, 64.0], [210.0, 62.0], [213.0, 62.0], [208.0, 79.0], [219.0, 73.0], [221.0, 66.0], [223.0, 116.5], [218.0, 150.5], [220.0, 71.0], [216.0, 71.0], [222.0, 88.0], [217.0, 59.0], [231.0, 67.0], [230.0, 69.0], [228.0, 86.5], [224.0, 67.0], [227.0, 76.0], [225.0, 69.0], [229.0, 65.0], [226.0, 67.0], [238.0, 87.0], [232.0, 71.0], [237.0, 78.0], [236.0, 78.0], [234.0, 73.0], [233.0, 68.0], [235.0, 63.0], [239.0, 81.0], [241.0, 98.0], [240.0, 86.0], [245.0, 171.0], [242.0, 90.0], [243.0, 89.0], [246.0, 117.0], [244.0, 77.0], [247.0, 75.0], [254.0, 77.0], [249.0, 106.0], [252.0, 81.0], [253.0, 113.0], [255.0, 98.0], [270.0, 98.0], [265.0, 97.0], [261.0, 106.0], [264.0, 93.0], [271.0, 75.0], [269.0, 90.0], [262.0, 77.5], [266.0, 79.0], [267.0, 98.0], [260.0, 98.0], [259.0, 134.0], [263.0, 69.0], [257.0, 74.0], [258.0, 97.0], [256.0, 120.0], [287.0, 140.0], [277.0, 102.0], [276.0, 92.0], [272.0, 98.0], [278.0, 158.0], [279.0, 121.0], [283.0, 81.0], [282.0, 108.0], [281.0, 116.0], [273.0, 82.0], [275.0, 100.0], [274.0, 88.0], [284.0, 109.0], [286.0, 107.0], [285.0, 94.0], [280.0, 115.5], [289.0, 102.0], [288.0, 155.5], [291.0, 92.0], [292.0, 80.5], [290.0, 124.5], [295.0, 140.0], [294.0, 102.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[85.0, 30.0], [93.0, 27.0], [95.0, 63002.5], [131.0, 198219.0], [142.0, 63032.5], [149.0, 63053.0], [156.0, 63084.0], [182.0, 63039.0], [183.0, 63070.0], [179.0, 63074.0], [188.0, 63057.0], [195.0, 63041.0], [210.0, 63093.0], [221.0, 63082.5], [219.0, 63067.0], [225.0, 63052.0], [231.0, 63059.0], [226.0, 63110.0], [229.0, 63693.0], [234.0, 63066.0], [238.0, 63086.0], [237.0, 63547.0], [240.0, 63061.0], [247.0, 63916.5], [270.0, 63078.0], [266.0, 63157.0], [1.0, 63568.0], [276.0, 63687.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 295.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 0.0, "minX": 1.0, "maxY": 1585.5, "series": [{"data": [[2.0, 1585.5], [31.0, 47.0], [32.0, 283.5], [39.0, 46.0], [38.0, 38.0], [41.0, 44.0], [43.0, 43.0], [42.0, 43.0], [44.0, 45.5], [45.0, 39.0], [46.0, 45.0], [47.0, 40.0], [48.0, 41.0], [49.0, 42.0], [50.0, 42.0], [70.0, 60.0], [78.0, 60.5], [76.0, 43.0], [83.0, 46.0], [81.0, 54.0], [84.0, 43.0], [87.0, 41.0], [86.0, 43.5], [85.0, 43.0], [88.0, 45.0], [91.0, 42.0], [89.0, 46.0], [90.0, 45.0], [95.0, 43.0], [94.0, 45.0], [93.0, 43.0], [92.0, 44.0], [98.0, 44.0], [99.0, 44.0], [97.0, 43.0], [96.0, 43.0], [100.0, 76.5], [109.0, 53.0], [115.0, 39.0], [113.0, 56.0], [112.0, 191.0], [119.0, 88.0], [117.0, 69.0], [118.0, 62.0], [122.0, 100.5], [120.0, 77.5], [121.0, 85.0], [124.0, 198.0], [127.0, 62.0], [131.0, 51.0], [132.0, 60.0], [129.0, 46.0], [133.0, 51.0], [128.0, 60.0], [135.0, 65.0], [130.0, 51.0], [134.0, 52.0], [143.0, 56.0], [138.0, 51.0], [142.0, 63.0], [140.0, 51.0], [139.0, 52.0], [137.0, 50.0], [141.0, 63.0], [136.0, 52.0], [146.0, 57.0], [144.0, 51.0], [148.0, 51.0], [145.0, 53.0], [149.0, 52.0], [150.0, 48.0], [147.0, 52.0], [151.0, 60.5], [154.0, 56.0], [157.0, 74.0], [156.0, 73.0], [166.0, 56.0], [163.0, 52.0], [165.0, 74.0], [161.0, 59.0], [173.0, 59.0], [169.0, 67.0], [174.0, 60.0], [172.0, 61.0], [170.0, 63.0], [168.0, 63.0], [171.0, 57.0], [175.0, 69.0], [183.0, 64.0], [180.0, 60.0], [178.0, 58.0], [179.0, 59.0], [176.0, 63.0], [177.0, 60.0], [182.0, 57.0], [181.0, 57.0], [186.0, 57.0], [187.0, 62.0], [184.0, 53.0], [190.0, 55.0], [188.0, 59.0], [189.0, 59.0], [191.0, 64.0], [185.0, 70.0], [196.0, 65.0], [192.0, 77.5], [195.0, 59.0], [199.0, 64.5], [194.0, 69.0], [197.0, 78.0], [193.0, 81.0], [198.0, 90.0], [202.0, 696.0], [204.0, 66.0], [200.0, 95.0], [203.0, 73.0], [206.0, 84.0], [207.0, 89.0], [201.0, 70.5], [214.0, 72.0], [209.0, 61.0], [211.0, 74.0], [215.0, 72.0], [212.0, 64.0], [210.0, 61.5], [213.0, 62.0], [208.0, 79.0], [219.0, 73.0], [221.0, 66.0], [223.0, 116.5], [218.0, 150.5], [220.0, 71.0], [216.0, 71.0], [222.0, 88.0], [217.0, 59.0], [231.0, 67.0], [230.0, 69.0], [228.0, 86.0], [224.0, 67.0], [227.0, 76.0], [225.0, 69.0], [229.0, 65.0], [226.0, 67.0], [238.0, 87.0], [232.0, 71.0], [237.0, 78.0], [236.0, 78.0], [234.0, 73.0], [233.0, 68.0], [235.0, 63.0], [239.0, 81.0], [241.0, 98.0], [240.0, 86.0], [245.0, 171.0], [242.0, 90.0], [243.0, 89.0], [246.0, 117.0], [244.0, 76.5], [247.0, 75.0], [254.0, 77.0], [249.0, 106.0], [252.0, 81.0], [253.0, 113.0], [255.0, 98.0], [270.0, 98.0], [265.0, 97.0], [261.0, 106.0], [264.0, 93.0], [271.0, 75.0], [269.0, 90.0], [262.0, 77.0], [266.0, 79.0], [267.0, 98.0], [260.0, 98.0], [259.0, 134.0], [263.0, 69.0], [257.0, 74.0], [258.0, 97.0], [256.0, 120.0], [287.0, 140.0], [277.0, 102.0], [276.0, 92.0], [272.0, 98.0], [278.0, 158.0], [279.0, 121.0], [283.0, 81.0], [282.0, 107.5], [281.0, 116.0], [273.0, 82.0], [275.0, 100.0], [274.0, 88.0], [284.0, 109.0], [286.0, 107.0], [285.0, 94.0], [280.0, 115.5], [289.0, 102.0], [288.0, 155.5], [291.0, 92.0], [292.0, 80.5], [290.0, 124.5], [295.0, 140.0], [294.0, 101.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[85.0, 0.0], [93.0, 0.0], [95.0, 0.0], [131.0, 0.0], [142.0, 0.0], [149.0, 0.0], [156.0, 0.0], [182.0, 0.0], [183.0, 0.0], [179.0, 0.0], [188.0, 0.0], [195.0, 0.0], [210.0, 0.0], [221.0, 0.0], [219.0, 0.0], [225.0, 0.0], [231.0, 0.0], [226.0, 0.0], [229.0, 0.0], [234.0, 0.0], [238.0, 0.0], [237.0, 0.0], [240.0, 0.0], [247.0, 0.0], [270.0, 0.0], [266.0, 0.0], [1.0, 0.0], [276.0, 0.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 295.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 22.533333333333335, "minX": 1.62581364E12, "maxY": 266.45, "series": [{"data": [[1.6258143E12, 184.58333333333334], [1.6258146E12, 226.73333333333332], [1.62581364E12, 22.533333333333335], [1.62581394E12, 93.83333333333333], [1.62581424E12, 163.63333333333333], [1.62581406E12, 134.36666666666667], [1.62581436E12, 181.8], [1.62581466E12, 262.6], [1.6258137E12, 47.5], [1.625814E12, 92.51666666666667], [1.62581478E12, 266.45], [1.62581382E12, 56.06666666666667], [1.62581412E12, 134.95], [1.62581442E12, 184.86666666666667], [1.62581472E12, 264.51666666666665], [1.62581376E12, 47.666666666666664], [1.62581454E12, 220.96666666666667], [1.62581484E12, 128.36666666666667], [1.62581388E12, 93.75], [1.62581418E12, 139.18333333333334], [1.62581448E12, 217.61666666666667]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.62581484E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.62581364E12, "maxY": 266.55, "series": [{"data": [[1.625814E12, 1.45]], "isOverall": false, "label": "Non HTTP response code: javax.net.ssl.SSLException", "isController": false}, {"data": [[1.6258143E12, 184.03333333333333], [1.6258146E12, 226.96666666666667], [1.62581364E12, 22.466666666666665], [1.62581394E12, 93.7], [1.62581424E12, 163.65], [1.62581406E12, 134.46666666666667], [1.62581436E12, 182.06666666666666], [1.62581466E12, 262.0], [1.6258137E12, 47.56666666666667], [1.625814E12, 91.06666666666666], [1.62581478E12, 266.55], [1.62581382E12, 56.1], [1.62581412E12, 134.88333333333333], [1.62581442E12, 184.96666666666667], [1.62581472E12, 264.56666666666666], [1.62581376E12, 47.63333333333333], [1.62581454E12, 220.55], [1.62581484E12, 128.75], [1.62581388E12, 93.65], [1.62581418E12, 139.16666666666666], [1.62581448E12, 217.53333333333333]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.6258143E12, 0.016666666666666666], [1.6258146E12, 0.11666666666666667], [1.62581406E12, 0.016666666666666666], [1.62581436E12, 0.05], [1.62581466E12, 0.05], [1.625814E12, 0.03333333333333333], [1.62581478E12, 0.05], [1.62581442E12, 0.08333333333333333], [1.62581472E12, 0.05], [1.62581454E12, 0.13333333333333333], [1.62581484E12, 0.016666666666666666], [1.62581418E12, 0.05], [1.62581448E12, 0.05]], "isOverall": false, "label": "Non HTTP response code: org.apache.http.conn.HttpHostConnectException", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.62581484E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.62581364E12, "maxY": 266.55, "series": [{"data": [[1.6258143E12, 184.03333333333333], [1.6258146E12, 226.96666666666667], [1.62581364E12, 22.466666666666665], [1.62581394E12, 93.7], [1.62581424E12, 163.65], [1.62581406E12, 134.46666666666667], [1.62581436E12, 182.06666666666666], [1.62581466E12, 262.0], [1.6258137E12, 47.56666666666667], [1.625814E12, 91.06666666666666], [1.62581478E12, 266.55], [1.62581382E12, 56.1], [1.62581412E12, 134.88333333333333], [1.62581442E12, 184.96666666666667], [1.62581472E12, 264.56666666666666], [1.62581376E12, 47.63333333333333], [1.62581454E12, 220.55], [1.62581484E12, 128.75], [1.62581388E12, 93.65], [1.62581418E12, 139.16666666666666], [1.62581448E12, 217.53333333333333]], "isOverall": false, "label": "HTTP Request-success", "isController": false}, {"data": [[1.6258143E12, 0.016666666666666666], [1.6258146E12, 0.11666666666666667], [1.62581406E12, 0.016666666666666666], [1.62581436E12, 0.05], [1.62581466E12, 0.05], [1.625814E12, 1.4833333333333334], [1.62581478E12, 0.05], [1.62581442E12, 0.08333333333333333], [1.62581472E12, 0.05], [1.62581454E12, 0.13333333333333333], [1.62581484E12, 0.016666666666666666], [1.62581418E12, 0.05], [1.62581448E12, 0.05]], "isOverall": false, "label": "HTTP Request-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.62581484E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.016666666666666666, "minX": 1.62581364E12, "maxY": 266.55, "series": [{"data": [[1.6258143E12, 184.03333333333333], [1.6258146E12, 226.96666666666667], [1.62581364E12, 22.466666666666665], [1.62581394E12, 93.7], [1.62581424E12, 163.65], [1.62581406E12, 134.46666666666667], [1.62581436E12, 182.06666666666666], [1.62581466E12, 262.0], [1.6258137E12, 47.56666666666667], [1.625814E12, 91.06666666666666], [1.62581478E12, 266.55], [1.62581382E12, 56.1], [1.62581412E12, 134.88333333333333], [1.62581442E12, 184.96666666666667], [1.62581472E12, 264.56666666666666], [1.62581376E12, 47.63333333333333], [1.62581454E12, 220.55], [1.62581484E12, 128.75], [1.62581388E12, 93.65], [1.62581418E12, 139.16666666666666], [1.62581448E12, 217.53333333333333]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.6258143E12, 0.016666666666666666], [1.6258146E12, 0.11666666666666667], [1.62581406E12, 0.016666666666666666], [1.62581436E12, 0.05], [1.62581466E12, 0.05], [1.625814E12, 1.4833333333333334], [1.62581478E12, 0.05], [1.62581442E12, 0.08333333333333333], [1.62581472E12, 0.05], [1.62581454E12, 0.13333333333333333], [1.62581484E12, 0.016666666666666666], [1.62581418E12, 0.05], [1.62581448E12, 0.05]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.62581484E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

