/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 138.0, "minX": 0.0, "maxY": 14760.0, "series": [{"data": [[0.0, 138.0], [0.1, 178.0], [0.2, 191.0], [0.3, 202.0], [0.4, 214.0], [0.5, 218.0], [0.6, 226.0], [0.7, 234.0], [0.8, 241.0], [0.9, 249.0], [1.0, 251.0], [1.1, 256.0], [1.2, 260.0], [1.3, 264.0], [1.4, 267.0], [1.5, 273.0], [1.6, 277.0], [1.7, 279.0], [1.8, 284.0], [1.9, 288.0], [2.0, 292.0], [2.1, 295.0], [2.2, 298.0], [2.3, 300.0], [2.4, 304.0], [2.5, 306.0], [2.6, 308.0], [2.7, 311.0], [2.8, 313.0], [2.9, 314.0], [3.0, 316.0], [3.1, 322.0], [3.2, 325.0], [3.3, 330.0], [3.4, 333.0], [3.5, 335.0], [3.6, 337.0], [3.7, 339.0], [3.8, 342.0], [3.9, 345.0], [4.0, 347.0], [4.1, 350.0], [4.2, 353.0], [4.3, 355.0], [4.4, 357.0], [4.5, 360.0], [4.6, 363.0], [4.7, 366.0], [4.8, 368.0], [4.9, 371.0], [5.0, 375.0], [5.1, 377.0], [5.2, 378.0], [5.3, 380.0], [5.4, 382.0], [5.5, 384.0], [5.6, 387.0], [5.7, 389.0], [5.8, 391.0], [5.9, 394.0], [6.0, 395.0], [6.1, 397.0], [6.2, 401.0], [6.3, 403.0], [6.4, 406.0], [6.5, 408.0], [6.6, 411.0], [6.7, 412.0], [6.8, 416.0], [6.9, 418.0], [7.0, 420.0], [7.1, 422.0], [7.2, 424.0], [7.3, 425.0], [7.4, 428.0], [7.5, 431.0], [7.6, 434.0], [7.7, 436.0], [7.8, 437.0], [7.9, 439.0], [8.0, 442.0], [8.1, 444.0], [8.2, 446.0], [8.3, 448.0], [8.4, 450.0], [8.5, 451.0], [8.6, 454.0], [8.7, 457.0], [8.8, 459.0], [8.9, 461.0], [9.0, 463.0], [9.1, 465.0], [9.2, 467.0], [9.3, 469.0], [9.4, 470.0], [9.5, 473.0], [9.6, 475.0], [9.7, 476.0], [9.8, 478.0], [9.9, 480.0], [10.0, 482.0], [10.1, 485.0], [10.2, 487.0], [10.3, 489.0], [10.4, 491.0], [10.5, 492.0], [10.6, 495.0], [10.7, 496.0], [10.8, 498.0], [10.9, 501.0], [11.0, 503.0], [11.1, 505.0], [11.2, 506.0], [11.3, 508.0], [11.4, 510.0], [11.5, 513.0], [11.6, 514.0], [11.7, 516.0], [11.8, 518.0], [11.9, 520.0], [12.0, 523.0], [12.1, 525.0], [12.2, 528.0], [12.3, 530.0], [12.4, 532.0], [12.5, 535.0], [12.6, 537.0], [12.7, 540.0], [12.8, 541.0], [12.9, 543.0], [13.0, 547.0], [13.1, 550.0], [13.2, 551.0], [13.3, 552.0], [13.4, 554.0], [13.5, 556.0], [13.6, 559.0], [13.7, 560.0], [13.8, 562.0], [13.9, 565.0], [14.0, 567.0], [14.1, 570.0], [14.2, 572.0], [14.3, 574.0], [14.4, 577.0], [14.5, 580.0], [14.6, 583.0], [14.7, 584.0], [14.8, 586.0], [14.9, 588.0], [15.0, 590.0], [15.1, 594.0], [15.2, 596.0], [15.3, 599.0], [15.4, 601.0], [15.5, 604.0], [15.6, 608.0], [15.7, 611.0], [15.8, 612.0], [15.9, 615.0], [16.0, 618.0], [16.1, 622.0], [16.2, 624.0], [16.3, 626.0], [16.4, 629.0], [16.5, 631.0], [16.6, 635.0], [16.7, 637.0], [16.8, 640.0], [16.9, 644.0], [17.0, 648.0], [17.1, 651.0], [17.2, 654.0], [17.3, 657.0], [17.4, 658.0], [17.5, 661.0], [17.6, 665.0], [17.7, 667.0], [17.8, 671.0], [17.9, 674.0], [18.0, 676.0], [18.1, 678.0], [18.2, 681.0], [18.3, 684.0], [18.4, 687.0], [18.5, 691.0], [18.6, 693.0], [18.7, 695.0], [18.8, 697.0], [18.9, 699.0], [19.0, 702.0], [19.1, 707.0], [19.2, 709.0], [19.3, 712.0], [19.4, 715.0], [19.5, 717.0], [19.6, 721.0], [19.7, 724.0], [19.8, 729.0], [19.9, 731.0], [20.0, 735.0], [20.1, 739.0], [20.2, 743.0], [20.3, 747.0], [20.4, 750.0], [20.5, 752.0], [20.6, 757.0], [20.7, 759.0], [20.8, 765.0], [20.9, 769.0], [21.0, 773.0], [21.1, 778.0], [21.2, 781.0], [21.3, 784.0], [21.4, 788.0], [21.5, 793.0], [21.6, 796.0], [21.7, 800.0], [21.8, 802.0], [21.9, 805.0], [22.0, 809.0], [22.1, 813.0], [22.2, 817.0], [22.3, 820.0], [22.4, 823.0], [22.5, 826.0], [22.6, 832.0], [22.7, 836.0], [22.8, 840.0], [22.9, 844.0], [23.0, 848.0], [23.1, 851.0], [23.2, 855.0], [23.3, 860.0], [23.4, 865.0], [23.5, 869.0], [23.6, 871.0], [23.7, 875.0], [23.8, 878.0], [23.9, 881.0], [24.0, 884.0], [24.1, 889.0], [24.2, 893.0], [24.3, 896.0], [24.4, 898.0], [24.5, 902.0], [24.6, 906.0], [24.7, 909.0], [24.8, 912.0], [24.9, 914.0], [25.0, 919.0], [25.1, 921.0], [25.2, 923.0], [25.3, 929.0], [25.4, 933.0], [25.5, 938.0], [25.6, 941.0], [25.7, 944.0], [25.8, 948.0], [25.9, 955.0], [26.0, 960.0], [26.1, 962.0], [26.2, 966.0], [26.3, 968.0], [26.4, 971.0], [26.5, 975.0], [26.6, 978.0], [26.7, 982.0], [26.8, 986.0], [26.9, 989.0], [27.0, 992.0], [27.1, 995.0], [27.2, 1001.0], [27.3, 1005.0], [27.4, 1008.0], [27.5, 1012.0], [27.6, 1014.0], [27.7, 1020.0], [27.8, 1028.0], [27.9, 1032.0], [28.0, 1036.0], [28.1, 1040.0], [28.2, 1044.0], [28.3, 1048.0], [28.4, 1055.0], [28.5, 1059.0], [28.6, 1062.0], [28.7, 1065.0], [28.8, 1069.0], [28.9, 1071.0], [29.0, 1075.0], [29.1, 1080.0], [29.2, 1081.0], [29.3, 1086.0], [29.4, 1090.0], [29.5, 1092.0], [29.6, 1095.0], [29.7, 1097.0], [29.8, 1100.0], [29.9, 1104.0], [30.0, 1108.0], [30.1, 1110.0], [30.2, 1115.0], [30.3, 1119.0], [30.4, 1121.0], [30.5, 1124.0], [30.6, 1128.0], [30.7, 1133.0], [30.8, 1135.0], [30.9, 1140.0], [31.0, 1144.0], [31.1, 1148.0], [31.2, 1153.0], [31.3, 1158.0], [31.4, 1163.0], [31.5, 1169.0], [31.6, 1171.0], [31.7, 1177.0], [31.8, 1181.0], [31.9, 1185.0], [32.0, 1187.0], [32.1, 1191.0], [32.2, 1195.0], [32.3, 1199.0], [32.4, 1203.0], [32.5, 1207.0], [32.6, 1213.0], [32.7, 1216.0], [32.8, 1223.0], [32.9, 1228.0], [33.0, 1233.0], [33.1, 1236.0], [33.2, 1238.0], [33.3, 1242.0], [33.4, 1246.0], [33.5, 1249.0], [33.6, 1253.0], [33.7, 1257.0], [33.8, 1263.0], [33.9, 1266.0], [34.0, 1272.0], [34.1, 1275.0], [34.2, 1278.0], [34.3, 1280.0], [34.4, 1285.0], [34.5, 1290.0], [34.6, 1295.0], [34.7, 1302.0], [34.8, 1309.0], [34.9, 1313.0], [35.0, 1317.0], [35.1, 1321.0], [35.2, 1326.0], [35.3, 1330.0], [35.4, 1332.0], [35.5, 1337.0], [35.6, 1342.0], [35.7, 1346.0], [35.8, 1358.0], [35.9, 1361.0], [36.0, 1366.0], [36.1, 1371.0], [36.2, 1380.0], [36.3, 1385.0], [36.4, 1392.0], [36.5, 1398.0], [36.6, 1403.0], [36.7, 1406.0], [36.8, 1414.0], [36.9, 1418.0], [37.0, 1425.0], [37.1, 1431.0], [37.2, 1437.0], [37.3, 1441.0], [37.4, 1446.0], [37.5, 1450.0], [37.6, 1455.0], [37.7, 1459.0], [37.8, 1466.0], [37.9, 1472.0], [38.0, 1477.0], [38.1, 1485.0], [38.2, 1492.0], [38.3, 1500.0], [38.4, 1504.0], [38.5, 1507.0], [38.6, 1510.0], [38.7, 1515.0], [38.8, 1519.0], [38.9, 1527.0], [39.0, 1532.0], [39.1, 1538.0], [39.2, 1548.0], [39.3, 1555.0], [39.4, 1559.0], [39.5, 1564.0], [39.6, 1569.0], [39.7, 1574.0], [39.8, 1581.0], [39.9, 1587.0], [40.0, 1592.0], [40.1, 1598.0], [40.2, 1606.0], [40.3, 1616.0], [40.4, 1622.0], [40.5, 1633.0], [40.6, 1637.0], [40.7, 1642.0], [40.8, 1647.0], [40.9, 1657.0], [41.0, 1662.0], [41.1, 1668.0], [41.2, 1676.0], [41.3, 1685.0], [41.4, 1694.0], [41.5, 1698.0], [41.6, 1705.0], [41.7, 1708.0], [41.8, 1715.0], [41.9, 1721.0], [42.0, 1734.0], [42.1, 1743.0], [42.2, 1750.0], [42.3, 1756.0], [42.4, 1763.0], [42.5, 1769.0], [42.6, 1775.0], [42.7, 1779.0], [42.8, 1786.0], [42.9, 1796.0], [43.0, 1801.0], [43.1, 1810.0], [43.2, 1821.0], [43.3, 1826.0], [43.4, 1831.0], [43.5, 1839.0], [43.6, 1846.0], [43.7, 1850.0], [43.8, 1859.0], [43.9, 1868.0], [44.0, 1872.0], [44.1, 1877.0], [44.2, 1883.0], [44.3, 1887.0], [44.4, 1894.0], [44.5, 1902.0], [44.6, 1907.0], [44.7, 1916.0], [44.8, 1923.0], [44.9, 1930.0], [45.0, 1938.0], [45.1, 1944.0], [45.2, 1951.0], [45.3, 1961.0], [45.4, 1967.0], [45.5, 1976.0], [45.6, 1981.0], [45.7, 1990.0], [45.8, 1996.0], [45.9, 2005.0], [46.0, 2011.0], [46.1, 2021.0], [46.2, 2026.0], [46.3, 2036.0], [46.4, 2045.0], [46.5, 2056.0], [46.6, 2065.0], [46.7, 2071.0], [46.8, 2081.0], [46.9, 2087.0], [47.0, 2095.0], [47.1, 2102.0], [47.2, 2109.0], [47.3, 2120.0], [47.4, 2130.0], [47.5, 2137.0], [47.6, 2149.0], [47.7, 2156.0], [47.8, 2163.0], [47.9, 2167.0], [48.0, 2176.0], [48.1, 2183.0], [48.2, 2191.0], [48.3, 2203.0], [48.4, 2217.0], [48.5, 2227.0], [48.6, 2236.0], [48.7, 2243.0], [48.8, 2257.0], [48.9, 2267.0], [49.0, 2274.0], [49.1, 2279.0], [49.2, 2293.0], [49.3, 2299.0], [49.4, 2310.0], [49.5, 2322.0], [49.6, 2335.0], [49.7, 2342.0], [49.8, 2348.0], [49.9, 2356.0], [50.0, 2368.0], [50.1, 2382.0], [50.2, 2392.0], [50.3, 2399.0], [50.4, 2409.0], [50.5, 2414.0], [50.6, 2425.0], [50.7, 2429.0], [50.8, 2435.0], [50.9, 2443.0], [51.0, 2445.0], [51.1, 2452.0], [51.2, 2458.0], [51.3, 2473.0], [51.4, 2485.0], [51.5, 2496.0], [51.6, 2500.0], [51.7, 2507.0], [51.8, 2511.0], [51.9, 2523.0], [52.0, 2533.0], [52.1, 2540.0], [52.2, 2550.0], [52.3, 2556.0], [52.4, 2562.0], [52.5, 2570.0], [52.6, 2575.0], [52.7, 2585.0], [52.8, 2593.0], [52.9, 2599.0], [53.0, 2607.0], [53.1, 2615.0], [53.2, 2623.0], [53.3, 2633.0], [53.4, 2642.0], [53.5, 2658.0], [53.6, 2666.0], [53.7, 2674.0], [53.8, 2682.0], [53.9, 2689.0], [54.0, 2704.0], [54.1, 2714.0], [54.2, 2718.0], [54.3, 2728.0], [54.4, 2736.0], [54.5, 2749.0], [54.6, 2754.0], [54.7, 2763.0], [54.8, 2770.0], [54.9, 2781.0], [55.0, 2788.0], [55.1, 2805.0], [55.2, 2810.0], [55.3, 2821.0], [55.4, 2831.0], [55.5, 2836.0], [55.6, 2843.0], [55.7, 2853.0], [55.8, 2857.0], [55.9, 2866.0], [56.0, 2878.0], [56.1, 2892.0], [56.2, 2903.0], [56.3, 2912.0], [56.4, 2923.0], [56.5, 2936.0], [56.6, 2947.0], [56.7, 2953.0], [56.8, 2962.0], [56.9, 2970.0], [57.0, 2981.0], [57.1, 2992.0], [57.2, 3005.0], [57.3, 3017.0], [57.4, 3038.0], [57.5, 3049.0], [57.6, 3058.0], [57.7, 3066.0], [57.8, 3076.0], [57.9, 3090.0], [58.0, 3101.0], [58.1, 3110.0], [58.2, 3127.0], [58.3, 3142.0], [58.4, 3148.0], [58.5, 3159.0], [58.6, 3178.0], [58.7, 3193.0], [58.8, 3204.0], [58.9, 3212.0], [59.0, 3221.0], [59.1, 3234.0], [59.2, 3244.0], [59.3, 3247.0], [59.4, 3252.0], [59.5, 3259.0], [59.6, 3268.0], [59.7, 3280.0], [59.8, 3296.0], [59.9, 3308.0], [60.0, 3323.0], [60.1, 3328.0], [60.2, 3339.0], [60.3, 3348.0], [60.4, 3362.0], [60.5, 3374.0], [60.6, 3385.0], [60.7, 3390.0], [60.8, 3403.0], [60.9, 3413.0], [61.0, 3421.0], [61.1, 3432.0], [61.2, 3438.0], [61.3, 3448.0], [61.4, 3458.0], [61.5, 3466.0], [61.6, 3474.0], [61.7, 3483.0], [61.8, 3497.0], [61.9, 3505.0], [62.0, 3516.0], [62.1, 3521.0], [62.2, 3527.0], [62.3, 3540.0], [62.4, 3550.0], [62.5, 3558.0], [62.6, 3567.0], [62.7, 3573.0], [62.8, 3580.0], [62.9, 3591.0], [63.0, 3601.0], [63.1, 3606.0], [63.2, 3618.0], [63.3, 3632.0], [63.4, 3639.0], [63.5, 3651.0], [63.6, 3659.0], [63.7, 3666.0], [63.8, 3677.0], [63.9, 3686.0], [64.0, 3699.0], [64.1, 3708.0], [64.2, 3716.0], [64.3, 3727.0], [64.4, 3734.0], [64.5, 3743.0], [64.6, 3754.0], [64.7, 3760.0], [64.8, 3769.0], [64.9, 3778.0], [65.0, 3795.0], [65.1, 3807.0], [65.2, 3817.0], [65.3, 3828.0], [65.4, 3837.0], [65.5, 3854.0], [65.6, 3866.0], [65.7, 3882.0], [65.8, 3896.0], [65.9, 3906.0], [66.0, 3920.0], [66.1, 3927.0], [66.2, 3947.0], [66.3, 3961.0], [66.4, 3969.0], [66.5, 3982.0], [66.6, 3998.0], [66.7, 4005.0], [66.8, 4013.0], [66.9, 4025.0], [67.0, 4032.0], [67.1, 4042.0], [67.2, 4059.0], [67.3, 4073.0], [67.4, 4082.0], [67.5, 4092.0], [67.6, 4104.0], [67.7, 4117.0], [67.8, 4126.0], [67.9, 4137.0], [68.0, 4149.0], [68.1, 4158.0], [68.2, 4167.0], [68.3, 4183.0], [68.4, 4193.0], [68.5, 4204.0], [68.6, 4220.0], [68.7, 4230.0], [68.8, 4247.0], [68.9, 4257.0], [69.0, 4270.0], [69.1, 4282.0], [69.2, 4297.0], [69.3, 4310.0], [69.4, 4330.0], [69.5, 4350.0], [69.6, 4362.0], [69.7, 4371.0], [69.8, 4380.0], [69.9, 4393.0], [70.0, 4406.0], [70.1, 4420.0], [70.2, 4430.0], [70.3, 4439.0], [70.4, 4447.0], [70.5, 4454.0], [70.6, 4458.0], [70.7, 4471.0], [70.8, 4478.0], [70.9, 4484.0], [71.0, 4491.0], [71.1, 4502.0], [71.2, 4511.0], [71.3, 4519.0], [71.4, 4531.0], [71.5, 4536.0], [71.6, 4544.0], [71.7, 4557.0], [71.8, 4564.0], [71.9, 4571.0], [72.0, 4581.0], [72.1, 4592.0], [72.2, 4602.0], [72.3, 4611.0], [72.4, 4618.0], [72.5, 4627.0], [72.6, 4633.0], [72.7, 4642.0], [72.8, 4646.0], [72.9, 4653.0], [73.0, 4660.0], [73.1, 4666.0], [73.2, 4671.0], [73.3, 4683.0], [73.4, 4692.0], [73.5, 4702.0], [73.6, 4709.0], [73.7, 4722.0], [73.8, 4729.0], [73.9, 4738.0], [74.0, 4750.0], [74.1, 4761.0], [74.2, 4773.0], [74.3, 4783.0], [74.4, 4791.0], [74.5, 4804.0], [74.6, 4811.0], [74.7, 4825.0], [74.8, 4837.0], [74.9, 4845.0], [75.0, 4854.0], [75.1, 4864.0], [75.2, 4877.0], [75.3, 4883.0], [75.4, 4896.0], [75.5, 4908.0], [75.6, 4922.0], [75.7, 4935.0], [75.8, 4941.0], [75.9, 4951.0], [76.0, 4957.0], [76.1, 4963.0], [76.2, 4969.0], [76.3, 4983.0], [76.4, 5001.0], [76.5, 5015.0], [76.6, 5028.0], [76.7, 5033.0], [76.8, 5046.0], [76.9, 5057.0], [77.0, 5072.0], [77.1, 5090.0], [77.2, 5106.0], [77.3, 5121.0], [77.4, 5133.0], [77.5, 5157.0], [77.6, 5165.0], [77.7, 5184.0], [77.8, 5199.0], [77.9, 5215.0], [78.0, 5225.0], [78.1, 5240.0], [78.2, 5251.0], [78.3, 5263.0], [78.4, 5283.0], [78.5, 5297.0], [78.6, 5312.0], [78.7, 5323.0], [78.8, 5340.0], [78.9, 5356.0], [79.0, 5370.0], [79.1, 5380.0], [79.2, 5398.0], [79.3, 5408.0], [79.4, 5417.0], [79.5, 5430.0], [79.6, 5446.0], [79.7, 5457.0], [79.8, 5471.0], [79.9, 5478.0], [80.0, 5490.0], [80.1, 5504.0], [80.2, 5519.0], [80.3, 5540.0], [80.4, 5551.0], [80.5, 5566.0], [80.6, 5574.0], [80.7, 5583.0], [80.8, 5593.0], [80.9, 5605.0], [81.0, 5614.0], [81.1, 5621.0], [81.2, 5632.0], [81.3, 5646.0], [81.4, 5660.0], [81.5, 5669.0], [81.6, 5684.0], [81.7, 5695.0], [81.8, 5711.0], [81.9, 5726.0], [82.0, 5748.0], [82.1, 5757.0], [82.2, 5768.0], [82.3, 5776.0], [82.4, 5788.0], [82.5, 5796.0], [82.6, 5810.0], [82.7, 5818.0], [82.8, 5834.0], [82.9, 5844.0], [83.0, 5865.0], [83.1, 5877.0], [83.2, 5897.0], [83.3, 5914.0], [83.4, 5928.0], [83.5, 5941.0], [83.6, 5956.0], [83.7, 5969.0], [83.8, 5979.0], [83.9, 5987.0], [84.0, 6003.0], [84.1, 6013.0], [84.2, 6029.0], [84.3, 6038.0], [84.4, 6055.0], [84.5, 6062.0], [84.6, 6078.0], [84.7, 6099.0], [84.8, 6115.0], [84.9, 6131.0], [85.0, 6148.0], [85.1, 6169.0], [85.2, 6177.0], [85.3, 6190.0], [85.4, 6202.0], [85.5, 6223.0], [85.6, 6230.0], [85.7, 6247.0], [85.8, 6263.0], [85.9, 6286.0], [86.0, 6308.0], [86.1, 6342.0], [86.2, 6364.0], [86.3, 6375.0], [86.4, 6403.0], [86.5, 6438.0], [86.6, 6454.0], [86.7, 6480.0], [86.8, 6502.0], [86.9, 6523.0], [87.0, 6572.0], [87.1, 6624.0], [87.2, 6644.0], [87.3, 6672.0], [87.4, 6712.0], [87.5, 6752.0], [87.6, 6795.0], [87.7, 6824.0], [87.8, 6862.0], [87.9, 6900.0], [88.0, 6938.0], [88.1, 6976.0], [88.2, 7033.0], [88.3, 7077.0], [88.4, 7115.0], [88.5, 7176.0], [88.6, 7272.0], [88.7, 7337.0], [88.8, 7382.0], [88.9, 7432.0], [89.0, 7487.0], [89.1, 7510.0], [89.2, 7534.0], [89.3, 7566.0], [89.4, 7590.0], [89.5, 7611.0], [89.6, 7647.0], [89.7, 7672.0], [89.8, 7691.0], [89.9, 7706.0], [90.0, 7723.0], [90.1, 7748.0], [90.2, 7765.0], [90.3, 7784.0], [90.4, 7798.0], [90.5, 7813.0], [90.6, 7845.0], [90.7, 7869.0], [90.8, 7888.0], [90.9, 7934.0], [91.0, 7959.0], [91.1, 7975.0], [91.2, 8000.0], [91.3, 8037.0], [91.4, 8055.0], [91.5, 8071.0], [91.6, 8112.0], [91.7, 8130.0], [91.8, 8158.0], [91.9, 8189.0], [92.0, 8207.0], [92.1, 8234.0], [92.2, 8255.0], [92.3, 8268.0], [92.4, 8282.0], [92.5, 8299.0], [92.6, 8322.0], [92.7, 8342.0], [92.8, 8364.0], [92.9, 8404.0], [93.0, 8436.0], [93.1, 8456.0], [93.2, 8474.0], [93.3, 8503.0], [93.4, 8520.0], [93.5, 8552.0], [93.6, 8580.0], [93.7, 8609.0], [93.8, 8627.0], [93.9, 8663.0], [94.0, 8698.0], [94.1, 8721.0], [94.2, 8748.0], [94.3, 8787.0], [94.4, 8818.0], [94.5, 8840.0], [94.6, 8852.0], [94.7, 8868.0], [94.8, 8905.0], [94.9, 8917.0], [95.0, 8933.0], [95.1, 8962.0], [95.2, 8981.0], [95.3, 9006.0], [95.4, 9041.0], [95.5, 9073.0], [95.6, 9090.0], [95.7, 9153.0], [95.8, 9185.0], [95.9, 9236.0], [96.0, 9281.0], [96.1, 9315.0], [96.2, 9328.0], [96.3, 9356.0], [96.4, 9434.0], [96.5, 9456.0], [96.6, 9492.0], [96.7, 9530.0], [96.8, 9555.0], [96.9, 9584.0], [97.0, 9632.0], [97.1, 9649.0], [97.2, 9665.0], [97.3, 9692.0], [97.4, 9723.0], [97.5, 9761.0], [97.6, 9783.0], [97.7, 9842.0], [97.8, 9898.0], [97.9, 9935.0], [98.0, 9971.0], [98.1, 10011.0], [98.2, 10062.0], [98.3, 10107.0], [98.4, 10191.0], [98.5, 10296.0], [98.6, 10377.0], [98.7, 10512.0], [98.8, 10574.0], [98.9, 10613.0], [99.0, 10669.0], [99.1, 10697.0], [99.2, 10749.0], [99.3, 10808.0], [99.4, 10851.0], [99.5, 10893.0], [99.6, 10945.0], [99.7, 11092.0], [99.8, 12430.0], [99.9, 13183.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 100.0, "maxY": 454.0, "series": [{"data": [[100.0, 26.0], [200.0, 196.0], [300.0, 375.0], [400.0, 454.0], [500.0, 433.0], [600.0, 349.0], [700.0, 269.0], [800.0, 264.0], [900.0, 265.0], [1000.0, 254.0], [1100.0, 245.0], [1200.0, 229.0], [1300.0, 184.0], [1400.0, 165.0], [1500.0, 182.0], [1600.0, 133.0], [1700.0, 137.0], [1800.0, 146.0], [1900.0, 135.0], [2000.0, 121.0], [2100.0, 115.0], [2300.0, 97.0], [2200.0, 100.0], [2400.0, 122.0], [2500.0, 129.0], [2600.0, 102.0], [2700.0, 111.0], [2800.0, 105.0], [2900.0, 94.0], [3000.0, 82.0], [3100.0, 74.0], [3200.0, 106.0], [3300.0, 89.0], [3400.0, 105.0], [3500.0, 108.0], [3700.0, 98.0], [3600.0, 100.0], [3800.0, 80.0], [3900.0, 75.0], [4000.0, 92.0], [4200.0, 72.0], [4100.0, 87.0], [4300.0, 69.0], [4600.0, 123.0], [4400.0, 113.0], [4500.0, 107.0], [4700.0, 99.0], [4800.0, 90.0], [5000.0, 73.0], [4900.0, 95.0], [5100.0, 65.0], [5300.0, 66.0], [5200.0, 69.0], [5500.0, 73.0], [5600.0, 86.0], [5400.0, 84.0], [5800.0, 64.0], [5700.0, 81.0], [6000.0, 72.0], [5900.0, 73.0], [6100.0, 64.0], [6200.0, 59.0], [6300.0, 39.0], [6400.0, 39.0], [6500.0, 26.0], [6600.0, 31.0], [6800.0, 25.0], [6700.0, 25.0], [6900.0, 23.0], [7000.0, 24.0], [7100.0, 14.0], [7400.0, 23.0], [7300.0, 19.0], [7200.0, 10.0], [7600.0, 41.0], [7500.0, 37.0], [7900.0, 35.0], [7700.0, 52.0], [7800.0, 42.0], [8000.0, 38.0], [8100.0, 37.0], [8500.0, 38.0], [8400.0, 37.0], [8200.0, 52.0], [8700.0, 33.0], [8600.0, 33.0], [8300.0, 38.0], [9000.0, 34.0], [8800.0, 43.0], [9100.0, 23.0], [9200.0, 20.0], [8900.0, 44.0], [9300.0, 32.0], [9600.0, 35.0], [9700.0, 32.0], [9400.0, 24.0], [9500.0, 31.0], [9900.0, 26.0], [10200.0, 10.0], [9800.0, 16.0], [10000.0, 20.0], [10100.0, 12.0], [10300.0, 12.0], [10500.0, 18.0], [10400.0, 7.0], [10600.0, 23.0], [10700.0, 14.0], [10800.0, 23.0], [11100.0, 4.0], [10900.0, 14.0], [11000.0, 6.0], [11200.0, 1.0], [11500.0, 1.0], [11800.0, 1.0], [12200.0, 1.0], [12400.0, 1.0], [12700.0, 1.0], [12600.0, 1.0], [13100.0, 3.0], [13000.0, 3.0], [12800.0, 1.0], [12900.0, 1.0], [13700.0, 1.0], [13600.0, 1.0], [14100.0, 1.0], [14300.0, 1.0], [13900.0, 1.0], [14000.0, 1.0], [14600.0, 1.0], [14700.0, 2.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 14700.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 1053.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 5976.0, "series": [{"data": [[0.0, 1053.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 2659.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 5976.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 13.0, "minX": 1.6304832E12, "maxY": 75.0, "series": [{"data": [[1.63048368E12, 75.0], [1.6304832E12, 13.0], [1.63048338E12, 34.45342205323195], [1.63048356E12, 63.0], [1.63048326E12, 13.0], [1.63048374E12, 75.0], [1.63048344E12, 43.60077145612345], [1.63048362E12, 74.75485188968337], [1.63048332E12, 24.798019801980175], [1.6304838E12, 71.61566707466342], [1.6304835E12, 53.20621761658033]], "isOverall": false, "label": "bzm - Concurrency Thread Group-ThreadStarter", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.6304838E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 471.0, "minX": 1.0, "maxY": 7323.0, "series": [{"data": [[2.0, 5730.0], [3.0, 2441.0], [4.0, 2714.0], [5.0, 2940.0], [6.0, 3045.0], [7.0, 3046.0], [8.0, 3090.0], [9.0, 3609.0], [10.0, 3287.0], [11.0, 3856.0], [12.0, 3969.0], [13.0, 979.4908350305495], [14.0, 4326.0], [15.0, 4428.0], [16.0, 4660.0], [17.0, 4679.0], [18.0, 4628.0], [19.0, 4766.0], [20.0, 4856.0], [21.0, 4845.0], [22.0, 4948.0], [23.0, 5281.0], [24.0, 5646.0], [25.0, 1455.0312256049942], [26.0, 4691.5], [27.0, 6156.0], [28.0, 6012.0], [30.0, 6135.5], [31.0, 6099.0], [33.0, 6661.0], [32.0, 6100.0], [35.0, 6664.0], [34.0, 6694.0], [37.0, 2843.0], [36.0, 6943.0], [38.0, 2173.1936218678793], [39.0, 4834.5], [41.0, 1762.0], [40.0, 6889.0], [43.0, 6967.0], [42.0, 7248.0], [45.0, 2295.0], [44.0, 1898.0], [47.0, 2237.0], [46.0, 7082.0], [49.0, 2198.0], [48.0, 7077.0], [50.0, 2992.797854785483], [51.0, 2562.0], [53.0, 3010.0], [52.0, 2642.0], [55.0, 7099.0], [54.0, 2730.0], [57.0, 2893.0], [56.0, 2946.0], [59.0, 3201.0], [58.0, 2999.0], [61.0, 3216.0], [60.0, 7171.0], [62.0, 7112.5], [63.0, 3872.8122895622896], [67.0, 3433.0], [66.0, 4447.75], [70.0, 471.0], [71.0, 5360.5], [69.0, 6898.0], [68.0, 7323.0], [72.0, 2027.5], [75.0, 4657.819157720905], [74.0, 7047.0], [73.0, 7071.0], [1.0, 5001.0]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[52.1967382328654, 3218.860755573907]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 75.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 3363.1, "minX": 1.6304832E12, "maxY": 64233.416666666664, "series": [{"data": [[1.63048368E12, 57022.35], [1.6304832E12, 7768.3], [1.63048338E12, 64233.416666666664], [1.63048356E12, 56804.45], [1.63048326E12, 51041.0], [1.63048374E12, 60890.73333333333], [1.63048344E12, 63374.51666666667], [1.63048362E12, 59921.4], [1.63048332E12, 61611.03333333333], [1.6304838E12, 50051.65], [1.6304835E12, 58833.45]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.63048368E12, 24592.9], [1.6304832E12, 3363.1], [1.63048338E12, 27640.8], [1.63048356E12, 24461.5], [1.63048326E12, 21965.516666666666], [1.63048374E12, 26195.65], [1.63048344E12, 27246.716666666667], [1.63048362E12, 25722.883333333335], [1.63048332E12, 26537.216666666667], [1.6304838E12, 21466.383333333335], [1.6304835E12, 25354.833333333332]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.6304838E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 928.8241626794251, "minX": 1.6304832E12, "maxY": 4698.7482447342, "series": [{"data": [[1.63048368E12, 4667.032051282044], [1.6304832E12, 1319.7421875000005], [1.63048338E12, 1919.2661596958194], [1.63048356E12, 3998.256713211597], [1.63048326E12, 928.8241626794251], [1.63048374E12, 4698.7482447342], [1.63048344E12, 2444.717454194791], [1.63048362E12, 4550.312563840652], [1.63048332E12, 1458.8980198019808], [1.6304838E12, 4666.296205630354], [1.6304835E12, 3283.607253886012]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.6304838E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 928.7619617224892, "minX": 1.6304832E12, "maxY": 4698.7331995988025, "series": [{"data": [[1.63048368E12, 4667.016025641025], [1.6304832E12, 1319.6250000000002], [1.63048338E12, 1919.2233840304189], [1.63048356E12, 3998.233082706765], [1.63048326E12, 928.7619617224892], [1.63048374E12, 4698.7331995988025], [1.63048344E12, 2444.6981677917042], [1.63048362E12, 4550.290091930538], [1.63048332E12, 1458.8683168316848], [1.6304838E12, 4666.28396572827], [1.6304835E12, 3283.5886010362688]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.6304838E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 30.80538555691553, "minX": 1.6304832E12, "maxY": 242.84374999999991, "series": [{"data": [[1.63048368E12, 31.77777777777776], [1.6304832E12, 242.84374999999991], [1.63048338E12, 38.86596958174903], [1.63048356E12, 45.17937701396352], [1.63048326E12, 38.59688995215305], [1.63048374E12, 31.97693079237713], [1.63048344E12, 37.05689488910316], [1.63048362E12, 32.05005107252295], [1.63048332E12, 34.62079207920797], [1.6304838E12, 30.80538555691553], [1.6304835E12, 40.20103626943009]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.6304838E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 138.0, "minX": 1.6304832E12, "maxY": 14760.0, "series": [{"data": [[1.63048368E12, 14760.0], [1.6304832E12, 5818.0], [1.63048338E12, 9002.0], [1.63048356E12, 14643.0], [1.63048326E12, 6803.0], [1.63048374E12, 12924.0], [1.63048344E12, 10849.0], [1.63048362E12, 14714.0], [1.63048332E12, 7432.0], [1.6304838E12, 11584.0], [1.6304835E12, 11175.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.63048368E12, 10361.400000000001], [1.6304832E12, 2599.8], [1.63048338E12, 3605.0], [1.63048356E12, 8010.400000000001], [1.63048326E12, 1508.5000000000005], [1.63048374E12, 6849.400000000001], [1.63048344E12, 4925.0], [1.63048362E12, 9468.0], [1.63048332E12, 2578.8], [1.6304838E12, 6652.4], [1.6304835E12, 6436.599999999999]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.63048368E12, 12604.109999999997], [1.6304832E12, 5729.259999999998], [1.63048338E12, 5912.470000000011], [1.63048356E12, 10364.439999999999], [1.63048326E12, 5943.79], [1.63048374E12, 10885.14], [1.63048344E12, 6580.399999999998], [1.63048362E12, 10115.60000000001], [1.63048332E12, 5376.5599999999995], [1.6304838E12, 8226.799999999997], [1.6304835E12, 8547.840000000027]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.63048368E12, 10724.0], [1.6304832E12, 2678.75], [1.63048338E12, 3828.3999999999996], [1.63048356E12, 9321.2], [1.63048326E12, 1803.1499999999996], [1.63048374E12, 7802.399999999996], [1.63048344E12, 5883.299999999999], [1.63048362E12, 9702.0], [1.63048332E12, 2752.35], [1.6304838E12, 7102.799999999999], [1.6304835E12, 6941.799999999999]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.63048368E12, 145.0], [1.6304832E12, 251.0], [1.63048338E12, 217.0], [1.63048356E12, 138.0], [1.63048326E12, 178.0], [1.63048374E12, 934.0], [1.63048344E12, 163.0], [1.63048362E12, 181.0], [1.63048332E12, 166.0], [1.6304838E12, 1490.0], [1.6304835E12, 187.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.63048368E12, 1996.0], [1.6304832E12, 1094.5], [1.63048338E12, 1778.0], [1.63048356E12, 3343.0], [1.63048326E12, 777.0], [1.63048374E12, 4591.0], [1.63048344E12, 2230.0], [1.63048362E12, 3922.0], [1.63048332E12, 1339.5], [1.6304838E12, 4519.0], [1.6304835E12, 3057.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.6304838E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 998.5, "minX": 1.0, "maxY": 5957.0, "series": [{"data": [[32.0, 2804.0], [2.0, 5365.5], [37.0, 5957.0], [4.0, 1333.0], [5.0, 1988.0], [6.0, 2548.5], [7.0, 5106.0], [8.0, 998.5], [9.0, 2530.0], [10.0, 1884.5], [11.0, 2396.0], [12.0, 1935.5], [13.0, 1492.5], [14.0, 2402.5], [15.0, 1866.5], [1.0, 2392.0], [16.0, 2717.5], [17.0, 3161.0], [18.0, 2366.0], [19.0, 2457.0], [20.0, 2727.5], [21.0, 3296.0], [22.0, 2268.5], [23.0, 1706.0], [24.0, 2639.0], [25.0, 2972.5], [26.0, 1181.5], [27.0, 1319.0], [28.0, 2504.5], [29.0, 2403.5], [30.0, 2381.0], [31.0, 5294.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 37.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 998.0, "minX": 1.0, "maxY": 5957.0, "series": [{"data": [[32.0, 2804.0], [2.0, 5365.5], [37.0, 5957.0], [4.0, 1333.0], [5.0, 1988.0], [6.0, 2548.5], [7.0, 5106.0], [8.0, 998.0], [9.0, 2530.0], [10.0, 1883.0], [11.0, 2396.0], [12.0, 1935.5], [13.0, 1492.5], [14.0, 2402.5], [15.0, 1866.5], [1.0, 2391.0], [16.0, 2717.5], [17.0, 3161.0], [18.0, 2366.0], [19.0, 2457.0], [20.0, 2727.5], [21.0, 3296.0], [22.0, 2268.5], [23.0, 1706.0], [24.0, 2639.0], [25.0, 2972.5], [26.0, 1181.5], [27.0, 1319.0], [28.0, 2504.5], [29.0, 2403.5], [30.0, 2381.0], [31.0, 5294.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 37.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 2.35, "minX": 1.6304832E12, "maxY": 17.75, "series": [{"data": [[1.63048368E12, 15.6], [1.6304832E12, 2.35], [1.63048338E12, 17.75], [1.63048356E12, 15.516666666666667], [1.63048326E12, 13.933333333333334], [1.63048374E12, 16.616666666666667], [1.63048344E12, 17.483333333333334], [1.63048362E12, 16.516666666666666], [1.63048332E12, 17.033333333333335], [1.6304838E12, 12.366666666666667], [1.6304835E12, 16.3]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.6304838E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 2.1333333333333333, "minX": 1.6304832E12, "maxY": 17.533333333333335, "series": [{"data": [[1.63048368E12, 15.6], [1.6304832E12, 2.1333333333333333], [1.63048338E12, 17.533333333333335], [1.63048356E12, 15.516666666666667], [1.63048326E12, 13.933333333333334], [1.63048374E12, 16.616666666666667], [1.63048344E12, 17.283333333333335], [1.63048362E12, 16.316666666666666], [1.63048332E12, 16.833333333333332], [1.6304838E12, 13.616666666666667], [1.6304835E12, 16.083333333333332]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.6304838E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 2.1333333333333333, "minX": 1.6304832E12, "maxY": 17.533333333333335, "series": [{"data": [[1.63048368E12, 15.6], [1.6304832E12, 2.1333333333333333], [1.63048338E12, 17.533333333333335], [1.63048356E12, 15.516666666666667], [1.63048326E12, 13.933333333333334], [1.63048374E12, 16.616666666666667], [1.63048344E12, 17.283333333333335], [1.63048362E12, 16.316666666666666], [1.63048332E12, 16.833333333333332], [1.6304838E12, 13.616666666666667], [1.6304835E12, 16.083333333333332]], "isOverall": false, "label": "HTTP Request-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.6304838E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 2.1333333333333333, "minX": 1.6304832E12, "maxY": 17.533333333333335, "series": [{"data": [[1.63048368E12, 15.6], [1.6304832E12, 2.1333333333333333], [1.63048338E12, 17.533333333333335], [1.63048356E12, 15.516666666666667], [1.63048326E12, 13.933333333333334], [1.63048374E12, 16.616666666666667], [1.63048344E12, 17.283333333333335], [1.63048362E12, 16.316666666666666], [1.63048332E12, 16.833333333333332], [1.6304838E12, 13.616666666666667], [1.6304835E12, 16.083333333333332]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.6304838E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

