/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 185.0, "minX": 0.0, "maxY": 3442.0, "series": [{"data": [[0.0, 185.0], [0.1, 185.0], [0.2, 186.0], [0.3, 188.0], [0.4, 188.0], [0.5, 189.0], [0.6, 192.0], [0.7, 192.0], [0.8, 193.0], [0.9, 193.0], [1.0, 195.0], [1.1, 195.0], [1.2, 195.0], [1.3, 196.0], [1.4, 196.0], [1.5, 196.0], [1.6, 197.0], [1.7, 197.0], [1.8, 198.0], [1.9, 198.0], [2.0, 198.0], [2.1, 198.0], [2.2, 199.0], [2.3, 199.0], [2.4, 199.0], [2.5, 201.0], [2.6, 202.0], [2.7, 202.0], [2.8, 202.0], [2.9, 202.0], [3.0, 203.0], [3.1, 203.0], [3.2, 203.0], [3.3, 203.0], [3.4, 203.0], [3.5, 203.0], [3.6, 203.0], [3.7, 203.0], [3.8, 204.0], [3.9, 204.0], [4.0, 204.0], [4.1, 204.0], [4.2, 204.0], [4.3, 204.0], [4.4, 204.0], [4.5, 205.0], [4.6, 205.0], [4.7, 205.0], [4.8, 205.0], [4.9, 205.0], [5.0, 205.0], [5.1, 205.0], [5.2, 205.0], [5.3, 205.0], [5.4, 205.0], [5.5, 205.0], [5.6, 206.0], [5.7, 206.0], [5.8, 206.0], [5.9, 207.0], [6.0, 208.0], [6.1, 208.0], [6.2, 208.0], [6.3, 208.0], [6.4, 208.0], [6.5, 209.0], [6.6, 209.0], [6.7, 209.0], [6.8, 209.0], [6.9, 210.0], [7.0, 210.0], [7.1, 210.0], [7.2, 210.0], [7.3, 211.0], [7.4, 211.0], [7.5, 211.0], [7.6, 211.0], [7.7, 211.0], [7.8, 211.0], [7.9, 211.0], [8.0, 211.0], [8.1, 211.0], [8.2, 212.0], [8.3, 212.0], [8.4, 212.0], [8.5, 214.0], [8.6, 214.0], [8.7, 214.0], [8.8, 214.0], [8.9, 215.0], [9.0, 215.0], [9.1, 215.0], [9.2, 215.0], [9.3, 215.0], [9.4, 215.0], [9.5, 216.0], [9.6, 217.0], [9.7, 217.0], [9.8, 217.0], [9.9, 217.0], [10.0, 217.0], [10.1, 217.0], [10.2, 218.0], [10.3, 219.0], [10.4, 219.0], [10.5, 219.0], [10.6, 219.0], [10.7, 219.0], [10.8, 219.0], [10.9, 220.0], [11.0, 220.0], [11.1, 220.0], [11.2, 220.0], [11.3, 220.0], [11.4, 220.0], [11.5, 220.0], [11.6, 220.0], [11.7, 220.0], [11.8, 220.0], [11.9, 221.0], [12.0, 221.0], [12.1, 221.0], [12.2, 221.0], [12.3, 222.0], [12.4, 222.0], [12.5, 222.0], [12.6, 223.0], [12.7, 223.0], [12.8, 223.0], [12.9, 223.0], [13.0, 223.0], [13.1, 223.0], [13.2, 223.0], [13.3, 224.0], [13.4, 224.0], [13.5, 224.0], [13.6, 224.0], [13.7, 224.0], [13.8, 224.0], [13.9, 224.0], [14.0, 225.0], [14.1, 225.0], [14.2, 225.0], [14.3, 225.0], [14.4, 225.0], [14.5, 226.0], [14.6, 226.0], [14.7, 226.0], [14.8, 226.0], [14.9, 226.0], [15.0, 226.0], [15.1, 226.0], [15.2, 226.0], [15.3, 226.0], [15.4, 226.0], [15.5, 227.0], [15.6, 227.0], [15.7, 227.0], [15.8, 227.0], [15.9, 227.0], [16.0, 227.0], [16.1, 227.0], [16.2, 227.0], [16.3, 227.0], [16.4, 227.0], [16.5, 228.0], [16.6, 228.0], [16.7, 228.0], [16.8, 228.0], [16.9, 228.0], [17.0, 228.0], [17.1, 228.0], [17.2, 229.0], [17.3, 229.0], [17.4, 229.0], [17.5, 229.0], [17.6, 229.0], [17.7, 229.0], [17.8, 230.0], [17.9, 230.0], [18.0, 230.0], [18.1, 230.0], [18.2, 230.0], [18.3, 230.0], [18.4, 230.0], [18.5, 230.0], [18.6, 230.0], [18.7, 230.0], [18.8, 231.0], [18.9, 231.0], [19.0, 231.0], [19.1, 231.0], [19.2, 231.0], [19.3, 231.0], [19.4, 231.0], [19.5, 232.0], [19.6, 232.0], [19.7, 232.0], [19.8, 232.0], [19.9, 232.0], [20.0, 232.0], [20.1, 232.0], [20.2, 232.0], [20.3, 232.0], [20.4, 232.0], [20.5, 232.0], [20.6, 233.0], [20.7, 233.0], [20.8, 233.0], [20.9, 233.0], [21.0, 233.0], [21.1, 233.0], [21.2, 233.0], [21.3, 233.0], [21.4, 233.0], [21.5, 234.0], [21.6, 235.0], [21.7, 235.0], [21.8, 235.0], [21.9, 235.0], [22.0, 235.0], [22.1, 236.0], [22.2, 236.0], [22.3, 236.0], [22.4, 236.0], [22.5, 236.0], [22.6, 236.0], [22.7, 236.0], [22.8, 236.0], [22.9, 236.0], [23.0, 236.0], [23.1, 236.0], [23.2, 236.0], [23.3, 236.0], [23.4, 236.0], [23.5, 237.0], [23.6, 237.0], [23.7, 237.0], [23.8, 237.0], [23.9, 237.0], [24.0, 237.0], [24.1, 237.0], [24.2, 237.0], [24.3, 237.0], [24.4, 237.0], [24.5, 237.0], [24.6, 237.0], [24.7, 237.0], [24.8, 238.0], [24.9, 238.0], [25.0, 239.0], [25.1, 239.0], [25.2, 239.0], [25.3, 239.0], [25.4, 239.0], [25.5, 239.0], [25.6, 239.0], [25.7, 239.0], [25.8, 240.0], [25.9, 240.0], [26.0, 240.0], [26.1, 240.0], [26.2, 240.0], [26.3, 241.0], [26.4, 241.0], [26.5, 241.0], [26.6, 241.0], [26.7, 241.0], [26.8, 242.0], [26.9, 242.0], [27.0, 242.0], [27.1, 242.0], [27.2, 242.0], [27.3, 242.0], [27.4, 242.0], [27.5, 242.0], [27.6, 242.0], [27.7, 242.0], [27.8, 243.0], [27.9, 244.0], [28.0, 244.0], [28.1, 244.0], [28.2, 244.0], [28.3, 244.0], [28.4, 244.0], [28.5, 244.0], [28.6, 244.0], [28.7, 244.0], [28.8, 245.0], [28.9, 245.0], [29.0, 246.0], [29.1, 246.0], [29.2, 246.0], [29.3, 246.0], [29.4, 246.0], [29.5, 246.0], [29.6, 246.0], [29.7, 246.0], [29.8, 247.0], [29.9, 247.0], [30.0, 248.0], [30.1, 248.0], [30.2, 248.0], [30.3, 248.0], [30.4, 248.0], [30.5, 248.0], [30.6, 249.0], [30.7, 249.0], [30.8, 249.0], [30.9, 249.0], [31.0, 249.0], [31.1, 249.0], [31.2, 249.0], [31.3, 249.0], [31.4, 249.0], [31.5, 249.0], [31.6, 250.0], [31.7, 250.0], [31.8, 250.0], [31.9, 250.0], [32.0, 251.0], [32.1, 251.0], [32.2, 252.0], [32.3, 252.0], [32.4, 252.0], [32.5, 252.0], [32.6, 252.0], [32.7, 252.0], [32.8, 252.0], [32.9, 252.0], [33.0, 253.0], [33.1, 253.0], [33.2, 253.0], [33.3, 254.0], [33.4, 254.0], [33.5, 254.0], [33.6, 255.0], [33.7, 255.0], [33.8, 255.0], [33.9, 255.0], [34.0, 255.0], [34.1, 255.0], [34.2, 255.0], [34.3, 256.0], [34.4, 256.0], [34.5, 256.0], [34.6, 256.0], [34.7, 256.0], [34.8, 256.0], [34.9, 256.0], [35.0, 256.0], [35.1, 256.0], [35.2, 257.0], [35.3, 257.0], [35.4, 257.0], [35.5, 257.0], [35.6, 257.0], [35.7, 257.0], [35.8, 257.0], [35.9, 258.0], [36.0, 258.0], [36.1, 258.0], [36.2, 259.0], [36.3, 259.0], [36.4, 259.0], [36.5, 259.0], [36.6, 259.0], [36.7, 259.0], [36.8, 259.0], [36.9, 260.0], [37.0, 260.0], [37.1, 260.0], [37.2, 260.0], [37.3, 261.0], [37.4, 261.0], [37.5, 261.0], [37.6, 262.0], [37.7, 262.0], [37.8, 262.0], [37.9, 263.0], [38.0, 263.0], [38.1, 263.0], [38.2, 264.0], [38.3, 265.0], [38.4, 265.0], [38.5, 265.0], [38.6, 265.0], [38.7, 265.0], [38.8, 265.0], [38.9, 265.0], [39.0, 266.0], [39.1, 266.0], [39.2, 267.0], [39.3, 267.0], [39.4, 267.0], [39.5, 267.0], [39.6, 268.0], [39.7, 268.0], [39.8, 269.0], [39.9, 269.0], [40.0, 269.0], [40.1, 269.0], [40.2, 269.0], [40.3, 269.0], [40.4, 269.0], [40.5, 270.0], [40.6, 270.0], [40.7, 270.0], [40.8, 270.0], [40.9, 270.0], [41.0, 270.0], [41.1, 271.0], [41.2, 271.0], [41.3, 271.0], [41.4, 271.0], [41.5, 272.0], [41.6, 272.0], [41.7, 272.0], [41.8, 273.0], [41.9, 273.0], [42.0, 273.0], [42.1, 273.0], [42.2, 273.0], [42.3, 273.0], [42.4, 273.0], [42.5, 273.0], [42.6, 274.0], [42.7, 274.0], [42.8, 274.0], [42.9, 274.0], [43.0, 274.0], [43.1, 274.0], [43.2, 274.0], [43.3, 275.0], [43.4, 275.0], [43.5, 275.0], [43.6, 275.0], [43.7, 275.0], [43.8, 275.0], [43.9, 275.0], [44.0, 275.0], [44.1, 275.0], [44.2, 275.0], [44.3, 276.0], [44.4, 276.0], [44.5, 277.0], [44.6, 277.0], [44.7, 277.0], [44.8, 277.0], [44.9, 277.0], [45.0, 277.0], [45.1, 278.0], [45.2, 278.0], [45.3, 278.0], [45.4, 278.0], [45.5, 278.0], [45.6, 278.0], [45.7, 278.0], [45.8, 279.0], [45.9, 279.0], [46.0, 279.0], [46.1, 279.0], [46.2, 279.0], [46.3, 279.0], [46.4, 279.0], [46.5, 279.0], [46.6, 280.0], [46.7, 280.0], [46.8, 280.0], [46.9, 280.0], [47.0, 280.0], [47.1, 280.0], [47.2, 281.0], [47.3, 281.0], [47.4, 281.0], [47.5, 281.0], [47.6, 282.0], [47.7, 282.0], [47.8, 282.0], [47.9, 283.0], [48.0, 283.0], [48.1, 283.0], [48.2, 283.0], [48.3, 283.0], [48.4, 283.0], [48.5, 283.0], [48.6, 284.0], [48.7, 284.0], [48.8, 284.0], [48.9, 284.0], [49.0, 284.0], [49.1, 284.0], [49.2, 284.0], [49.3, 285.0], [49.4, 285.0], [49.5, 285.0], [49.6, 285.0], [49.7, 285.0], [49.8, 286.0], [49.9, 287.0], [50.0, 287.0], [50.1, 287.0], [50.2, 287.0], [50.3, 287.0], [50.4, 287.0], [50.5, 288.0], [50.6, 288.0], [50.7, 288.0], [50.8, 288.0], [50.9, 288.0], [51.0, 288.0], [51.1, 288.0], [51.2, 288.0], [51.3, 289.0], [51.4, 289.0], [51.5, 289.0], [51.6, 290.0], [51.7, 290.0], [51.8, 290.0], [51.9, 291.0], [52.0, 291.0], [52.1, 291.0], [52.2, 291.0], [52.3, 291.0], [52.4, 291.0], [52.5, 292.0], [52.6, 293.0], [52.7, 293.0], [52.8, 293.0], [52.9, 293.0], [53.0, 293.0], [53.1, 293.0], [53.2, 293.0], [53.3, 294.0], [53.4, 294.0], [53.5, 294.0], [53.6, 294.0], [53.7, 294.0], [53.8, 296.0], [53.9, 297.0], [54.0, 297.0], [54.1, 297.0], [54.2, 297.0], [54.3, 298.0], [54.4, 298.0], [54.5, 298.0], [54.6, 298.0], [54.7, 298.0], [54.8, 299.0], [54.9, 300.0], [55.0, 300.0], [55.1, 301.0], [55.2, 301.0], [55.3, 302.0], [55.4, 302.0], [55.5, 302.0], [55.6, 302.0], [55.7, 302.0], [55.8, 302.0], [55.9, 302.0], [56.0, 302.0], [56.1, 303.0], [56.2, 304.0], [56.3, 304.0], [56.4, 304.0], [56.5, 306.0], [56.6, 306.0], [56.7, 306.0], [56.8, 307.0], [56.9, 308.0], [57.0, 308.0], [57.1, 308.0], [57.2, 308.0], [57.3, 308.0], [57.4, 308.0], [57.5, 309.0], [57.6, 310.0], [57.7, 310.0], [57.8, 311.0], [57.9, 311.0], [58.0, 311.0], [58.1, 311.0], [58.2, 311.0], [58.3, 312.0], [58.4, 312.0], [58.5, 312.0], [58.6, 312.0], [58.7, 312.0], [58.8, 312.0], [58.9, 313.0], [59.0, 313.0], [59.1, 313.0], [59.2, 314.0], [59.3, 315.0], [59.4, 315.0], [59.5, 315.0], [59.6, 316.0], [59.7, 316.0], [59.8, 316.0], [59.9, 316.0], [60.0, 316.0], [60.1, 317.0], [60.2, 318.0], [60.3, 318.0], [60.4, 318.0], [60.5, 318.0], [60.6, 318.0], [60.7, 318.0], [60.8, 318.0], [60.9, 319.0], [61.0, 319.0], [61.1, 319.0], [61.2, 319.0], [61.3, 319.0], [61.4, 319.0], [61.5, 320.0], [61.6, 321.0], [61.7, 321.0], [61.8, 321.0], [61.9, 322.0], [62.0, 322.0], [62.1, 324.0], [62.2, 325.0], [62.3, 325.0], [62.4, 325.0], [62.5, 325.0], [62.6, 326.0], [62.7, 326.0], [62.8, 326.0], [62.9, 327.0], [63.0, 327.0], [63.1, 327.0], [63.2, 327.0], [63.3, 328.0], [63.4, 328.0], [63.5, 329.0], [63.6, 329.0], [63.7, 329.0], [63.8, 330.0], [63.9, 330.0], [64.0, 330.0], [64.1, 331.0], [64.2, 331.0], [64.3, 331.0], [64.4, 331.0], [64.5, 332.0], [64.6, 332.0], [64.7, 332.0], [64.8, 333.0], [64.9, 333.0], [65.0, 333.0], [65.1, 334.0], [65.2, 334.0], [65.3, 334.0], [65.4, 334.0], [65.5, 335.0], [65.6, 335.0], [65.7, 335.0], [65.8, 335.0], [65.9, 336.0], [66.0, 336.0], [66.1, 336.0], [66.2, 337.0], [66.3, 337.0], [66.4, 337.0], [66.5, 337.0], [66.6, 338.0], [66.7, 338.0], [66.8, 338.0], [66.9, 341.0], [67.0, 341.0], [67.1, 341.0], [67.2, 342.0], [67.3, 343.0], [67.4, 343.0], [67.5, 343.0], [67.6, 343.0], [67.7, 343.0], [67.8, 344.0], [67.9, 344.0], [68.0, 344.0], [68.1, 345.0], [68.2, 346.0], [68.3, 346.0], [68.4, 346.0], [68.5, 347.0], [68.6, 348.0], [68.7, 348.0], [68.8, 348.0], [68.9, 349.0], [69.0, 349.0], [69.1, 349.0], [69.2, 351.0], [69.3, 352.0], [69.4, 352.0], [69.5, 353.0], [69.6, 353.0], [69.7, 353.0], [69.8, 353.0], [69.9, 353.0], [70.0, 353.0], [70.1, 354.0], [70.2, 354.0], [70.3, 354.0], [70.4, 354.0], [70.5, 354.0], [70.6, 355.0], [70.7, 355.0], [70.8, 355.0], [70.9, 355.0], [71.0, 355.0], [71.1, 356.0], [71.2, 356.0], [71.3, 356.0], [71.4, 356.0], [71.5, 357.0], [71.6, 357.0], [71.7, 357.0], [71.8, 358.0], [71.9, 359.0], [72.0, 359.0], [72.1, 360.0], [72.2, 361.0], [72.3, 362.0], [72.4, 362.0], [72.5, 363.0], [72.6, 363.0], [72.7, 363.0], [72.8, 363.0], [72.9, 363.0], [73.0, 363.0], [73.1, 363.0], [73.2, 364.0], [73.3, 364.0], [73.4, 364.0], [73.5, 365.0], [73.6, 365.0], [73.7, 365.0], [73.8, 366.0], [73.9, 366.0], [74.0, 366.0], [74.1, 366.0], [74.2, 366.0], [74.3, 367.0], [74.4, 367.0], [74.5, 367.0], [74.6, 367.0], [74.7, 367.0], [74.8, 368.0], [74.9, 369.0], [75.0, 369.0], [75.1, 370.0], [75.2, 370.0], [75.3, 370.0], [75.4, 370.0], [75.5, 371.0], [75.6, 371.0], [75.7, 371.0], [75.8, 374.0], [75.9, 374.0], [76.0, 374.0], [76.1, 374.0], [76.2, 377.0], [76.3, 377.0], [76.4, 377.0], [76.5, 377.0], [76.6, 378.0], [76.7, 378.0], [76.8, 379.0], [76.9, 379.0], [77.0, 379.0], [77.1, 379.0], [77.2, 380.0], [77.3, 381.0], [77.4, 381.0], [77.5, 382.0], [77.6, 382.0], [77.7, 382.0], [77.8, 383.0], [77.9, 385.0], [78.0, 385.0], [78.1, 386.0], [78.2, 388.0], [78.3, 389.0], [78.4, 389.0], [78.5, 389.0], [78.6, 390.0], [78.7, 390.0], [78.8, 390.0], [78.9, 391.0], [79.0, 391.0], [79.1, 391.0], [79.2, 393.0], [79.3, 393.0], [79.4, 393.0], [79.5, 393.0], [79.6, 393.0], [79.7, 393.0], [79.8, 396.0], [79.9, 398.0], [80.0, 398.0], [80.1, 400.0], [80.2, 401.0], [80.3, 402.0], [80.4, 402.0], [80.5, 402.0], [80.6, 403.0], [80.7, 403.0], [80.8, 406.0], [80.9, 406.0], [81.0, 406.0], [81.1, 406.0], [81.2, 406.0], [81.3, 407.0], [81.4, 407.0], [81.5, 408.0], [81.6, 408.0], [81.7, 408.0], [81.8, 409.0], [81.9, 410.0], [82.0, 410.0], [82.1, 410.0], [82.2, 412.0], [82.3, 412.0], [82.4, 412.0], [82.5, 414.0], [82.6, 415.0], [82.7, 415.0], [82.8, 415.0], [82.9, 415.0], [83.0, 415.0], [83.1, 416.0], [83.2, 418.0], [83.3, 418.0], [83.4, 418.0], [83.5, 419.0], [83.6, 420.0], [83.7, 420.0], [83.8, 422.0], [83.9, 422.0], [84.0, 422.0], [84.1, 422.0], [84.2, 424.0], [84.3, 426.0], [84.4, 426.0], [84.5, 430.0], [84.6, 433.0], [84.7, 433.0], [84.8, 433.0], [84.9, 434.0], [85.0, 434.0], [85.1, 436.0], [85.2, 436.0], [85.3, 437.0], [85.4, 437.0], [85.5, 442.0], [85.6, 443.0], [85.7, 443.0], [85.8, 443.0], [85.9, 445.0], [86.0, 445.0], [86.1, 445.0], [86.2, 445.0], [86.3, 446.0], [86.4, 446.0], [86.5, 447.0], [86.6, 449.0], [86.7, 449.0], [86.8, 450.0], [86.9, 456.0], [87.0, 456.0], [87.1, 457.0], [87.2, 463.0], [87.3, 464.0], [87.4, 464.0], [87.5, 466.0], [87.6, 467.0], [87.7, 467.0], [87.8, 468.0], [87.9, 469.0], [88.0, 469.0], [88.1, 474.0], [88.2, 476.0], [88.3, 480.0], [88.4, 480.0], [88.5, 481.0], [88.6, 486.0], [88.7, 486.0], [88.8, 486.0], [88.9, 490.0], [89.0, 493.0], [89.1, 493.0], [89.2, 498.0], [89.3, 499.0], [89.4, 499.0], [89.5, 503.0], [89.6, 505.0], [89.7, 505.0], [89.8, 517.0], [89.9, 518.0], [90.0, 520.0], [90.1, 520.0], [90.2, 520.0], [90.3, 526.0], [90.4, 526.0], [90.5, 536.0], [90.6, 542.0], [90.7, 542.0], [90.8, 547.0], [90.9, 548.0], [91.0, 552.0], [91.1, 552.0], [91.2, 565.0], [91.3, 573.0], [91.4, 573.0], [91.5, 579.0], [91.6, 580.0], [91.7, 580.0], [91.8, 587.0], [91.9, 600.0], [92.0, 621.0], [92.1, 621.0], [92.2, 625.0], [92.3, 627.0], [92.4, 627.0], [92.5, 649.0], [92.6, 658.0], [92.7, 658.0], [92.8, 661.0], [92.9, 666.0], [93.0, 669.0], [93.1, 669.0], [93.2, 671.0], [93.3, 679.0], [93.4, 679.0], [93.5, 681.0], [93.6, 706.0], [93.7, 706.0], [93.8, 708.0], [93.9, 708.0], [94.0, 737.0], [94.1, 737.0], [94.2, 738.0], [94.3, 747.0], [94.4, 747.0], [94.5, 755.0], [94.6, 766.0], [94.7, 766.0], [94.8, 769.0], [94.9, 782.0], [95.0, 822.0], [95.1, 822.0], [95.2, 824.0], [95.3, 831.0], [95.4, 831.0], [95.5, 837.0], [95.6, 841.0], [95.7, 841.0], [95.8, 850.0], [95.9, 852.0], [96.0, 852.0], [96.1, 852.0], [96.2, 862.0], [96.3, 876.0], [96.4, 876.0], [96.5, 893.0], [96.6, 906.0], [96.7, 906.0], [96.8, 912.0], [96.9, 988.0], [97.0, 1544.0], [97.1, 1544.0], [97.2, 1566.0], [97.3, 1654.0], [97.4, 1654.0], [97.5, 1679.0], [97.6, 1683.0], [97.7, 1683.0], [97.8, 1698.0], [97.9, 1916.0], [98.0, 1988.0], [98.1, 1988.0], [98.2, 1996.0], [98.3, 2075.0], [98.4, 2075.0], [98.5, 2239.0], [98.6, 2301.0], [98.7, 2301.0], [98.8, 2301.0], [98.9, 2376.0], [99.0, 2482.0], [99.1, 2482.0], [99.2, 2554.0], [99.3, 2570.0], [99.4, 2570.0], [99.5, 2590.0], [99.6, 2758.0], [99.7, 2758.0], [99.8, 3185.0], [99.9, 3442.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 100.0, "maxY": 367.0, "series": [{"data": [[2300.0, 3.0], [2200.0, 1.0], [600.0, 12.0], [2400.0, 1.0], [2500.0, 3.0], [700.0, 10.0], [2700.0, 1.0], [3100.0, 1.0], [800.0, 11.0], [200.0, 367.0], [3400.0, 1.0], [900.0, 3.0], [300.0, 176.0], [1500.0, 2.0], [1600.0, 4.0], [400.0, 66.0], [100.0, 17.0], [1900.0, 3.0], [2000.0, 1.0], [500.0, 17.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 3400.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 21.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 626.0, "series": [{"data": [[0.0, 626.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 53.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 21.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 4.258064516129034, "minX": 1.62003948E12, "maxY": 5.324652777777779, "series": [{"data": [[1.62003948E12, 5.324652777777779], [1.62003954E12, 4.258064516129034]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.62003954E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 245.0, "minX": 1.0, "maxY": 3442.0, "series": [{"data": [[2.0, 269.9166666666667], [3.0, 250.70093457943935], [4.0, 269.0897959183673], [5.0, 381.0736842105262], [6.0, 437.4651162790698], [7.0, 499.95], [8.0, 563.9166666666666], [9.0, 556.8888888888889], [10.0, 653.375], [11.0, 923.8571428571429], [12.0, 1409.0], [13.0, 3442.0], [15.0, 769.0], [16.0, 1414.0], [1.0, 245.0], [17.0, 885.0], [18.0, 799.5], [19.0, 1961.5], [20.0, 2590.0], [21.0, 1988.0], [22.0, 1333.25], [23.0, 1807.5], [24.0, 1710.0], [25.0, 852.0], [26.0, 2376.0], [27.0, 1669.0], [28.0, 1683.0], [29.0, 2075.0], [30.0, 1610.0], [31.0, 2239.0]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[5.135714285714287, 381.01142857142867]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 31.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 4588.0, "minX": 1.62003948E12, "maxY": 71587.2, "series": [{"data": [[1.62003948E12, 71587.2], [1.62003954E12, 15411.133333333333]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.62003948E12, 21312.0], [1.62003954E12, 4588.0]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.62003954E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 311.68548387096763, "minX": 1.62003948E12, "maxY": 395.93576388888926, "series": [{"data": [[1.62003948E12, 395.93576388888926], [1.62003954E12, 311.68548387096763]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.62003954E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 311.5967741935484, "minX": 1.62003948E12, "maxY": 395.81597222222257, "series": [{"data": [[1.62003948E12, 395.81597222222257], [1.62003954E12, 311.5967741935484]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.62003954E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 21.080645161290324, "minX": 1.62003948E12, "maxY": 76.70486111111111, "series": [{"data": [[1.62003948E12, 76.70486111111111], [1.62003954E12, 21.080645161290324]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.62003954E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 185.0, "minX": 1.62003948E12, "maxY": 3442.0, "series": [{"data": [[1.62003948E12, 3442.0], [1.62003954E12, 679.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.62003948E12, 574.8000000000004], [1.62003954E12, 427.0]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.62003948E12, 2557.6800000000003], [1.62003954E12, 671.5]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.62003948E12, 852.0], [1.62003954E12, 519.25]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.62003948E12, 185.0], [1.62003954E12, 186.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.62003948E12, 284.5], [1.62003954E12, 293.5]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.62003954E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 258.5, "minX": 5.0, "maxY": 1690.5, "series": [{"data": [[8.0, 342.5], [16.0, 439.5], [17.0, 391.0], [18.0, 507.5], [5.0, 1544.0], [10.0, 322.5], [11.0, 258.5], [12.0, 273.0], [13.0, 285.5], [7.0, 766.0], [30.0, 1690.5], [15.0, 279.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 30.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 258.5, "minX": 5.0, "maxY": 1690.5, "series": [{"data": [[8.0, 341.5], [16.0, 439.5], [17.0, 391.0], [18.0, 507.5], [5.0, 1540.0], [10.0, 322.5], [11.0, 258.5], [12.0, 273.0], [13.0, 285.5], [7.0, 766.0], [30.0, 1690.5], [15.0, 279.0]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 30.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 2.0, "minX": 1.62003948E12, "maxY": 9.666666666666666, "series": [{"data": [[1.62003948E12, 9.666666666666666], [1.62003954E12, 2.0]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.62003954E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 2.066666666666667, "minX": 1.62003948E12, "maxY": 9.6, "series": [{"data": [[1.62003948E12, 9.6], [1.62003954E12, 2.066666666666667]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.62003954E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 2.066666666666667, "minX": 1.62003948E12, "maxY": 9.6, "series": [{"data": [[1.62003948E12, 9.6], [1.62003954E12, 2.066666666666667]], "isOverall": false, "label": "HTTP Request-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.62003954E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 2.066666666666667, "minX": 1.62003948E12, "maxY": 9.6, "series": [{"data": [[1.62003948E12, 9.6], [1.62003954E12, 2.066666666666667]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.62003954E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

