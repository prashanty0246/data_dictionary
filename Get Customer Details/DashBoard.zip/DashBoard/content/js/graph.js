/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 18.0, "minX": 0.0, "maxY": 60591.0, "series": [{"data": [[0.0, 18.0], [0.1, 20.0], [0.2, 20.0], [0.3, 21.0], [0.4, 21.0], [0.5, 21.0], [0.6, 22.0], [0.7, 22.0], [0.8, 22.0], [0.9, 22.0], [1.0, 23.0], [1.1, 23.0], [1.2, 23.0], [1.3, 23.0], [1.4, 23.0], [1.5, 24.0], [1.6, 24.0], [1.7, 24.0], [1.8, 24.0], [1.9, 24.0], [2.0, 24.0], [2.1, 25.0], [2.2, 25.0], [2.3, 25.0], [2.4, 25.0], [2.5, 25.0], [2.6, 25.0], [2.7, 26.0], [2.8, 26.0], [2.9, 26.0], [3.0, 26.0], [3.1, 26.0], [3.2, 26.0], [3.3, 27.0], [3.4, 27.0], [3.5, 27.0], [3.6, 27.0], [3.7, 27.0], [3.8, 28.0], [3.9, 28.0], [4.0, 28.0], [4.1, 28.0], [4.2, 28.0], [4.3, 29.0], [4.4, 29.0], [4.5, 29.0], [4.6, 29.0], [4.7, 29.0], [4.8, 30.0], [4.9, 30.0], [5.0, 30.0], [5.1, 30.0], [5.2, 31.0], [5.3, 31.0], [5.4, 31.0], [5.5, 31.0], [5.6, 32.0], [5.7, 32.0], [5.8, 32.0], [5.9, 32.0], [6.0, 33.0], [6.1, 33.0], [6.2, 33.0], [6.3, 34.0], [6.4, 34.0], [6.5, 34.0], [6.6, 35.0], [6.7, 35.0], [6.8, 35.0], [6.9, 36.0], [7.0, 36.0], [7.1, 36.0], [7.2, 37.0], [7.3, 37.0], [7.4, 37.0], [7.5, 38.0], [7.6, 38.0], [7.7, 39.0], [7.8, 39.0], [7.9, 40.0], [8.0, 40.0], [8.1, 41.0], [8.2, 42.0], [8.3, 42.0], [8.4, 42.0], [8.5, 43.0], [8.6, 44.0], [8.7, 44.0], [8.8, 45.0], [8.9, 46.0], [9.0, 46.0], [9.1, 47.0], [9.2, 47.0], [9.3, 48.0], [9.4, 48.0], [9.5, 49.0], [9.6, 50.0], [9.7, 51.0], [9.8, 51.0], [9.9, 52.0], [10.0, 53.0], [10.1, 54.0], [10.2, 55.0], [10.3, 56.0], [10.4, 56.0], [10.5, 57.0], [10.6, 58.0], [10.7, 59.0], [10.8, 59.0], [10.9, 60.0], [11.0, 61.0], [11.1, 62.0], [11.2, 63.0], [11.3, 65.0], [11.4, 65.0], [11.5, 67.0], [11.6, 68.0], [11.7, 70.0], [11.8, 71.0], [11.9, 72.0], [12.0, 74.0], [12.1, 75.0], [12.2, 76.0], [12.3, 77.0], [12.4, 78.0], [12.5, 80.0], [12.6, 80.0], [12.7, 81.0], [12.8, 82.0], [12.9, 83.0], [13.0, 84.0], [13.1, 85.0], [13.2, 86.0], [13.3, 87.0], [13.4, 87.0], [13.5, 88.0], [13.6, 89.0], [13.7, 89.0], [13.8, 91.0], [13.9, 91.0], [14.0, 92.0], [14.1, 93.0], [14.2, 93.0], [14.3, 94.0], [14.4, 94.0], [14.5, 95.0], [14.6, 96.0], [14.7, 97.0], [14.8, 98.0], [14.9, 98.0], [15.0, 99.0], [15.1, 99.0], [15.2, 100.0], [15.3, 100.0], [15.4, 101.0], [15.5, 102.0], [15.6, 103.0], [15.7, 104.0], [15.8, 104.0], [15.9, 105.0], [16.0, 106.0], [16.1, 107.0], [16.2, 108.0], [16.3, 109.0], [16.4, 110.0], [16.5, 111.0], [16.6, 112.0], [16.7, 113.0], [16.8, 114.0], [16.9, 115.0], [17.0, 116.0], [17.1, 117.0], [17.2, 118.0], [17.3, 120.0], [17.4, 121.0], [17.5, 122.0], [17.6, 123.0], [17.7, 125.0], [17.8, 127.0], [17.9, 130.0], [18.0, 132.0], [18.1, 135.0], [18.2, 136.0], [18.3, 138.0], [18.4, 140.0], [18.5, 142.0], [18.6, 144.0], [18.7, 146.0], [18.8, 149.0], [18.9, 153.0], [19.0, 156.0], [19.1, 157.0], [19.2, 159.0], [19.3, 161.0], [19.4, 164.0], [19.5, 166.0], [19.6, 168.0], [19.7, 169.0], [19.8, 171.0], [19.9, 172.0], [20.0, 173.0], [20.1, 175.0], [20.2, 177.0], [20.3, 178.0], [20.4, 179.0], [20.5, 181.0], [20.6, 184.0], [20.7, 185.0], [20.8, 186.0], [20.9, 187.0], [21.0, 189.0], [21.1, 190.0], [21.2, 191.0], [21.3, 192.0], [21.4, 193.0], [21.5, 194.0], [21.6, 195.0], [21.7, 197.0], [21.8, 198.0], [21.9, 199.0], [22.0, 200.0], [22.1, 200.0], [22.2, 201.0], [22.3, 202.0], [22.4, 203.0], [22.5, 203.0], [22.6, 205.0], [22.7, 206.0], [22.8, 206.0], [22.9, 207.0], [23.0, 209.0], [23.1, 210.0], [23.2, 212.0], [23.3, 213.0], [23.4, 214.0], [23.5, 216.0], [23.6, 217.0], [23.7, 219.0], [23.8, 220.0], [23.9, 221.0], [24.0, 223.0], [24.1, 225.0], [24.2, 228.0], [24.3, 232.0], [24.4, 236.0], [24.5, 240.0], [24.6, 243.0], [24.7, 248.0], [24.8, 252.0], [24.9, 255.0], [25.0, 259.0], [25.1, 263.0], [25.2, 265.0], [25.3, 268.0], [25.4, 271.0], [25.5, 274.0], [25.6, 276.0], [25.7, 277.0], [25.8, 279.0], [25.9, 281.0], [26.0, 282.0], [26.1, 284.0], [26.2, 285.0], [26.3, 286.0], [26.4, 287.0], [26.5, 289.0], [26.6, 291.0], [26.7, 294.0], [26.8, 296.0], [26.9, 297.0], [27.0, 300.0], [27.1, 301.0], [27.2, 303.0], [27.3, 303.0], [27.4, 305.0], [27.5, 306.0], [27.6, 308.0], [27.7, 309.0], [27.8, 310.0], [27.9, 312.0], [28.0, 313.0], [28.1, 315.0], [28.2, 316.0], [28.3, 318.0], [28.4, 320.0], [28.5, 323.0], [28.6, 328.0], [28.7, 332.0], [28.8, 338.0], [28.9, 341.0], [29.0, 347.0], [29.1, 352.0], [29.2, 358.0], [29.3, 362.0], [29.4, 365.0], [29.5, 369.0], [29.6, 370.0], [29.7, 372.0], [29.8, 375.0], [29.9, 378.0], [30.0, 379.0], [30.1, 381.0], [30.2, 383.0], [30.3, 385.0], [30.4, 387.0], [30.5, 388.0], [30.6, 391.0], [30.7, 392.0], [30.8, 393.0], [30.9, 394.0], [31.0, 396.0], [31.1, 398.0], [31.2, 400.0], [31.3, 403.0], [31.4, 404.0], [31.5, 406.0], [31.6, 407.0], [31.7, 409.0], [31.8, 411.0], [31.9, 413.0], [32.0, 414.0], [32.1, 419.0], [32.2, 421.0], [32.3, 424.0], [32.4, 427.0], [32.5, 431.0], [32.6, 435.0], [32.7, 442.0], [32.8, 448.0], [32.9, 455.0], [33.0, 457.0], [33.1, 461.0], [33.2, 464.0], [33.3, 468.0], [33.4, 471.0], [33.5, 475.0], [33.6, 478.0], [33.7, 480.0], [33.8, 481.0], [33.9, 483.0], [34.0, 484.0], [34.1, 486.0], [34.2, 488.0], [34.3, 491.0], [34.4, 492.0], [34.5, 494.0], [34.6, 495.0], [34.7, 497.0], [34.8, 498.0], [34.9, 500.0], [35.0, 502.0], [35.1, 504.0], [35.2, 507.0], [35.3, 509.0], [35.4, 511.0], [35.5, 512.0], [35.6, 514.0], [35.7, 516.0], [35.8, 519.0], [35.9, 523.0], [36.0, 529.0], [36.1, 539.0], [36.2, 546.0], [36.3, 553.0], [36.4, 558.0], [36.5, 561.0], [36.6, 564.0], [36.7, 566.0], [36.8, 569.0], [36.9, 574.0], [37.0, 577.0], [37.1, 581.0], [37.2, 584.0], [37.3, 585.0], [37.4, 587.0], [37.5, 589.0], [37.6, 591.0], [37.7, 593.0], [37.8, 594.0], [37.9, 595.0], [38.0, 596.0], [38.1, 598.0], [38.2, 600.0], [38.3, 601.0], [38.4, 603.0], [38.5, 605.0], [38.6, 606.0], [38.7, 608.0], [38.8, 610.0], [38.9, 613.0], [39.0, 614.0], [39.1, 618.0], [39.2, 622.0], [39.3, 624.0], [39.4, 627.0], [39.5, 633.0], [39.6, 638.0], [39.7, 648.0], [39.8, 655.0], [39.9, 659.0], [40.0, 664.0], [40.1, 666.0], [40.2, 668.0], [40.3, 670.0], [40.4, 672.0], [40.5, 674.0], [40.6, 676.0], [40.7, 677.0], [40.8, 679.0], [40.9, 680.0], [41.0, 681.0], [41.1, 682.0], [41.2, 684.0], [41.3, 685.0], [41.4, 686.0], [41.5, 687.0], [41.6, 688.0], [41.7, 689.0], [41.8, 691.0], [41.9, 692.0], [42.0, 693.0], [42.1, 694.0], [42.2, 695.0], [42.3, 697.0], [42.4, 698.0], [42.5, 700.0], [42.6, 701.0], [42.7, 703.0], [42.8, 705.0], [42.9, 706.0], [43.0, 709.0], [43.1, 710.0], [43.2, 711.0], [43.3, 714.0], [43.4, 716.0], [43.5, 718.0], [43.6, 720.0], [43.7, 723.0], [43.8, 725.0], [43.9, 727.0], [44.0, 732.0], [44.1, 738.0], [44.2, 748.0], [44.3, 753.0], [44.4, 757.0], [44.5, 760.0], [44.6, 763.0], [44.7, 766.0], [44.8, 770.0], [44.9, 773.0], [45.0, 775.0], [45.1, 777.0], [45.2, 778.0], [45.3, 779.0], [45.4, 781.0], [45.5, 782.0], [45.6, 784.0], [45.7, 785.0], [45.8, 786.0], [45.9, 787.0], [46.0, 789.0], [46.1, 790.0], [46.2, 792.0], [46.3, 794.0], [46.4, 796.0], [46.5, 797.0], [46.6, 799.0], [46.7, 800.0], [46.8, 802.0], [46.9, 804.0], [47.0, 806.0], [47.1, 807.0], [47.2, 809.0], [47.3, 811.0], [47.4, 813.0], [47.5, 814.0], [47.6, 816.0], [47.7, 819.0], [47.8, 823.0], [47.9, 826.0], [48.0, 829.0], [48.1, 834.0], [48.2, 842.0], [48.3, 848.0], [48.4, 852.0], [48.5, 856.0], [48.6, 861.0], [48.7, 864.0], [48.8, 867.0], [48.9, 870.0], [49.0, 873.0], [49.1, 876.0], [49.2, 877.0], [49.3, 879.0], [49.4, 881.0], [49.5, 884.0], [49.6, 885.0], [49.7, 887.0], [49.8, 889.0], [49.9, 890.0], [50.0, 892.0], [50.1, 894.0], [50.2, 896.0], [50.3, 897.0], [50.4, 899.0], [50.5, 901.0], [50.6, 904.0], [50.7, 906.0], [50.8, 909.0], [50.9, 912.0], [51.0, 913.0], [51.1, 915.0], [51.2, 919.0], [51.3, 925.0], [51.4, 932.0], [51.5, 943.0], [51.6, 952.0], [51.7, 957.0], [51.8, 962.0], [51.9, 965.0], [52.0, 969.0], [52.1, 972.0], [52.2, 974.0], [52.3, 976.0], [52.4, 979.0], [52.5, 981.0], [52.6, 983.0], [52.7, 985.0], [52.8, 988.0], [52.9, 990.0], [53.0, 991.0], [53.1, 993.0], [53.2, 995.0], [53.3, 996.0], [53.4, 999.0], [53.5, 1001.0], [53.6, 1002.0], [53.7, 1004.0], [53.8, 1008.0], [53.9, 1010.0], [54.0, 1012.0], [54.1, 1013.0], [54.2, 1016.0], [54.3, 1020.0], [54.4, 1022.0], [54.5, 1024.0], [54.6, 1029.0], [54.7, 1037.0], [54.8, 1046.0], [54.9, 1050.0], [55.0, 1056.0], [55.1, 1062.0], [55.2, 1067.0], [55.3, 1070.0], [55.4, 1073.0], [55.5, 1075.0], [55.6, 1079.0], [55.7, 1080.0], [55.8, 1083.0], [55.9, 1084.0], [56.0, 1086.0], [56.1, 1088.0], [56.2, 1090.0], [56.3, 1092.0], [56.4, 1094.0], [56.5, 1096.0], [56.6, 1099.0], [56.7, 1101.0], [56.8, 1104.0], [56.9, 1107.0], [57.0, 1109.0], [57.1, 1111.0], [57.2, 1114.0], [57.3, 1118.0], [57.4, 1121.0], [57.5, 1126.0], [57.6, 1133.0], [57.7, 1141.0], [57.8, 1149.0], [57.9, 1153.0], [58.0, 1160.0], [58.1, 1163.0], [58.2, 1166.0], [58.3, 1169.0], [58.4, 1172.0], [58.5, 1174.0], [58.6, 1176.0], [58.7, 1179.0], [58.8, 1181.0], [58.9, 1184.0], [59.0, 1186.0], [59.1, 1188.0], [59.2, 1191.0], [59.3, 1192.0], [59.4, 1193.0], [59.5, 1196.0], [59.6, 1198.0], [59.7, 1200.0], [59.8, 1204.0], [59.9, 1206.0], [60.0, 1209.0], [60.1, 1211.0], [60.2, 1213.0], [60.3, 1214.0], [60.4, 1217.0], [60.5, 1221.0], [60.6, 1231.0], [60.7, 1240.0], [60.8, 1250.0], [60.9, 1255.0], [61.0, 1259.0], [61.1, 1263.0], [61.2, 1266.0], [61.3, 1269.0], [61.4, 1272.0], [61.5, 1275.0], [61.6, 1276.0], [61.7, 1278.0], [61.8, 1280.0], [61.9, 1281.0], [62.0, 1283.0], [62.1, 1285.0], [62.2, 1288.0], [62.3, 1292.0], [62.4, 1294.0], [62.5, 1296.0], [62.6, 1298.0], [62.7, 1300.0], [62.8, 1302.0], [62.9, 1303.0], [63.0, 1306.0], [63.1, 1309.0], [63.2, 1312.0], [63.3, 1315.0], [63.4, 1318.0], [63.5, 1324.0], [63.6, 1330.0], [63.7, 1333.0], [63.8, 1336.0], [63.9, 1341.0], [64.0, 1345.0], [64.1, 1348.0], [64.2, 1352.0], [64.3, 1355.0], [64.4, 1359.0], [64.5, 1362.0], [64.6, 1364.0], [64.7, 1368.0], [64.8, 1371.0], [64.9, 1374.0], [65.0, 1377.0], [65.1, 1381.0], [65.2, 1383.0], [65.3, 1385.0], [65.4, 1386.0], [65.5, 1388.0], [65.6, 1390.0], [65.7, 1391.0], [65.8, 1393.0], [65.9, 1394.0], [66.0, 1395.0], [66.1, 1397.0], [66.2, 1398.0], [66.3, 1399.0], [66.4, 1401.0], [66.5, 1403.0], [66.6, 1405.0], [66.7, 1407.0], [66.8, 1409.0], [66.9, 1412.0], [67.0, 1414.0], [67.1, 1417.0], [67.2, 1419.0], [67.3, 1423.0], [67.4, 1429.0], [67.5, 1438.0], [67.6, 1445.0], [67.7, 1452.0], [67.8, 1454.0], [67.9, 1457.0], [68.0, 1460.0], [68.1, 1462.0], [68.2, 1465.0], [68.3, 1467.0], [68.4, 1470.0], [68.5, 1472.0], [68.6, 1476.0], [68.7, 1478.0], [68.8, 1479.0], [68.9, 1481.0], [69.0, 1483.0], [69.1, 1485.0], [69.2, 1487.0], [69.3, 1489.0], [69.4, 1491.0], [69.5, 1492.0], [69.6, 1493.0], [69.7, 1496.0], [69.8, 1498.0], [69.9, 1500.0], [70.0, 1502.0], [70.1, 1505.0], [70.2, 1509.0], [70.3, 1512.0], [70.4, 1515.0], [70.5, 1521.0], [70.6, 1528.0], [70.7, 1535.0], [70.8, 1545.0], [70.9, 1552.0], [71.0, 1559.0], [71.1, 1563.0], [71.2, 1565.0], [71.3, 1570.0], [71.4, 1573.0], [71.5, 1575.0], [71.6, 1578.0], [71.7, 1580.0], [71.8, 1582.0], [71.9, 1585.0], [72.0, 1588.0], [72.1, 1590.0], [72.2, 1592.0], [72.3, 1595.0], [72.4, 1598.0], [72.5, 1600.0], [72.6, 1602.0], [72.7, 1606.0], [72.8, 1611.0], [72.9, 1616.0], [73.0, 1620.0], [73.1, 1626.0], [73.2, 1630.0], [73.3, 1637.0], [73.4, 1643.0], [73.5, 1650.0], [73.6, 1654.0], [73.7, 1658.0], [73.8, 1663.0], [73.9, 1667.0], [74.0, 1670.0], [74.1, 1672.0], [74.2, 1674.0], [74.3, 1677.0], [74.4, 1679.0], [74.5, 1681.0], [74.6, 1683.0], [74.7, 1686.0], [74.8, 1689.0], [74.9, 1694.0], [75.0, 1697.0], [75.1, 1701.0], [75.2, 1706.0], [75.3, 1710.0], [75.4, 1715.0], [75.5, 1722.0], [75.6, 1728.0], [75.7, 1739.0], [75.8, 1751.0], [75.9, 1759.0], [76.0, 1762.0], [76.1, 1765.0], [76.2, 1767.0], [76.3, 1770.0], [76.4, 1775.0], [76.5, 1778.0], [76.6, 1783.0], [76.7, 1789.0], [76.8, 1795.0], [76.9, 1800.0], [77.0, 1805.0], [77.1, 1812.0], [77.2, 1831.0], [77.3, 1850.0], [77.4, 1863.0], [77.5, 1870.0], [77.6, 1874.0], [77.7, 1881.0], [77.8, 1885.0], [77.9, 1892.0], [78.0, 1897.0], [78.1, 1904.0], [78.2, 1916.0], [78.3, 1927.0], [78.4, 1940.0], [78.5, 1953.0], [78.6, 1965.0], [78.7, 1970.0], [78.8, 1974.0], [78.9, 1978.0], [79.0, 1985.0], [79.1, 1989.0], [79.2, 1992.0], [79.3, 1996.0], [79.4, 2002.0], [79.5, 2008.0], [79.6, 2016.0], [79.7, 2032.0], [79.8, 2052.0], [79.9, 2063.0], [80.0, 2067.0], [80.1, 2074.0], [80.2, 2082.0], [80.3, 2091.0], [80.4, 2104.0], [80.5, 2118.0], [80.6, 2144.0], [80.7, 2165.0], [80.8, 2185.0], [80.9, 2198.0], [81.0, 2212.0], [81.1, 2227.0], [81.2, 2254.0], [81.3, 2277.0], [81.4, 2299.0], [81.5, 2317.0], [81.6, 2359.0], [81.7, 2378.0], [81.8, 2402.0], [81.9, 2437.0], [82.0, 2476.0], [82.1, 2491.0], [82.2, 2502.0], [82.3, 2515.0], [82.4, 2547.0], [82.5, 2587.0], [82.6, 2597.0], [82.7, 2608.0], [82.8, 2644.0], [82.9, 2684.0], [83.0, 2710.0], [83.1, 2762.0], [83.2, 2793.0], [83.3, 2828.0], [83.4, 2875.0], [83.5, 2915.0], [83.6, 2945.0], [83.7, 2989.0], [83.8, 3017.0], [83.9, 3074.0], [84.0, 3103.0], [84.1, 3122.0], [84.2, 3167.0], [84.3, 3197.0], [84.4, 3256.0], [84.5, 3290.0], [84.6, 3318.0], [84.7, 3380.0], [84.8, 3411.0], [84.9, 3465.0], [85.0, 3489.0], [85.1, 3508.0], [85.2, 3560.0], [85.3, 3613.0], [85.4, 3664.0], [85.5, 3701.0], [85.6, 3736.0], [85.7, 3790.0], [85.8, 3831.0], [85.9, 3883.0], [86.0, 3925.0], [86.1, 3983.0], [86.2, 4017.0], [86.3, 4086.0], [86.4, 4121.0], [86.5, 4174.0], [86.6, 4202.0], [86.7, 4237.0], [86.8, 4275.0], [86.9, 4301.0], [87.0, 4335.0], [87.1, 4414.0], [87.2, 4499.0], [87.3, 4582.0], [87.4, 4612.0], [87.5, 4727.0], [87.6, 4798.0], [87.7, 4883.0], [87.8, 4926.0], [87.9, 5006.0], [88.0, 5086.0], [88.1, 5157.0], [88.2, 5206.0], [88.3, 5296.0], [88.4, 5374.0], [88.5, 5427.0], [88.6, 5514.0], [88.7, 5603.0], [88.8, 5705.0], [88.9, 5771.0], [89.0, 5816.0], [89.1, 5904.0], [89.2, 5979.0], [89.3, 6087.0], [89.4, 6141.0], [89.5, 6210.0], [89.6, 6288.0], [89.7, 6376.0], [89.8, 6460.0], [89.9, 6593.0], [90.0, 6696.0], [90.1, 6791.0], [90.2, 6871.0], [90.3, 6903.0], [90.4, 7023.0], [90.5, 7103.0], [90.6, 7194.0], [90.7, 7233.0], [90.8, 7316.0], [90.9, 7418.0], [91.0, 7504.0], [91.1, 7595.0], [91.2, 7714.0], [91.3, 7790.0], [91.4, 7885.0], [91.5, 7973.0], [91.6, 8017.0], [91.7, 8097.0], [91.8, 8159.0], [91.9, 8234.0], [92.0, 8308.0], [92.1, 8383.0], [92.2, 8465.0], [92.3, 8580.0], [92.4, 8667.0], [92.5, 8793.0], [92.6, 8905.0], [92.7, 8994.0], [92.8, 9076.0], [92.9, 9172.0], [93.0, 9274.0], [93.1, 9318.0], [93.2, 9425.0], [93.3, 9504.0], [93.4, 9589.0], [93.5, 9701.0], [93.6, 9795.0], [93.7, 9910.0], [93.8, 10002.0], [93.9, 10177.0], [94.0, 10300.0], [94.1, 10434.0], [94.2, 10586.0], [94.3, 10691.0], [94.4, 10740.0], [94.5, 10809.0], [94.6, 10910.0], [94.7, 11022.0], [94.8, 11118.0], [94.9, 11383.0], [95.0, 11962.0], [95.1, 37465.0], [95.2, 53563.0], [95.3, 60012.0], [95.4, 60013.0], [95.5, 60014.0], [95.6, 60014.0], [95.7, 60015.0], [95.8, 60015.0], [95.9, 60016.0], [96.0, 60016.0], [96.1, 60016.0], [96.2, 60016.0], [96.3, 60017.0], [96.4, 60017.0], [96.5, 60017.0], [96.6, 60018.0], [96.7, 60018.0], [96.8, 60019.0], [96.9, 60019.0], [97.0, 60020.0], [97.1, 60020.0], [97.2, 60021.0], [97.3, 60021.0], [97.4, 60022.0], [97.5, 60023.0], [97.6, 60024.0], [97.7, 60026.0], [97.8, 60027.0], [97.9, 60030.0], [98.0, 60032.0], [98.1, 60034.0], [98.2, 60036.0], [98.3, 60040.0], [98.4, 60045.0], [98.5, 60049.0], [98.6, 60052.0], [98.7, 60055.0], [98.8, 60064.0], [98.9, 60072.0], [99.0, 60084.0], [99.1, 60096.0], [99.2, 60107.0], [99.3, 60119.0], [99.4, 60128.0], [99.5, 60143.0], [99.6, 60169.0], [99.7, 60193.0], [99.8, 60233.0], [99.9, 60290.0], [100.0, 60591.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 2595.0, "series": [{"data": [[0.0, 2595.0], [100.0, 1177.0], [37300.0, 1.0], [37900.0, 2.0], [37700.0, 2.0], [38300.0, 2.0], [38100.0, 2.0], [38500.0, 1.0], [200.0, 857.0], [53500.0, 4.0], [54500.0, 2.0], [53700.0, 1.0], [58700.0, 1.0], [58900.0, 1.0], [60100.0, 101.0], [60300.0, 9.0], [60500.0, 4.0], [300.0, 716.0], [400.0, 634.0], [500.0, 568.0], [600.0, 735.0], [700.0, 715.0], [800.0, 646.0], [900.0, 518.0], [1000.0, 548.0], [1100.0, 526.0], [1200.0, 513.0], [1300.0, 622.0], [1400.0, 609.0], [1500.0, 451.0], [1600.0, 445.0], [1700.0, 309.0], [1800.0, 200.0], [1900.0, 221.0], [2000.0, 177.0], [2100.0, 91.0], [2200.0, 86.0], [2300.0, 64.0], [2400.0, 69.0], [2500.0, 74.0], [2600.0, 55.0], [2700.0, 47.0], [2800.0, 44.0], [2900.0, 48.0], [3000.0, 39.0], [3100.0, 56.0], [3300.0, 38.0], [3200.0, 40.0], [3400.0, 48.0], [3500.0, 38.0], [3600.0, 41.0], [3700.0, 41.0], [3800.0, 36.0], [3900.0, 36.0], [4000.0, 31.0], [4100.0, 45.0], [4200.0, 47.0], [4300.0, 30.0], [4500.0, 25.0], [4400.0, 27.0], [4600.0, 20.0], [4700.0, 25.0], [4800.0, 20.0], [5000.0, 29.0], [5100.0, 21.0], [4900.0, 26.0], [5200.0, 22.0], [5300.0, 24.0], [5500.0, 19.0], [5400.0, 25.0], [5600.0, 16.0], [5700.0, 24.0], [5800.0, 27.0], [5900.0, 26.0], [6100.0, 25.0], [6000.0, 12.0], [6300.0, 19.0], [6200.0, 31.0], [6500.0, 14.0], [6600.0, 14.0], [6400.0, 16.0], [6800.0, 26.0], [6900.0, 13.0], [6700.0, 22.0], [7100.0, 25.0], [7000.0, 23.0], [7300.0, 13.0], [7200.0, 23.0], [7400.0, 24.0], [7600.0, 13.0], [7500.0, 20.0], [7700.0, 23.0], [7900.0, 23.0], [7800.0, 18.0], [8100.0, 28.0], [8000.0, 25.0], [8600.0, 20.0], [8500.0, 18.0], [8300.0, 28.0], [8400.0, 16.0], [8700.0, 9.0], [8200.0, 19.0], [9100.0, 22.0], [9000.0, 17.0], [8900.0, 23.0], [8800.0, 14.0], [9200.0, 20.0], [9700.0, 18.0], [9300.0, 18.0], [9400.0, 22.0], [9500.0, 18.0], [9600.0, 16.0], [10100.0, 11.0], [10000.0, 10.0], [9900.0, 22.0], [9800.0, 11.0], [10200.0, 13.0], [10600.0, 17.0], [10700.0, 28.0], [10400.0, 9.0], [10300.0, 13.0], [10500.0, 15.0], [10800.0, 20.0], [11000.0, 16.0], [10900.0, 15.0], [11200.0, 5.0], [11100.0, 12.0], [11400.0, 3.0], [11700.0, 3.0], [11300.0, 7.0], [11500.0, 6.0], [11800.0, 3.0], [12000.0, 3.0], [11900.0, 3.0], [12100.0, 2.0], [12200.0, 1.0], [12700.0, 1.0], [12900.0, 1.0], [14000.0, 1.0], [36800.0, 1.0], [36600.0, 1.0], [37400.0, 3.0], [37800.0, 1.0], [37200.0, 1.0], [37600.0, 2.0], [38200.0, 2.0], [38600.0, 1.0], [57400.0, 1.0], [59000.0, 1.0], [58200.0, 2.0], [60000.0, 665.0], [60200.0, 31.0], [60400.0, 1.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 60500.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 818.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 6000.0, "series": [{"data": [[0.0, 5988.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 6000.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 4341.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [[3.0, 818.0]], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 50.0, "minX": 1.6427583E12, "maxY": 150.0, "series": [{"data": [[1.6427583E12, 50.0], [1.64275878E12, 150.0], [1.6427586E12, 146.59749999999988], [1.64275842E12, 97.46401515151507], [1.6427589E12, 150.0], [1.64275872E12, 150.0], [1.64275854E12, 100.0], [1.64275836E12, 50.0], [1.64275884E12, 150.0], [1.64275866E12, 150.0], [1.64275896E12, 75.65999999999998], [1.64275848E12, 100.0]], "isOverall": false, "label": "bzm - Concurrency Thread Group-ThreadStarter", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64275896E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 116.0, "minX": 1.0, "maxY": 60325.0, "series": [{"data": [[2.0, 60013.0], [3.0, 60014.0], [4.0, 60017.0], [5.0, 60019.0], [6.0, 60025.0], [7.0, 60022.0], [8.0, 60030.0], [9.0, 60031.0], [10.0, 60038.0], [11.0, 60035.0], [12.0, 60017.0], [13.0, 60034.0], [14.0, 60026.0], [15.0, 60025.0], [16.0, 60021.0], [17.0, 60027.0], [18.0, 60021.0], [21.0, 60063.0], [22.0, 60064.0], [23.0, 60064.0], [24.0, 60063.0], [25.0, 60034.0], [26.0, 60013.0], [27.0, 60018.0], [28.0, 60016.0], [29.0, 60021.0], [30.0, 60018.0], [31.0, 60033.0], [32.0, 60051.0], [35.0, 60051.0], [34.0, 60048.5], [37.0, 60074.0], [36.0, 60065.0], [38.0, 60068.0], [41.0, 60066.0], [40.0, 60072.0], [43.0, 60054.0], [42.0, 60057.0], [44.0, 60028.0], [47.0, 60051.0], [46.0, 60052.0], [49.0, 60052.5], [50.0, 5909.665249734327], [51.0, 60031.0], [52.0, 60032.5], [53.0, 60041.0], [54.0, 60029.333333333336], [55.0, 60050.0], [57.0, 60049.0], [56.0, 60046.0], [59.0, 60020.0], [58.0, 60023.0], [61.0, 60143.0], [60.0, 60144.0], [62.0, 60103.0], [63.0, 60071.4], [64.0, 60105.0], [67.0, 60131.0], [66.0, 60155.5], [71.0, 60096.0], [70.0, 60083.0], [69.0, 60087.0], [68.0, 60079.0], [75.0, 60124.0], [74.0, 60127.0], [73.0, 60101.0], [72.0, 60102.0], [79.0, 60037.0], [78.0, 60121.0], [77.0, 60119.0], [76.0, 60125.0], [83.0, 60090.0], [82.0, 60099.0], [81.0, 60095.0], [80.0, 60036.0], [87.0, 60046.0], [86.0, 60047.333333333336], [91.0, 60112.0], [90.0, 60063.0], [89.0, 60016.0], [88.0, 60040.0], [95.0, 60196.0], [94.0, 60196.0], [93.0, 60113.5], [99.0, 60290.0], [98.0, 60287.0], [97.0, 60288.0], [96.0, 60267.0], [100.0, 6064.013574660634], [103.0, 60229.0], [102.0, 60237.0], [101.0, 60290.0], [107.0, 60223.0], [106.0, 60233.0], [105.0, 60229.0], [104.0, 60229.0], [111.0, 60031.0], [110.0, 60027.0], [109.0, 60035.0], [108.0, 60019.0], [115.0, 60026.0], [114.0, 60038.0], [113.0, 60035.0], [112.0, 60039.0], [118.0, 12065.0], [119.0, 60066.0], [117.0, 60012.0], [116.0, 60021.0], [120.0, 30074.5], [121.0, 116.0], [122.0, 128.5], [124.0, 36238.2], [127.0, 60325.0], [126.0, 60262.0], [128.0, 30279.5], [129.0, 30285.5], [130.0, 30281.5], [131.0, 30270.0], [132.0, 5207.333333333334], [133.0, 20236.0], [135.0, 30176.0], [134.0, 60318.0], [136.0, 30126.5], [138.0, 15071.75], [143.0, 60042.0], [142.0, 60071.0], [141.0, 60082.0], [140.0, 60097.0], [139.0, 60094.0], [137.0, 60195.0], [146.0, 30088.5], [147.0, 30342.5], [150.0, 3339.1723163841793], [149.0, 60015.0], [148.0, 60040.0], [145.0, 60035.0], [144.0, 60041.0], [1.0, 60014.0]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[137.33918469703036, 4341.519974339552]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 150.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 243.33333333333334, "minX": 1.6427583E12, "maxY": 236292.25, "series": [{"data": [[1.6427583E12, 40091.85], [1.64275878E12, 208863.46666666667], [1.6427586E12, 14339.683333333332], [1.64275842E12, 22559.95], [1.6427589E12, 43442.1], [1.64275872E12, 104141.8], [1.64275854E12, 9553.716666666667], [1.64275836E12, 243.33333333333334], [1.64275884E12, 236292.25], [1.64275866E12, 14219.483333333334], [1.64275896E12, 730.0], [1.64275848E12, 61798.25]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.6427583E12, 29449.5], [1.64275878E12, 153848.25], [1.6427586E12, 13540.0], [1.64275842E12, 17872.8], [1.6427589E12, 31920.55], [1.64275872E12, 81070.75], [1.64275854E12, 10019.6], [1.64275836E12, 1692.5], [1.64275884E12, 173616.65], [1.64275866E12, 14995.55], [1.64275896E12, 5077.5], [1.64275848E12, 47322.3]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64275896E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 1620.9056203605503, "minX": 1.6427583E12, "maxY": 60141.100000000006, "series": [{"data": [[1.6427583E12, 1751.732183908047], [1.64275878E12, 2067.2688668866876], [1.6427586E12, 14919.617500000006], [1.64275842E12, 6279.196969696973], [1.6427589E12, 1620.9056203605503], [1.64275872E12, 4858.26764091858], [1.64275854E12, 20478.067567567577], [1.64275836E12, 60141.100000000006], [1.64275884E12, 1715.3684928836017], [1.64275866E12, 20362.89841986457], [1.64275896E12, 60102.26666666664], [1.64275848E12, 3701.129470672391]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64275896E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 1620.9024390243897, "minX": 1.6427583E12, "maxY": 60141.08, "series": [{"data": [[1.6427583E12, 1751.675862068966], [1.64275878E12, 2067.2611661166115], [1.6427586E12, 14919.594999999996], [1.64275842E12, 6279.1893939393885], [1.6427589E12, 1620.9024390243897], [1.64275872E12, 4858.255114822538], [1.64275854E12, 20478.04729729731], [1.64275836E12, 60141.08], [1.64275884E12, 1715.36322869955], [1.64275866E12, 20362.889390519216], [1.64275896E12, 60102.26000000001], [1.64275848E12, 3701.1072961373397]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64275896E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 21.74662162162163, "minX": 1.6427583E12, "maxY": 277.11034482758595, "series": [{"data": [[1.6427583E12, 277.11034482758595], [1.64275878E12, 136.91573157315688], [1.6427586E12, 51.09249999999999], [1.64275842E12, 48.081439393939405], [1.6427589E12, 90.36055143160131], [1.64275872E12, 100.67014613778726], [1.64275854E12, 21.74662162162163], [1.64275836E12, 132.16000000000003], [1.64275884E12, 112.88340807174882], [1.64275866E12, 33.87810383747175], [1.64275896E12, 100.81333333333333], [1.64275848E12, 59.680972818311865]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64275896E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 18.0, "minX": 1.6427583E12, "maxY": 59076.0, "series": [{"data": [[1.6427583E12, 4325.0], [1.64275878E12, 12293.0], [1.6427586E12, 613.0], [1.64275842E12, 59076.0], [1.6427589E12, 11511.0], [1.64275872E12, 10627.0], [1.64275854E12, 14057.0], [1.64275884E12, 11548.0], [1.64275866E12, 283.0], [1.64275848E12, 38697.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.6427583E12, 2498.8], [1.64275878E12, 5080.800000000001], [1.6427586E12, 253.8], [1.64275842E12, 2011.0], [1.6427589E12, 5578.4], [1.64275872E12, 3127.8], [1.64275854E12, 267.0000000000001], [1.64275884E12, 5320.0], [1.64275866E12, 49.60000000000002], [1.64275848E12, 971.8000000000002]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.6427583E12, 4275.87], [1.64275878E12, 10608.69], [1.6427586E12, 525.98], [1.64275842E12, 58272.45], [1.6427589E12, 10829.479999999996], [1.64275872E12, 9713.939999999999], [1.64275854E12, 12980.960000000012], [1.64275884E12, 10817.199999999999], [1.64275866E12, 230.90000000000003], [1.64275848E12, 37693.44000000001]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.6427583E12, 3992.0999999999985], [1.64275878E12, 7902.199999999993], [1.6427586E12, 304.39999999999986], [1.64275842E12, 2231.0], [1.6427589E12, 8471.399999999996], [1.64275872E12, 4371.299999999975], [1.64275854E12, 2146.4999999999523], [1.64275884E12, 8000.5], [1.64275866E12, 78.80000000000007], [1.64275848E12, 1296.2]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.6427583E12, 890.0], [1.64275878E12, 18.0], [1.6427586E12, 21.0], [1.64275842E12, 19.0], [1.6427589E12, 20.0], [1.64275872E12, 20.0], [1.64275854E12, 20.0], [1.64275884E12, 18.0], [1.64275866E12, 21.0], [1.64275848E12, 19.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.6427583E12, 1615.5], [1.64275878E12, 1207.0], [1.6427586E12, 40.0], [1.64275842E12, 676.5], [1.6427589E12, 709.0], [1.64275872E12, 461.0], [1.64275854E12, 42.0], [1.64275884E12, 899.0], [1.64275866E12, 27.0], [1.64275848E12, 334.0]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.6427589E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 24.5, "minX": 1.0, "maxY": 60185.0, "series": [{"data": [[2.0, 27.0], [3.0, 43.0], [4.0, 25.0], [5.0, 27.0], [6.0, 26.5], [7.0, 1307.5], [8.0, 28.5], [9.0, 890.0], [10.0, 30.0], [11.0, 24.5], [12.0, 38.0], [14.0, 31.5], [15.0, 27.0], [16.0, 1181.5], [17.0, 25.0], [18.0, 3489.0], [20.0, 45.0], [22.0, 1535.5], [26.0, 1338.0], [27.0, 25.0], [28.0, 1467.5], [29.0, 2028.0], [30.0, 1408.5], [33.0, 542.0], [32.0, 446.5], [35.0, 1403.5], [36.0, 139.0], [39.0, 41.0], [38.0, 1400.5], [40.0, 4223.0], [41.0, 1083.0], [43.0, 1769.5], [45.0, 1402.0], [44.0, 189.0], [46.0, 1654.0], [47.0, 1176.0], [49.0, 2548.5], [48.0, 1299.0], [50.0, 1636.5], [51.0, 1258.0], [53.0, 42.0], [52.0, 31.0], [55.0, 786.0], [57.0, 82.5], [56.0, 197.5], [58.0, 145.0], [59.0, 1085.0], [61.0, 690.5], [60.0, 799.0], [62.0, 507.0], [63.0, 999.5], [65.0, 293.0], [66.0, 183.5], [67.0, 314.0], [64.0, 1217.5], [70.0, 750.5], [74.0, 474.5], [75.0, 319.0], [72.0, 965.0], [73.0, 369.0], [77.0, 382.0], [79.0, 1079.5], [76.0, 668.0], [83.0, 655.5], [81.0, 322.0], [80.0, 688.0], [82.0, 240.0], [84.0, 942.0], [87.0, 893.0], [85.0, 232.0], [86.0, 735.0], [90.0, 31.5], [91.0, 599.0], [89.0, 788.5], [88.0, 443.5], [94.0, 493.0], [92.0, 695.0], [93.0, 255.0], [95.0, 313.0], [96.0, 493.5], [99.0, 1188.0], [98.0, 605.0], [97.0, 785.0], [102.0, 709.0], [100.0, 99.0], [103.0, 381.5], [107.0, 989.0], [106.0, 810.0], [105.0, 1268.0], [104.0, 869.0], [108.0, 193.0], [109.0, 1164.0], [111.0, 3103.0], [110.0, 305.5], [115.0, 994.0], [112.0, 1089.0], [113.0, 1345.5], [114.0, 889.0], [118.0, 266.0], [116.0, 633.5], [122.0, 1957.0], [121.0, 6426.0], [126.0, 542.0], [124.0, 1787.0], [125.0, 1314.0], [133.0, 619.0], [129.0, 1525.5], [128.0, 1102.5], [139.0, 7874.5], [141.0, 6862.0], [142.0, 5821.0], [147.0, 5576.0], [144.0, 689.0], [148.0, 5124.0], [152.0, 7002.5], [167.0, 4512.0], [163.0, 1052.0], [1.0, 3368.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[2.0, 60017.0], [39.0, 60021.0], [41.0, 60021.0], [45.0, 60017.0], [46.0, 60035.0], [47.0, 60024.0], [3.0, 60022.0], [48.0, 60018.0], [51.0, 60016.0], [53.0, 60026.0], [52.0, 60015.0], [57.0, 60042.0], [59.0, 60017.5], [62.0, 60093.5], [63.0, 60017.0], [65.0, 60018.5], [4.0, 60014.0], [70.0, 60021.0], [74.0, 60017.5], [5.0, 60016.0], [82.0, 60013.0], [85.0, 60024.0], [90.0, 60097.5], [91.0, 60023.5], [92.0, 60018.0], [95.0, 60022.0], [6.0, 60014.5], [99.0, 60024.0], [107.0, 60020.5], [7.0, 60014.0], [8.0, 60015.5], [133.0, 60023.5], [9.0, 60017.0], [10.0, 60025.0], [11.0, 60014.5], [12.0, 60021.0], [13.0, 60089.0], [14.0, 60016.5], [1.0, 60014.0], [17.0, 60020.0], [18.0, 60030.0], [20.0, 60107.0], [21.0, 60090.0], [23.0, 60123.0], [26.0, 60017.5], [27.0, 60185.0], [29.0, 60052.0], [31.0, 60034.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 167.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 24.5, "minX": 1.0, "maxY": 60185.0, "series": [{"data": [[2.0, 26.0], [3.0, 43.0], [4.0, 25.0], [5.0, 27.0], [6.0, 26.5], [7.0, 1307.5], [8.0, 28.5], [9.0, 889.0], [10.0, 30.0], [11.0, 24.5], [12.0, 38.0], [14.0, 31.5], [15.0, 27.0], [16.0, 1181.5], [17.0, 25.0], [18.0, 3489.0], [20.0, 45.0], [22.0, 1535.5], [26.0, 1338.0], [27.0, 25.0], [28.0, 1467.5], [29.0, 2028.0], [30.0, 1408.5], [33.0, 542.0], [32.0, 446.5], [35.0, 1403.5], [36.0, 139.0], [39.0, 41.0], [38.0, 1400.5], [40.0, 4223.0], [41.0, 1083.0], [43.0, 1769.5], [45.0, 1402.0], [44.0, 189.0], [46.0, 1654.0], [47.0, 1176.0], [49.0, 2548.5], [48.0, 1299.0], [50.0, 1636.5], [51.0, 1258.0], [53.0, 42.0], [52.0, 31.0], [55.0, 786.0], [57.0, 82.5], [56.0, 197.5], [58.0, 145.0], [59.0, 1085.0], [61.0, 690.5], [60.0, 799.0], [62.0, 507.0], [63.0, 999.5], [65.0, 293.0], [66.0, 183.5], [67.0, 314.0], [64.0, 1217.5], [70.0, 750.5], [74.0, 474.5], [75.0, 319.0], [72.0, 965.0], [73.0, 369.0], [77.0, 382.0], [79.0, 1079.5], [76.0, 668.0], [83.0, 655.5], [81.0, 322.0], [80.0, 687.5], [82.0, 240.0], [84.0, 942.0], [87.0, 893.0], [85.0, 232.0], [86.0, 735.0], [90.0, 31.5], [91.0, 599.0], [89.0, 788.5], [88.0, 443.5], [94.0, 493.0], [92.0, 695.0], [93.0, 255.0], [95.0, 313.0], [96.0, 493.5], [99.0, 1188.0], [98.0, 605.0], [97.0, 785.0], [102.0, 709.0], [100.0, 99.0], [103.0, 381.5], [107.0, 989.0], [106.0, 810.0], [105.0, 1268.0], [104.0, 869.0], [108.0, 193.0], [109.0, 1164.0], [111.0, 3103.0], [110.0, 305.5], [115.0, 994.0], [112.0, 1089.0], [113.0, 1345.5], [114.0, 889.0], [118.0, 266.0], [116.0, 633.5], [122.0, 1957.0], [121.0, 6426.0], [126.0, 542.0], [124.0, 1787.0], [125.0, 1314.0], [133.0, 619.0], [129.0, 1525.5], [128.0, 1102.5], [139.0, 7874.5], [141.0, 6862.0], [142.0, 5821.0], [147.0, 5576.0], [144.0, 689.0], [148.0, 5124.0], [152.0, 7002.5], [167.0, 4512.0], [163.0, 1052.0], [1.0, 3368.0]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[2.0, 60017.0], [39.0, 60021.0], [41.0, 60021.0], [45.0, 60017.0], [46.0, 60035.0], [47.0, 60024.0], [3.0, 60022.0], [48.0, 60018.0], [51.0, 60015.5], [53.0, 60026.0], [52.0, 60015.0], [57.0, 60042.0], [59.0, 60017.5], [62.0, 60093.5], [63.0, 60017.0], [65.0, 60018.5], [4.0, 60014.0], [70.0, 60021.0], [74.0, 60017.5], [5.0, 60016.0], [82.0, 60013.0], [85.0, 60024.0], [90.0, 60097.5], [91.0, 60023.5], [92.0, 60018.0], [95.0, 60022.0], [6.0, 60014.5], [99.0, 60024.0], [107.0, 60020.5], [7.0, 60014.0], [8.0, 60015.5], [133.0, 60023.5], [9.0, 60017.0], [10.0, 60025.0], [11.0, 60014.5], [12.0, 60021.0], [13.0, 60089.0], [14.0, 60016.5], [1.0, 60014.0], [17.0, 60020.0], [18.0, 60030.0], [20.0, 60107.0], [21.0, 60090.0], [23.0, 60123.0], [26.0, 60017.5], [27.0, 60185.0], [29.0, 60052.0], [31.0, 60034.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 167.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 0.8333333333333334, "minX": 1.6427583E12, "maxY": 85.48333333333333, "series": [{"data": [[1.6427583E12, 15.333333333333334], [1.64275878E12, 75.75], [1.6427586E12, 7.516666666666667], [1.64275842E12, 9.633333333333333], [1.6427589E12, 15.716666666666667], [1.64275872E12, 39.916666666666664], [1.64275854E12, 4.933333333333334], [1.64275836E12, 0.8333333333333334], [1.64275884E12, 85.48333333333333], [1.64275866E12, 7.383333333333334], [1.64275848E12, 23.283333333333335]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.6427589E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.11666666666666667, "minX": 1.6427583E12, "maxY": 85.48333333333333, "series": [{"data": [[1.6427583E12, 14.5], [1.64275878E12, 75.53333333333333], [1.6427586E12, 5.016666666666667], [1.64275842E12, 8.066666666666666], [1.6427589E12, 15.716666666666667], [1.64275872E12, 37.416666666666664], [1.64275854E12, 3.283333333333333], [1.64275884E12, 85.48333333333333], [1.64275866E12, 4.883333333333334], [1.64275848E12, 22.25]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.64275842E12, 0.11666666666666667]], "isOverall": false, "label": "503", "isController": false}, {"data": [[1.64275878E12, 0.21666666666666667], [1.6427586E12, 1.65], [1.64275842E12, 0.6166666666666667], [1.64275872E12, 2.5], [1.64275854E12, 1.65], [1.64275836E12, 0.8333333333333334], [1.64275866E12, 2.5], [1.64275896E12, 2.5], [1.64275848E12, 1.05]], "isOverall": false, "label": "504", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.64275896E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.21666666666666667, "minX": 1.6427583E12, "maxY": 85.48333333333333, "series": [{"data": [[1.6427583E12, 14.5], [1.64275878E12, 75.53333333333333], [1.6427586E12, 5.016666666666667], [1.64275842E12, 8.066666666666666], [1.6427589E12, 15.716666666666667], [1.64275872E12, 37.416666666666664], [1.64275854E12, 3.283333333333333], [1.64275884E12, 85.48333333333333], [1.64275866E12, 4.883333333333334], [1.64275848E12, 22.25]], "isOverall": false, "label": "HTTP Request-success", "isController": false}, {"data": [[1.64275878E12, 0.21666666666666667], [1.6427586E12, 1.65], [1.64275842E12, 0.7333333333333333], [1.64275872E12, 2.5], [1.64275854E12, 1.65], [1.64275836E12, 0.8333333333333334], [1.64275866E12, 2.5], [1.64275896E12, 2.5], [1.64275848E12, 1.05]], "isOverall": false, "label": "HTTP Request-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64275896E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 0.21666666666666667, "minX": 1.6427583E12, "maxY": 85.48333333333333, "series": [{"data": [[1.6427583E12, 14.5], [1.64275878E12, 75.53333333333333], [1.6427586E12, 5.016666666666667], [1.64275842E12, 8.066666666666666], [1.6427589E12, 15.716666666666667], [1.64275872E12, 37.416666666666664], [1.64275854E12, 3.283333333333333], [1.64275884E12, 85.48333333333333], [1.64275866E12, 4.883333333333334], [1.64275848E12, 22.25]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [[1.64275878E12, 0.21666666666666667], [1.6427586E12, 1.65], [1.64275842E12, 0.7333333333333333], [1.64275872E12, 2.5], [1.64275854E12, 1.65], [1.64275836E12, 0.8333333333333334], [1.64275866E12, 2.5], [1.64275896E12, 2.5], [1.64275848E12, 1.05]], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.64275896E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 19800000);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

