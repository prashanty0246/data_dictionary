/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
});


var responseTimePercentilesInfos = {
        data: {"result": {"minY": 152.0, "minX": 0.0, "maxY": 26343.0, "series": [{"data": [[0.0, 152.0], [0.1, 260.0], [0.2, 297.0], [0.3, 300.0], [0.4, 305.0], [0.5, 317.0], [0.6, 321.0], [0.7, 323.0], [0.8, 326.0], [0.9, 333.0], [1.0, 337.0], [1.1, 343.0], [1.2, 344.0], [1.3, 352.0], [1.4, 356.0], [1.5, 359.0], [1.6, 364.0], [1.7, 366.0], [1.8, 369.0], [1.9, 370.0], [2.0, 372.0], [2.1, 375.0], [2.2, 376.0], [2.3, 378.0], [2.4, 382.0], [2.5, 387.0], [2.6, 388.0], [2.7, 389.0], [2.8, 390.0], [2.9, 393.0], [3.0, 395.0], [3.1, 398.0], [3.2, 400.0], [3.3, 401.0], [3.4, 403.0], [3.5, 404.0], [3.6, 407.0], [3.7, 411.0], [3.8, 415.0], [3.9, 417.0], [4.0, 418.0], [4.1, 422.0], [4.2, 425.0], [4.3, 427.0], [4.4, 429.0], [4.5, 432.0], [4.6, 436.0], [4.7, 438.0], [4.8, 439.0], [4.9, 441.0], [5.0, 443.0], [5.1, 444.0], [5.2, 445.0], [5.3, 450.0], [5.4, 452.0], [5.5, 454.0], [5.6, 457.0], [5.7, 461.0], [5.8, 463.0], [5.9, 464.0], [6.0, 465.0], [6.1, 470.0], [6.2, 473.0], [6.3, 476.0], [6.4, 478.0], [6.5, 479.0], [6.6, 482.0], [6.7, 483.0], [6.8, 485.0], [6.9, 486.0], [7.0, 487.0], [7.1, 492.0], [7.2, 495.0], [7.3, 497.0], [7.4, 503.0], [7.5, 504.0], [7.6, 505.0], [7.7, 506.0], [7.8, 511.0], [7.9, 513.0], [8.0, 515.0], [8.1, 517.0], [8.2, 519.0], [8.3, 521.0], [8.4, 524.0], [8.5, 527.0], [8.6, 530.0], [8.7, 532.0], [8.8, 538.0], [8.9, 540.0], [9.0, 541.0], [9.1, 544.0], [9.2, 546.0], [9.3, 549.0], [9.4, 551.0], [9.5, 553.0], [9.6, 555.0], [9.7, 557.0], [9.8, 561.0], [9.9, 562.0], [10.0, 564.0], [10.1, 565.0], [10.2, 568.0], [10.3, 569.0], [10.4, 573.0], [10.5, 574.0], [10.6, 579.0], [10.7, 585.0], [10.8, 589.0], [10.9, 591.0], [11.0, 593.0], [11.1, 595.0], [11.2, 597.0], [11.3, 598.0], [11.4, 602.0], [11.5, 605.0], [11.6, 607.0], [11.7, 610.0], [11.8, 617.0], [11.9, 620.0], [12.0, 623.0], [12.1, 626.0], [12.2, 629.0], [12.3, 633.0], [12.4, 637.0], [12.5, 639.0], [12.6, 643.0], [12.7, 646.0], [12.8, 654.0], [12.9, 659.0], [13.0, 662.0], [13.1, 664.0], [13.2, 670.0], [13.3, 671.0], [13.4, 674.0], [13.5, 678.0], [13.6, 679.0], [13.7, 684.0], [13.8, 689.0], [13.9, 693.0], [14.0, 696.0], [14.1, 702.0], [14.2, 706.0], [14.3, 710.0], [14.4, 714.0], [14.5, 718.0], [14.6, 719.0], [14.7, 725.0], [14.8, 728.0], [14.9, 731.0], [15.0, 735.0], [15.1, 742.0], [15.2, 747.0], [15.3, 750.0], [15.4, 752.0], [15.5, 754.0], [15.6, 758.0], [15.7, 762.0], [15.8, 767.0], [15.9, 771.0], [16.0, 775.0], [16.1, 780.0], [16.2, 782.0], [16.3, 791.0], [16.4, 798.0], [16.5, 802.0], [16.6, 807.0], [16.7, 811.0], [16.8, 825.0], [16.9, 829.0], [17.0, 837.0], [17.1, 844.0], [17.2, 845.0], [17.3, 850.0], [17.4, 853.0], [17.5, 864.0], [17.6, 869.0], [17.7, 874.0], [17.8, 883.0], [17.9, 888.0], [18.0, 897.0], [18.1, 905.0], [18.2, 916.0], [18.3, 923.0], [18.4, 926.0], [18.5, 931.0], [18.6, 944.0], [18.7, 952.0], [18.8, 960.0], [18.9, 965.0], [19.0, 969.0], [19.1, 983.0], [19.2, 990.0], [19.3, 1000.0], [19.4, 1004.0], [19.5, 1007.0], [19.6, 1016.0], [19.7, 1018.0], [19.8, 1022.0], [19.9, 1025.0], [20.0, 1026.0], [20.1, 1028.0], [20.2, 1035.0], [20.3, 1038.0], [20.4, 1047.0], [20.5, 1054.0], [20.6, 1056.0], [20.7, 1067.0], [20.8, 1072.0], [20.9, 1079.0], [21.0, 1084.0], [21.1, 1098.0], [21.2, 1107.0], [21.3, 1122.0], [21.4, 1130.0], [21.5, 1135.0], [21.6, 1148.0], [21.7, 1152.0], [21.8, 1159.0], [21.9, 1168.0], [22.0, 1184.0], [22.1, 1188.0], [22.2, 1196.0], [22.3, 1204.0], [22.4, 1217.0], [22.5, 1224.0], [22.6, 1239.0], [22.7, 1253.0], [22.8, 1263.0], [22.9, 1273.0], [23.0, 1284.0], [23.1, 1298.0], [23.2, 1320.0], [23.3, 1324.0], [23.4, 1337.0], [23.5, 1357.0], [23.6, 1371.0], [23.7, 1379.0], [23.8, 1388.0], [23.9, 1391.0], [24.0, 1405.0], [24.1, 1408.0], [24.2, 1420.0], [24.3, 1422.0], [24.4, 1431.0], [24.5, 1440.0], [24.6, 1450.0], [24.7, 1460.0], [24.8, 1469.0], [24.9, 1476.0], [25.0, 1483.0], [25.1, 1485.0], [25.2, 1499.0], [25.3, 1512.0], [25.4, 1521.0], [25.5, 1533.0], [25.6, 1543.0], [25.7, 1551.0], [25.8, 1559.0], [25.9, 1570.0], [26.0, 1581.0], [26.1, 1595.0], [26.2, 1622.0], [26.3, 1631.0], [26.4, 1640.0], [26.5, 1655.0], [26.6, 1669.0], [26.7, 1695.0], [26.8, 1706.0], [26.9, 1732.0], [27.0, 1746.0], [27.1, 1757.0], [27.2, 1775.0], [27.3, 1788.0], [27.4, 1792.0], [27.5, 1799.0], [27.6, 1807.0], [27.7, 1823.0], [27.8, 1830.0], [27.9, 1849.0], [28.0, 1859.0], [28.1, 1884.0], [28.2, 1893.0], [28.3, 1896.0], [28.4, 1923.0], [28.5, 1932.0], [28.6, 1941.0], [28.7, 1955.0], [28.8, 1978.0], [28.9, 1997.0], [29.0, 2002.0], [29.1, 2013.0], [29.2, 2020.0], [29.3, 2030.0], [29.4, 2055.0], [29.5, 2062.0], [29.6, 2081.0], [29.7, 2107.0], [29.8, 2114.0], [29.9, 2130.0], [30.0, 2138.0], [30.1, 2168.0], [30.2, 2187.0], [30.3, 2215.0], [30.4, 2236.0], [30.5, 2259.0], [30.6, 2271.0], [30.7, 2282.0], [30.8, 2295.0], [30.9, 2313.0], [31.0, 2316.0], [31.1, 2326.0], [31.2, 2330.0], [31.3, 2341.0], [31.4, 2348.0], [31.5, 2354.0], [31.6, 2358.0], [31.7, 2364.0], [31.8, 2369.0], [31.9, 2374.0], [32.0, 2381.0], [32.1, 2384.0], [32.2, 2394.0], [32.3, 2398.0], [32.4, 2403.0], [32.5, 2410.0], [32.6, 2418.0], [32.7, 2434.0], [32.8, 2456.0], [32.9, 2480.0], [33.0, 2489.0], [33.1, 2510.0], [33.2, 2524.0], [33.3, 2532.0], [33.4, 2559.0], [33.5, 2566.0], [33.6, 2577.0], [33.7, 2603.0], [33.8, 2616.0], [33.9, 2619.0], [34.0, 2647.0], [34.1, 2649.0], [34.2, 2662.0], [34.3, 2678.0], [34.4, 2698.0], [34.5, 2711.0], [34.6, 2716.0], [34.7, 2724.0], [34.8, 2743.0], [34.9, 2750.0], [35.0, 2778.0], [35.1, 2801.0], [35.2, 2806.0], [35.3, 2823.0], [35.4, 2833.0], [35.5, 2838.0], [35.6, 2844.0], [35.7, 2856.0], [35.8, 2874.0], [35.9, 2882.0], [36.0, 2890.0], [36.1, 2903.0], [36.2, 2918.0], [36.3, 2922.0], [36.4, 2938.0], [36.5, 2953.0], [36.6, 2972.0], [36.7, 2976.0], [36.8, 2990.0], [36.9, 3020.0], [37.0, 3041.0], [37.1, 3070.0], [37.2, 3082.0], [37.3, 3114.0], [37.4, 3121.0], [37.5, 3140.0], [37.6, 3162.0], [37.7, 3174.0], [37.8, 3182.0], [37.9, 3207.0], [38.0, 3224.0], [38.1, 3236.0], [38.2, 3250.0], [38.3, 3267.0], [38.4, 3275.0], [38.5, 3290.0], [38.6, 3303.0], [38.7, 3316.0], [38.8, 3323.0], [38.9, 3330.0], [39.0, 3346.0], [39.1, 3359.0], [39.2, 3373.0], [39.3, 3381.0], [39.4, 3388.0], [39.5, 3404.0], [39.6, 3415.0], [39.7, 3430.0], [39.8, 3446.0], [39.9, 3457.0], [40.0, 3467.0], [40.1, 3483.0], [40.2, 3487.0], [40.3, 3498.0], [40.4, 3505.0], [40.5, 3508.0], [40.6, 3510.0], [40.7, 3521.0], [40.8, 3530.0], [40.9, 3544.0], [41.0, 3559.0], [41.1, 3566.0], [41.2, 3570.0], [41.3, 3582.0], [41.4, 3590.0], [41.5, 3600.0], [41.6, 3614.0], [41.7, 3618.0], [41.8, 3621.0], [41.9, 3645.0], [42.0, 3664.0], [42.1, 3679.0], [42.2, 3684.0], [42.3, 3695.0], [42.4, 3707.0], [42.5, 3728.0], [42.6, 3731.0], [42.7, 3739.0], [42.8, 3753.0], [42.9, 3771.0], [43.0, 3776.0], [43.1, 3791.0], [43.2, 3798.0], [43.3, 3810.0], [43.4, 3813.0], [43.5, 3816.0], [43.6, 3820.0], [43.7, 3823.0], [43.8, 3830.0], [43.9, 3838.0], [44.0, 3845.0], [44.1, 3854.0], [44.2, 3865.0], [44.3, 3878.0], [44.4, 3881.0], [44.5, 3894.0], [44.6, 3905.0], [44.7, 3915.0], [44.8, 3924.0], [44.9, 3940.0], [45.0, 3962.0], [45.1, 3988.0], [45.2, 3995.0], [45.3, 4002.0], [45.4, 4015.0], [45.5, 4034.0], [45.6, 4049.0], [45.7, 4056.0], [45.8, 4058.0], [45.9, 4060.0], [46.0, 4083.0], [46.1, 4093.0], [46.2, 4101.0], [46.3, 4106.0], [46.4, 4112.0], [46.5, 4123.0], [46.6, 4131.0], [46.7, 4139.0], [46.8, 4158.0], [46.9, 4165.0], [47.0, 4168.0], [47.1, 4173.0], [47.2, 4192.0], [47.3, 4210.0], [47.4, 4217.0], [47.5, 4228.0], [47.6, 4234.0], [47.7, 4238.0], [47.8, 4240.0], [47.9, 4245.0], [48.0, 4261.0], [48.1, 4267.0], [48.2, 4276.0], [48.3, 4285.0], [48.4, 4324.0], [48.5, 4342.0], [48.6, 4346.0], [48.7, 4357.0], [48.8, 4366.0], [48.9, 4382.0], [49.0, 4396.0], [49.1, 4411.0], [49.2, 4419.0], [49.3, 4423.0], [49.4, 4436.0], [49.5, 4455.0], [49.6, 4468.0], [49.7, 4481.0], [49.8, 4488.0], [49.9, 4512.0], [50.0, 4516.0], [50.1, 4533.0], [50.2, 4540.0], [50.3, 4550.0], [50.4, 4559.0], [50.5, 4575.0], [50.6, 4578.0], [50.7, 4594.0], [50.8, 4602.0], [50.9, 4607.0], [51.0, 4615.0], [51.1, 4632.0], [51.2, 4654.0], [51.3, 4663.0], [51.4, 4667.0], [51.5, 4681.0], [51.6, 4701.0], [51.7, 4713.0], [51.8, 4727.0], [51.9, 4754.0], [52.0, 4759.0], [52.1, 4763.0], [52.2, 4773.0], [52.3, 4789.0], [52.4, 4800.0], [52.5, 4839.0], [52.6, 4861.0], [52.7, 4876.0], [52.8, 4881.0], [52.9, 4919.0], [53.0, 4937.0], [53.1, 4951.0], [53.2, 4972.0], [53.3, 4995.0], [53.4, 5004.0], [53.5, 5035.0], [53.6, 5055.0], [53.7, 5078.0], [53.8, 5101.0], [53.9, 5106.0], [54.0, 5125.0], [54.1, 5157.0], [54.2, 5169.0], [54.3, 5178.0], [54.4, 5187.0], [54.5, 5198.0], [54.6, 5210.0], [54.7, 5220.0], [54.8, 5249.0], [54.9, 5270.0], [55.0, 5280.0], [55.1, 5306.0], [55.2, 5309.0], [55.3, 5334.0], [55.4, 5344.0], [55.5, 5354.0], [55.6, 5369.0], [55.7, 5390.0], [55.8, 5408.0], [55.9, 5425.0], [56.0, 5440.0], [56.1, 5456.0], [56.2, 5474.0], [56.3, 5488.0], [56.4, 5497.0], [56.5, 5503.0], [56.6, 5516.0], [56.7, 5523.0], [56.8, 5527.0], [56.9, 5541.0], [57.0, 5551.0], [57.1, 5557.0], [57.2, 5570.0], [57.3, 5594.0], [57.4, 5610.0], [57.5, 5637.0], [57.6, 5661.0], [57.7, 5670.0], [57.8, 5693.0], [57.9, 5703.0], [58.0, 5720.0], [58.1, 5732.0], [58.2, 5752.0], [58.3, 5762.0], [58.4, 5769.0], [58.5, 5791.0], [58.6, 5797.0], [58.7, 5805.0], [58.8, 5814.0], [58.9, 5834.0], [59.0, 5837.0], [59.1, 5841.0], [59.2, 5855.0], [59.3, 5875.0], [59.4, 5914.0], [59.5, 5925.0], [59.6, 5929.0], [59.7, 5938.0], [59.8, 5953.0], [59.9, 5983.0], [60.0, 5994.0], [60.1, 6012.0], [60.2, 6028.0], [60.3, 6042.0], [60.4, 6058.0], [60.5, 6065.0], [60.6, 6105.0], [60.7, 6120.0], [60.8, 6128.0], [60.9, 6138.0], [61.0, 6146.0], [61.1, 6156.0], [61.2, 6163.0], [61.3, 6169.0], [61.4, 6191.0], [61.5, 6205.0], [61.6, 6218.0], [61.7, 6234.0], [61.8, 6248.0], [61.9, 6256.0], [62.0, 6266.0], [62.1, 6281.0], [62.2, 6289.0], [62.3, 6302.0], [62.4, 6322.0], [62.5, 6331.0], [62.6, 6349.0], [62.7, 6354.0], [62.8, 6359.0], [62.9, 6364.0], [63.0, 6371.0], [63.1, 6394.0], [63.2, 6396.0], [63.3, 6404.0], [63.4, 6411.0], [63.5, 6420.0], [63.6, 6428.0], [63.7, 6443.0], [63.8, 6446.0], [63.9, 6453.0], [64.0, 6458.0], [64.1, 6469.0], [64.2, 6472.0], [64.3, 6475.0], [64.4, 6480.0], [64.5, 6488.0], [64.6, 6493.0], [64.7, 6502.0], [64.8, 6507.0], [64.9, 6517.0], [65.0, 6524.0], [65.1, 6527.0], [65.2, 6528.0], [65.3, 6531.0], [65.4, 6539.0], [65.5, 6545.0], [65.6, 6550.0], [65.7, 6555.0], [65.8, 6558.0], [65.9, 6568.0], [66.0, 6571.0], [66.1, 6583.0], [66.2, 6592.0], [66.3, 6598.0], [66.4, 6616.0], [66.5, 6640.0], [66.6, 6649.0], [66.7, 6672.0], [66.8, 6698.0], [66.9, 6710.0], [67.0, 6731.0], [67.1, 6741.0], [67.2, 6744.0], [67.3, 6752.0], [67.4, 6773.0], [67.5, 6783.0], [67.6, 6791.0], [67.7, 6801.0], [67.8, 6815.0], [67.9, 6830.0], [68.0, 6834.0], [68.1, 6845.0], [68.2, 6853.0], [68.3, 6867.0], [68.4, 6880.0], [68.5, 6884.0], [68.6, 6899.0], [68.7, 6906.0], [68.8, 6916.0], [68.9, 6944.0], [69.0, 6961.0], [69.1, 6991.0], [69.2, 7002.0], [69.3, 7010.0], [69.4, 7016.0], [69.5, 7025.0], [69.6, 7042.0], [69.7, 7050.0], [69.8, 7056.0], [69.9, 7066.0], [70.0, 7084.0], [70.1, 7096.0], [70.2, 7113.0], [70.3, 7125.0], [70.4, 7133.0], [70.5, 7143.0], [70.6, 7151.0], [70.7, 7163.0], [70.8, 7226.0], [70.9, 7249.0], [71.0, 7264.0], [71.1, 7277.0], [71.2, 7321.0], [71.3, 7333.0], [71.4, 7334.0], [71.5, 7351.0], [71.6, 7364.0], [71.7, 7369.0], [71.8, 7378.0], [71.9, 7390.0], [72.0, 7391.0], [72.1, 7396.0], [72.2, 7402.0], [72.3, 7406.0], [72.4, 7432.0], [72.5, 7444.0], [72.6, 7458.0], [72.7, 7488.0], [72.8, 7496.0], [72.9, 7507.0], [73.0, 7514.0], [73.1, 7524.0], [73.2, 7547.0], [73.3, 7571.0], [73.4, 7592.0], [73.5, 7612.0], [73.6, 7629.0], [73.7, 7634.0], [73.8, 7643.0], [73.9, 7648.0], [74.0, 7679.0], [74.1, 7694.0], [74.2, 7717.0], [74.3, 7728.0], [74.4, 7739.0], [74.5, 7757.0], [74.6, 7775.0], [74.7, 7786.0], [74.8, 7798.0], [74.9, 7816.0], [75.0, 7827.0], [75.1, 7837.0], [75.2, 7846.0], [75.3, 7868.0], [75.4, 7891.0], [75.5, 7893.0], [75.6, 7907.0], [75.7, 7912.0], [75.8, 7916.0], [75.9, 7923.0], [76.0, 7935.0], [76.1, 7949.0], [76.2, 7970.0], [76.3, 8000.0], [76.4, 8014.0], [76.5, 8031.0], [76.6, 8055.0], [76.7, 8084.0], [76.8, 8108.0], [76.9, 8136.0], [77.0, 8149.0], [77.1, 8160.0], [77.2, 8177.0], [77.3, 8214.0], [77.4, 8241.0], [77.5, 8254.0], [77.6, 8259.0], [77.7, 8294.0], [77.8, 8311.0], [77.9, 8330.0], [78.0, 8337.0], [78.1, 8351.0], [78.2, 8383.0], [78.3, 8389.0], [78.4, 8392.0], [78.5, 8400.0], [78.6, 8429.0], [78.7, 8449.0], [78.8, 8462.0], [78.9, 8476.0], [79.0, 8484.0], [79.1, 8493.0], [79.2, 8522.0], [79.3, 8536.0], [79.4, 8555.0], [79.5, 8561.0], [79.6, 8578.0], [79.7, 8586.0], [79.8, 8598.0], [79.9, 8614.0], [80.0, 8623.0], [80.1, 8644.0], [80.2, 8664.0], [80.3, 8681.0], [80.4, 8696.0], [80.5, 8712.0], [80.6, 8735.0], [80.7, 8744.0], [80.8, 8781.0], [80.9, 8793.0], [81.0, 8825.0], [81.1, 8850.0], [81.2, 8871.0], [81.3, 8898.0], [81.4, 8923.0], [81.5, 8965.0], [81.6, 8986.0], [81.7, 8998.0], [81.8, 9025.0], [81.9, 9054.0], [82.0, 9083.0], [82.1, 9099.0], [82.2, 9109.0], [82.3, 9131.0], [82.4, 9178.0], [82.5, 9235.0], [82.6, 9271.0], [82.7, 9315.0], [82.8, 9350.0], [82.9, 9370.0], [83.0, 9399.0], [83.1, 9423.0], [83.2, 9427.0], [83.3, 9465.0], [83.4, 9522.0], [83.5, 9550.0], [83.6, 9574.0], [83.7, 9613.0], [83.8, 9619.0], [83.9, 9637.0], [84.0, 9653.0], [84.1, 9687.0], [84.2, 9745.0], [84.3, 9772.0], [84.4, 9818.0], [84.5, 9853.0], [84.6, 9898.0], [84.7, 9934.0], [84.8, 9946.0], [84.9, 9964.0], [85.0, 9983.0], [85.1, 10016.0], [85.2, 10024.0], [85.3, 10042.0], [85.4, 10049.0], [85.5, 10073.0], [85.6, 10084.0], [85.7, 10120.0], [85.8, 10151.0], [85.9, 10166.0], [86.0, 10182.0], [86.1, 10207.0], [86.2, 10263.0], [86.3, 10278.0], [86.4, 10305.0], [86.5, 10317.0], [86.6, 10344.0], [86.7, 10356.0], [86.8, 10369.0], [86.9, 10387.0], [87.0, 10410.0], [87.1, 10422.0], [87.2, 10436.0], [87.3, 10444.0], [87.4, 10528.0], [87.5, 10548.0], [87.6, 10559.0], [87.7, 10581.0], [87.8, 10588.0], [87.9, 10652.0], [88.0, 10673.0], [88.1, 10692.0], [88.2, 10703.0], [88.3, 10722.0], [88.4, 10749.0], [88.5, 10758.0], [88.6, 10779.0], [88.7, 10789.0], [88.8, 10809.0], [88.9, 10825.0], [89.0, 10844.0], [89.1, 10856.0], [89.2, 10869.0], [89.3, 10891.0], [89.4, 10904.0], [89.5, 10955.0], [89.6, 10971.0], [89.7, 10983.0], [89.8, 11027.0], [89.9, 11068.0], [90.0, 11077.0], [90.1, 11153.0], [90.2, 11195.0], [90.3, 11222.0], [90.4, 11243.0], [90.5, 11273.0], [90.6, 11284.0], [90.7, 11326.0], [90.8, 11381.0], [90.9, 11411.0], [91.0, 11444.0], [91.1, 11448.0], [91.2, 11457.0], [91.3, 11465.0], [91.4, 11524.0], [91.5, 11558.0], [91.6, 11573.0], [91.7, 11607.0], [91.8, 11659.0], [91.9, 11730.0], [92.0, 11810.0], [92.1, 11859.0], [92.2, 11904.0], [92.3, 11985.0], [92.4, 12100.0], [92.5, 12151.0], [92.6, 12269.0], [92.7, 12386.0], [92.8, 12422.0], [92.9, 12486.0], [93.0, 12567.0], [93.1, 12633.0], [93.2, 12697.0], [93.3, 12744.0], [93.4, 12809.0], [93.5, 12863.0], [93.6, 12939.0], [93.7, 12994.0], [93.8, 13026.0], [93.9, 13084.0], [94.0, 13213.0], [94.1, 13281.0], [94.2, 13301.0], [94.3, 13323.0], [94.4, 13332.0], [94.5, 13356.0], [94.6, 13386.0], [94.7, 13409.0], [94.8, 13481.0], [94.9, 13514.0], [95.0, 13579.0], [95.1, 13649.0], [95.2, 13767.0], [95.3, 13944.0], [95.4, 13997.0], [95.5, 14034.0], [95.6, 14047.0], [95.7, 14228.0], [95.8, 14297.0], [95.9, 14348.0], [96.0, 14393.0], [96.1, 14416.0], [96.2, 14453.0], [96.3, 14487.0], [96.4, 14636.0], [96.5, 14715.0], [96.6, 14768.0], [96.7, 14822.0], [96.8, 14870.0], [96.9, 14890.0], [97.0, 14914.0], [97.1, 14943.0], [97.2, 14958.0], [97.3, 15009.0], [97.4, 15108.0], [97.5, 15126.0], [97.6, 15412.0], [97.7, 15619.0], [97.8, 15781.0], [97.9, 15878.0], [98.0, 16075.0], [98.1, 16276.0], [98.2, 16437.0], [98.3, 16517.0], [98.4, 16704.0], [98.5, 16751.0], [98.6, 17301.0], [98.7, 17837.0], [98.8, 18459.0], [98.9, 19512.0], [99.0, 20198.0], [99.1, 20595.0], [99.2, 20944.0], [99.3, 21929.0], [99.4, 22673.0], [99.5, 22798.0], [99.6, 22848.0], [99.7, 23056.0], [99.8, 23277.0], [99.9, 25156.0], [100.0, 26343.0]], "isOverall": false, "label": "HTTP Request dyna", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

/**
 * @param elementId Id of element where we display message
 */
function setEmptyGraph(elementId) {
    $(function() {
        $(elementId).text("No graph series with filter="+seriesFilter);
    });
}

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimePercentiles");
        return;
    }
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 100.0, "maxY": 175.0, "series": [{"data": [[100.0, 2.0], [200.0, 9.0], [300.0, 124.0], [400.0, 175.0], [500.0, 172.0], [600.0, 115.0], [700.0, 101.0], [800.0, 67.0], [900.0, 54.0], [1000.0, 77.0], [1100.0, 48.0], [1200.0, 37.0], [1300.0, 36.0], [1400.0, 53.0], [1500.0, 39.0], [1600.0, 26.0], [1700.0, 33.0], [1800.0, 34.0], [1900.0, 28.0], [2000.0, 28.0], [2100.0, 26.0], [2300.0, 63.0], [2200.0, 25.0], [2400.0, 31.0], [2500.0, 27.0], [2600.0, 31.0], [2800.0, 42.0], [2700.0, 29.0], [2900.0, 32.0], [3000.0, 18.0], [3100.0, 25.0], [3300.0, 38.0], [3200.0, 30.0], [3400.0, 39.0], [3500.0, 48.0], [3700.0, 37.0], [3600.0, 36.0], [3800.0, 57.0], [3900.0, 29.0], [4000.0, 40.0], [4200.0, 46.0], [4100.0, 46.0], [4300.0, 29.0], [4500.0, 38.0], [4600.0, 37.0], [4400.0, 33.0], [4700.0, 34.0], [4800.0, 19.0], [5100.0, 31.0], [5000.0, 20.0], [4900.0, 21.0], [5300.0, 31.0], [5200.0, 22.0], [5600.0, 25.0], [5400.0, 28.0], [5500.0, 37.0], [5700.0, 32.0], [5800.0, 30.0], [6000.0, 23.0], [6100.0, 36.0], [5900.0, 30.0], [6200.0, 36.0], [6300.0, 40.0], [6400.0, 62.0], [6500.0, 69.0], [6600.0, 21.0], [6700.0, 36.0], [6800.0, 40.0], [6900.0, 24.0], [7100.0, 27.0], [7000.0, 41.0], [7300.0, 42.0], [7400.0, 30.0], [7200.0, 17.0], [7500.0, 25.0], [7600.0, 30.0], [7900.0, 32.0], [7800.0, 28.0], [7700.0, 30.0], [8100.0, 21.0], [8000.0, 21.0], [8200.0, 19.0], [8500.0, 29.0], [8700.0, 23.0], [8400.0, 27.0], [8300.0, 33.0], [8600.0, 25.0], [9000.0, 17.0], [9100.0, 14.0], [8800.0, 15.0], [8900.0, 17.0], [9200.0, 9.0], [9300.0, 16.0], [9400.0, 16.0], [9700.0, 9.0], [9500.0, 12.0], [9600.0, 19.0], [10100.0, 19.0], [10000.0, 25.0], [9900.0, 17.0], [10200.0, 13.0], [9800.0, 12.0], [10400.0, 17.0], [10700.0, 28.0], [10300.0, 26.0], [10600.0, 12.0], [10500.0, 19.0], [10800.0, 26.0], [11000.0, 12.0], [11100.0, 8.0], [11200.0, 19.0], [10900.0, 16.0], [11400.0, 22.0], [11300.0, 7.0], [11600.0, 7.0], [11500.0, 14.0], [11700.0, 6.0], [11800.0, 8.0], [12100.0, 7.0], [12200.0, 3.0], [11900.0, 6.0], [12000.0, 3.0], [12400.0, 7.0], [12700.0, 7.0], [12300.0, 5.0], [12600.0, 8.0], [12500.0, 5.0], [12800.0, 8.0], [12900.0, 7.0], [13000.0, 8.0], [13300.0, 21.0], [13200.0, 9.0], [13100.0, 2.0], [13400.0, 9.0], [13700.0, 5.0], [13600.0, 4.0], [13500.0, 7.0], [13800.0, 1.0], [14300.0, 10.0], [13900.0, 5.0], [14000.0, 10.0], [14200.0, 5.0], [14100.0, 2.0], [14700.0, 6.0], [14600.0, 6.0], [14400.0, 11.0], [14800.0, 12.0], [14500.0, 2.0], [15100.0, 6.0], [14900.0, 16.0], [15000.0, 3.0], [15200.0, 2.0], [15300.0, 2.0], [15800.0, 5.0], [15400.0, 2.0], [15700.0, 2.0], [15600.0, 3.0], [15500.0, 2.0], [15900.0, 2.0], [16100.0, 2.0], [16200.0, 3.0], [16000.0, 2.0], [16300.0, 2.0], [17400.0, 2.0], [17200.0, 1.0], [16400.0, 3.0], [16600.0, 1.0], [18200.0, 2.0], [17800.0, 1.0], [18000.0, 1.0], [18400.0, 1.0], [19000.0, 1.0], [19200.0, 1.0], [20000.0, 1.0], [20400.0, 1.0], [20800.0, 1.0], [21800.0, 1.0], [22800.0, 6.0], [22600.0, 2.0], [23000.0, 3.0], [23200.0, 1.0], [25400.0, 1.0], [16700.0, 6.0], [17300.0, 2.0], [16500.0, 5.0], [17100.0, 1.0], [18100.0, 1.0], [18500.0, 1.0], [19700.0, 1.0], [20300.0, 1.0], [20100.0, 2.0], [19500.0, 1.0], [20500.0, 2.0], [20900.0, 5.0], [20700.0, 1.0], [21900.0, 1.0], [22500.0, 1.0], [22300.0, 1.0], [23300.0, 1.0], [22900.0, 2.0], [22700.0, 4.0], [23100.0, 1.0], [23700.0, 2.0], [25300.0, 1.0], [25100.0, 1.0], [26300.0, 1.0], [25900.0, 1.0]], "isOverall": false, "label": "HTTP Request dyna", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 26300.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeDistribution");
        return;
    }
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 312.0, "minX": 0.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 3176.0, "series": [{"data": [[0.0, 312.0]], "color": "#9ACD32", "isOverall": false, "label": "Requests having \nresponse time <= 500ms", "isController": false}, {"data": [[1.0, 758.0]], "color": "yellow", "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[2.0, 3176.0]], "color": "orange", "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}, {"data": [], "color": "#FF6347", "isOverall": false, "label": "Requests in error", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 2.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 13.0, "minX": 1.63049112E12, "maxY": 75.0, "series": [{"data": [[1.6304913E12, 35.41326530612245], [1.63049112E12, 13.0], [1.6304916E12, 75.0], [1.63049118E12, 14.04564315352697], [1.63049148E12, 64.4968287526427], [1.63049166E12, 75.0], [1.63049154E12, 75.0], [1.63049136E12, 44.166666666666686], [1.63049142E12, 54.968888888888905], [1.63049172E12, 66.62310030395136], [1.63049124E12, 25.0]], "isOverall": false, "label": "bzm - Concurrency Thread Group-ThreadStarter", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.63049172E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 688.0, "minX": 1.0, "maxY": 25951.0, "series": [{"data": [[2.0, 25951.0], [3.0, 10866.0], [4.0, 2919.0], [5.0, 5618.0], [6.0, 4058.0], [7.0, 5834.0], [8.0, 6253.0], [9.0, 6499.0], [10.0, 6061.0], [11.0, 6325.0], [12.0, 6806.0], [13.0, 1367.9482758620684], [14.0, 7737.0], [15.0, 7798.0], [17.0, 7818.0], [18.0, 7757.0], [20.0, 8700.0], [21.0, 8828.0], [22.0, 8773.0], [23.0, 8986.0], [24.0, 23791.0], [25.0, 1702.1741803278683], [26.0, 25156.0], [27.0, 11243.0], [28.0, 10983.0], [29.0, 16075.0], [30.0, 16224.0], [33.0, 18535.0], [32.0, 17393.0], [35.0, 20198.0], [34.0, 19242.0], [37.0, 19512.0], [36.0, 15228.0], [38.0, 2995.3214285714253], [39.0, 22315.0], [41.0, 688.0], [40.0, 22831.0], [43.0, 23277.0], [42.0, 22582.0], [45.0, 22899.0], [46.0, 23416.0], [49.0, 4914.0], [48.0, 23113.0], [50.0, 4879.189591078068], [51.0, 725.0], [52.0, 22825.0], [55.0, 22797.5], [54.0, 22768.0], [57.0, 22848.0], [56.0, 22848.0], [59.0, 2013.0], [60.0, 2158.5], [63.0, 5860.453151618401], [62.0, 2617.0], [67.0, 22914.0], [66.0, 22713.0], [65.0, 2979.0], [64.0, 2732.0], [71.0, 3452.0], [70.0, 3537.0], [68.0, 23065.0], [75.0, 7510.558926487749], [74.0, 22661.0], [73.0, 3297.0], [1.0, 11649.0]], "isOverall": false, "label": "HTTP Request dyna", "isController": false}, {"data": [[54.706076307112596, 5353.673339613769]], "isOverall": false, "label": "HTTP Request dyna-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 75.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTimeVsThreads");
        return;
    }
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 2309.2, "minX": 1.63049112E12, "maxY": 23158.8, "series": [{"data": [[1.6304913E12, 13114.533333333333], [1.63049112E12, 2309.2], [1.6304916E12, 15853.85], [1.63049118E12, 8065.466666666666], [1.63049148E12, 15824.783333333333], [1.63049166E12, 16051.35], [1.63049154E12, 14915.133333333333], [1.63049136E12, 16861.15], [1.63049142E12, 15054.5], [1.63049172E12, 11002.283333333333], [1.63049124E12, 12983.416666666666]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.6304913E12, 18012.4], [1.63049112E12, 3170.55], [1.6304916E12, 21780.3], [1.63049118E12, 11073.95], [1.63049148E12, 21734.35], [1.63049166E12, 22056.0], [1.63049154E12, 20493.7], [1.63049136E12, 23158.8], [1.63049142E12, 20677.5], [1.63049172E12, 15117.55], [1.63049124E12, 17828.6]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.63049172E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 1309.767634854772, "minX": 1.63049112E12, "maxY": 9090.012158054713, "series": [{"data": [[1.6304913E12, 3425.755102040817], [1.63049112E12, 1320.2028985507247], [1.6304916E12, 8665.938818565404], [1.63049118E12, 1309.767634854772], [1.63049148E12, 6218.363636363633], [1.63049166E12, 6687.135416666665], [1.63049154E12, 7157.764573991036], [1.63049136E12, 2874.9583333333353], [1.63049142E12, 5319.004444444443], [1.63049172E12, 9090.012158054713], [1.63049124E12, 1798.3994845360828]], "isOverall": false, "label": "HTTP Request dyna", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.63049172E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyResponseTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 1309.721991701244, "minX": 1.63049112E12, "maxY": 9089.960486322185, "series": [{"data": [[1.6304913E12, 3425.7193877551013], [1.63049112E12, 1320.0724637681158], [1.6304916E12, 8665.928270042192], [1.63049118E12, 1309.721991701244], [1.63049148E12, 6218.334038054968], [1.63049166E12, 6687.12916666667], [1.63049154E12, 7157.724215246639], [1.63049136E12, 2874.920634920635], [1.63049142E12, 5318.977777777777], [1.63049172E12, 9089.960486322185], [1.63049124E12, 1798.3376288659786]], "isOverall": false, "label": "HTTP Request dyna", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.63049172E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyLatenciesOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 34.398176291793284, "minX": 1.63049112E12, "maxY": 396.5362318840579, "series": [{"data": [[1.6304913E12, 58.77806122448979], [1.63049112E12, 396.5362318840579], [1.6304916E12, 40.723628691983095], [1.63049118E12, 39.95850622406642], [1.63049148E12, 43.10359408033826], [1.63049166E12, 54.88749999999992], [1.63049154E12, 59.89686098654711], [1.63049136E12, 47.43650793650793], [1.63049142E12, 47.417777777777786], [1.63049172E12, 34.398176291793284], [1.63049124E12, 42.68556701030927]], "isOverall": false, "label": "HTTP Request dyna", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.63049172E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyConnectTimeOverTime");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 152.0, "minX": 1.63049112E12, "maxY": 26343.0, "series": [{"data": [[1.6304913E12, 15804.0], [1.63049112E12, 7137.0], [1.6304916E12, 21929.0], [1.63049118E12, 11043.0], [1.63049148E12, 17484.0], [1.63049166E12, 18149.0], [1.63049154E12, 19071.0], [1.63049136E12, 13997.0], [1.63049142E12, 17404.0], [1.63049172E12, 26343.0], [1.63049124E12, 11185.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.6304913E12, 7469.999999999999], [1.63049112E12, 2890.0], [1.6304916E12, 14714.5], [1.63049118E12, 5409.200000000001], [1.63049148E12, 10832.800000000001], [1.63049166E12, 10541.900000000001], [1.63049154E12, 12917.2], [1.63049136E12, 6532.5], [1.63049142E12, 8710.8], [1.63049172E12, 20944.0], [1.63049124E12, 4701.8]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.6304913E12, 14749.949999999997], [1.63049112E12, 7137.0], [1.6304916E12, 17355.5], [1.63049118E12, 10801.56], [1.63049148E12, 16714.92], [1.63049166E12, 13836.07], [1.63049154E12, 16633.839999999993], [1.63049136E12, 11245.399999999996], [1.63049142E12, 12154.910000000005], [1.63049172E12, 25411.8], [1.63049124E12, 8041.4000000000115]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.6304913E12, 11780.099999999999], [1.63049112E12, 5554.0], [1.6304916E12, 15748.75], [1.63049118E12, 6069.199999999999], [1.63049148E12, 11556.79999999999], [1.63049166E12, 11460.75], [1.63049154E12, 14885.1], [1.63049136E12, 8393.25], [1.63049142E12, 10910.55], [1.63049172E12, 22873.5], [1.63049124E12, 6103.399999999999]], "isOverall": false, "label": "95th percentile", "isController": false}, {"data": [[1.6304913E12, 343.0], [1.63049112E12, 304.0], [1.6304916E12, 435.0], [1.63049118E12, 250.0], [1.63049148E12, 388.0], [1.63049166E12, 211.0], [1.63049154E12, 352.0], [1.63049136E12, 152.0], [1.63049142E12, 280.0], [1.63049172E12, 336.0], [1.63049124E12, 178.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.6304913E12, 2326.5], [1.63049112E12, 686.0], [1.6304916E12, 7937.5], [1.63049118E12, 517.0], [1.63049148E12, 5841.0], [1.63049166E12, 6825.5], [1.63049154E12, 6731.0], [1.63049136E12, 1810.0], [1.63049142E12, 5100.5], [1.63049172E12, 7444.0], [1.63049124E12, 1049.5]], "isOverall": false, "label": "Median", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.63049172E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 1012.5, "minX": 1.0, "maxY": 10277.5, "series": [{"data": [[2.0, 3700.5], [33.0, 6470.0], [35.0, 6475.0], [37.0, 7837.0], [36.0, 7333.5], [42.0, 8762.5], [3.0, 3433.5], [60.0, 7507.0], [4.0, 3208.0], [5.0, 2276.0], [6.0, 1629.5], [7.0, 2367.0], [8.0, 1012.5], [9.0, 2616.0], [10.0, 2043.0], [11.0, 1909.5], [12.0, 4584.0], [13.0, 3392.0], [14.0, 5386.5], [15.0, 2402.5], [1.0, 3383.0], [16.0, 4772.0], [17.0, 6847.0], [18.0, 6001.5], [19.0, 4772.5], [20.0, 4246.5], [21.0, 3832.0], [22.0, 4517.5], [23.0, 8109.0], [24.0, 6514.5], [25.0, 6159.0], [26.0, 2795.0], [27.0, 6457.0], [28.0, 10227.5], [29.0, 4419.0], [30.0, 5535.0], [31.0, 10277.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 60.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 1012.0, "minX": 1.0, "maxY": 10277.5, "series": [{"data": [[2.0, 3700.5], [33.0, 6470.0], [35.0, 6475.0], [37.0, 7837.0], [36.0, 7333.5], [42.0, 8762.5], [3.0, 3433.5], [60.0, 7507.0], [4.0, 3208.0], [5.0, 2276.0], [6.0, 1629.5], [7.0, 2367.0], [8.0, 1012.0], [9.0, 2616.0], [10.0, 2043.0], [11.0, 1909.5], [12.0, 4584.0], [13.0, 3392.0], [14.0, 5386.5], [15.0, 2402.5], [1.0, 3383.0], [16.0, 4772.0], [17.0, 6847.0], [18.0, 6001.5], [19.0, 4772.5], [20.0, 4246.5], [21.0, 3832.0], [22.0, 4517.5], [23.0, 8109.0], [24.0, 6514.5], [25.0, 6159.0], [26.0, 2795.0], [27.0, 6457.0], [28.0, 10227.5], [29.0, 4419.0], [30.0, 5535.0], [31.0, 10277.5]], "isOverall": false, "label": "Successes", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 1000, "maxX": 60.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median Latency time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 1.2333333333333334, "minX": 1.63049112E12, "maxY": 9.0, "series": [{"data": [[1.6304913E12, 6.633333333333334], [1.63049112E12, 1.2333333333333334], [1.6304916E12, 6.833333333333333], [1.63049118E12, 4.216666666666667], [1.63049148E12, 7.833333333333333], [1.63049166E12, 9.0], [1.63049154E12, 7.766666666666667], [1.63049136E12, 8.666666666666666], [1.63049142E12, 7.8], [1.63049172E12, 4.366666666666666], [1.63049124E12, 6.416666666666667]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.63049172E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 1.15, "minX": 1.63049112E12, "maxY": 8.4, "series": [{"data": [[1.6304913E12, 6.533333333333333], [1.63049112E12, 1.15], [1.6304916E12, 7.9], [1.63049118E12, 4.016666666666667], [1.63049148E12, 7.883333333333334], [1.63049166E12, 8.0], [1.63049154E12, 7.433333333333334], [1.63049136E12, 8.4], [1.63049142E12, 7.5], [1.63049172E12, 5.483333333333333], [1.63049124E12, 6.466666666666667]], "isOverall": false, "label": "200", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.63049172E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 1.15, "minX": 1.63049112E12, "maxY": 8.4, "series": [{"data": [[1.6304913E12, 6.533333333333333], [1.63049112E12, 1.15], [1.6304916E12, 7.9], [1.63049118E12, 4.016666666666667], [1.63049148E12, 7.883333333333334], [1.63049166E12, 8.0], [1.63049154E12, 7.433333333333334], [1.63049136E12, 8.4], [1.63049142E12, 7.5], [1.63049172E12, 5.483333333333333], [1.63049124E12, 6.466666666666667]], "isOverall": false, "label": "HTTP Request dyna-success", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.63049172E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(infos.data.result.series.length == 0) {
        setEmptyGraph("#bodyTransactionsPerSecond");
        return;
    }
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var totalTPSInfos = {
        data: {"result": {"minY": 1.15, "minX": 1.63049112E12, "maxY": 8.4, "series": [{"data": [[1.6304913E12, 6.533333333333333], [1.63049112E12, 1.15], [1.6304916E12, 7.9], [1.63049118E12, 4.016666666666667], [1.63049148E12, 7.883333333333334], [1.63049166E12, 8.0], [1.63049154E12, 7.433333333333334], [1.63049136E12, 8.4], [1.63049142E12, 7.5], [1.63049172E12, 5.483333333333333], [1.63049124E12, 6.466666666666667]], "isOverall": false, "label": "Transaction-success", "isController": false}, {"data": [], "isOverall": false, "label": "Transaction-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.63049172E12, "title": "Total Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: getTimeFormat(this.data.result.granularity),
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTotalTPS"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                },
                colors: ["#9ACD32", "#FF6347"]
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTotalTPS"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTotalTPS"), dataset, options);
        // setup overview
        $.plot($("#overviewTotalTPS"), dataset, prepareOverviewOptions(options));
    }
};

// Total Transactions per second
function refreshTotalTPS(fixTimestamps) {
    var infos = totalTPSInfos;
    // We want to ignore seriesFilter
    prepareSeries(infos.data, false, true);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 0);
    }
    if(isGraph($("#flotTotalTPS"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTotalTPS");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTotalTPS", "#overviewTotalTPS");
        $('#footerTotalTPS .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyCustomGraph") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCustomGraph(true);
            }
            document.location.href="#responseCustomGraph";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyTotalTPS") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTotalTPS(true);
            }
            document.location.href="#totalTPS";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    }else if(id == "choicesResponseCustomGraph"){
        choiceContainer = $("#choicesResponseCustomGraph");
        refreshCustomGraph(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "choicesResponseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesTotalTPS"){
        choiceContainer = $("#choicesTotalTPS");
        refreshTotalTPS(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    if(choiceContainer != null) {
        choiceContainer.find("label").each(function(){
            this.style.color = color;
        });
    }
}

